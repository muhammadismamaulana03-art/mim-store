export interface SkuItem {
  id: string;
  kode: string;
  nama: string;
  totalModal: number;
  hpp?: number;
  packing: number;
  targetUntung?: number;
  hargaKompetitor?: number;
  calcMode?: 'ideal' | 'kompetitor';
  selectedPreset?: string;
  adminPct?: number;
  ongkirPct?: number;
  affPct?: number;
  biayaProses?: number;
  voucherToko?: number;
  diskonCoretPct?: number;
  biayaIklanPcs?: number;
  rtsCodPct?: number;
  hargaCoret: number;
  hargaJualFinal: number;
  totalSemuaFee: number;
  minRoas: string;
  profitBersih: number;
  profitSetelahIklan?: number;
  netMarginPct: string;
  updatedAt?: string;
}

export interface BuyerLicenseRecord {
  id: string;
  namaToko: string;
  noWa?: string;
  tier: 'v4' | 'v5';
  kodeLisensi: string;
  hargaLabel: string;
  tanggal: string;
}

export const PRESETS_MP = [
  {
    id: 'shopee-star',
    name: 'Shopee Star',
    desc: 'Adm 6.5% + Xtra 4%',
    adm: 6.5,
    ongkir: 4.0,
    aff: 5.0,
    proses: 1250,
  },
  {
    id: 'shopee-mall',
    name: 'Shopee Mall',
    desc: 'Adm 8.0% + Xtra 4.5%',
    adm: 8.0,
    ongkir: 4.5,
    aff: 5.0,
    proses: 1250,
  },
  {
    id: 'tiktok-shop',
    name: 'TikTok Shop',
    desc: 'Adm 6% + Aff 8%',
    adm: 6.0,
    ongkir: 3.0,
    aff: 8.0,
    proses: 1000,
  },
  {
    id: 'tokopedia-lazada',
    name: 'Tokopedia / Lazada',
    desc: 'Adm 5.5% + Ongkir 3.5%',
    adm: 5.5,
    ongkir: 3.5,
    aff: 0.0,
    proses: 1000,
  },
];

export const PRESETS_KATEGORI = [
  {
    id: 'fashion',
    name: 'Fashion & Hijab',
    katLabel: 'Kat. A',
    desc: 'Pakaian, Sepatu, Tas, Aksesoris',
    rates: {
      'shopee-star': 8.0,
      'shopee-mall': 8.5,
      'tiktok-shop': 6.5,
      'tokopedia-lazada': 6.5,
    } as Record<string, number>,
  },
  {
    id: 'beauty',
    name: 'Skincare & Beauty',
    katLabel: 'Kat. A/B',
    desc: 'Kosmetik, Skincare, Parfum',
    rates: {
      'shopee-star': 7.5,
      'shopee-mall': 8.5,
      'tiktok-shop': 6.0,
      'tokopedia-lazada': 6.0,
    } as Record<string, number>,
  },
  {
    id: 'home',
    name: 'Rumah Tangga & Umum',
    katLabel: 'Kat. B',
    desc: 'Perlengkapan Rumah, Ibu & Anak, Hobi',
    rates: {
      'shopee-star': 6.5,
      'shopee-mall': 8.0,
      'tiktok-shop': 6.0,
      'tokopedia-lazada': 5.5,
    } as Record<string, number>,
  },
  {
    id: 'fmcg',
    name: 'Makanan & Herbal',
    katLabel: 'Kat. C',
    desc: 'Snack, Minuman, Suplemen, FMCG',
    rates: {
      'shopee-star': 5.75,
      'shopee-mall': 6.5,
      'tiktok-shop': 5.0,
      'tokopedia-lazada': 5.0,
    } as Record<string, number>,
  },
  {
    id: 'elektronik',
    name: 'Elektronik & Gadget',
    katLabel: 'Kat. D/E',
    desc: 'Aksesoris HP, Audio, Alat Elektronik',
    rates: {
      'shopee-star': 4.25,
      'shopee-mall': 5.5,
      'tiktok-shop': 4.0,
      'tokopedia-lazada': 4.0,
    } as Record<string, number>,
  },
];

export const GMV_MAX_ROAS_TARGETS = [
  { roas: 5, label: '5x (Agresif)' },
  { roas: 8, label: '8x (Standar)' },
  { roas: 10, label: '10x (Optimal)' },
  { roas: 12, label: '12x (Hemat)' },
  { roas: 15, label: '15x (Profit Tinggi)' },
];

export function rp(angka: number): string {
  return 'Rp ' + Math.round(angka || 0).toLocaleString('id-ID');
}
