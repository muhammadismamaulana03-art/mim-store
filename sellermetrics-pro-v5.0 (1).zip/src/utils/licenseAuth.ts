/**
 * Modul Verifikasi Lisensi, Obfuscated Owner PIN, Generator Serial Key & Proteksi Keamanan
 * SellerMetrics Pro Suite (v4.0 Pro & v5.0 Ultimate)
 */

export const OWNER_CONFIG = {
  brandName: 'WebCraft by MiM Studio',
  waNumber: '62895401068156',
  hargaLisensi: 'Rp 129.000',
  hargaLisensiV5: 'Rp 199.000',
  hargaUpgradeV5: 'Rp 79.000',
  hargaNormalCoret: 'Rp 349.000',
  hargaSourceCode: 'Rp 499.000',
};

function computeSecurityHash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// Hash dari PIN Pemilik ('ADMIN-MIM') agar tidak tertulis plain-text di konfigurasi
const OWNER_PIN_HASH = 1861201883;

// Hash FNV-1a untuk Master Backup Keys (v4 & v5) agar tidak terekspos plain-text di logika verifikasi utama
const MASTER_V4_HASHES = [247477267, 2127581809, 3089821788];
const MASTER_V5_HASHES = [1481807329, 3630623950, 4041204160];

export function verifyOwnerPin(input: string): boolean {
  const normalized = (input || '').trim().toUpperCase();
  if (!normalized) return false;
  return computeSecurityHash(`SM_AUTH_${normalized}_2026`) === OWNER_PIN_HASH;
}

export function verifyMasterBackupKey(
  input: string,
  tier: 'v4' | 'v5'
): boolean {
  const normalized = (input || '').trim().toUpperCase();
  if (!normalized) return false;
  if (tier === 'v5') {
    return MASTER_V5_HASHES.includes(computeSecurityHash(`SM_MK5_${normalized}`));
  }
  return MASTER_V4_HASHES.includes(computeSecurityHash(`SM_MK4_${normalized}`));
}

export function generateSerialKey(
  namaToko: string,
  tier: 'v4' | 'v5' = 'v4'
): string {
  const clean = (namaToko || 'TOKO').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const prefix = (clean + 'XXXX').substring(0, 5);
  let hash = 0;
  for (let i = 0; i < clean.length; i++) {
    hash = (hash << 5) - hash + clean.charCodeAt(i);
    hash |= 0;
  }
  if (tier === 'v5') {
    const secretV5 = (Math.abs(hash * 8191 + 2027) % 9000) + 1000;
    return `SM5-${prefix}-${secretV5}`;
  }
  const secretMultiplier = (Math.abs(hash * 7919 + 2026) % 9000) + 1000;
  return `SM-${prefix}-${secretMultiplier}`;
}

export function formatBuyerWaNumber(raw: string): string {
  const digits = (raw || '').replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.startsWith('0')) {
    return '62' + digits.slice(1);
  }
  if (digits.startsWith('8')) {
    return '62' + digits;
  }
  return digits;
}

/**
 * Safe JSON Parser (Anti-Prototype Pollution Guard)
 * Mencegah injeksi properti __proto__, constructor, atau prototype saat import file .json
 */
export function safeParseJson<T = unknown>(raw: string): T {
  return JSON.parse(raw, (key, value) => {
    if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
      return undefined;
    }
    return value;
  }) as T;
}

/**
 * Sanitasi teks input/CSV untuk mencegah CSV Formula Injection (=, +, -, @)
 */
export function sanitizeImportedString(val: unknown, maxLen = 120): string {
  const clean = String(val ?? '')
    .trim()
    .slice(0, maxLen);
  return clean.replace(/^[=+\-@]+/, '');
}
