import React from 'react';
import {
  Smartphone,
  X,
  Share2,
  PlusSquare,
  BookOpen,
  ShieldCheck,
  Lock,
  CheckCircle2,
  ServerOff,
  FileCheck2,
} from 'lucide-react';

interface GuideAndInstallModalsProps {
  showInstallModal: boolean;
  setShowInstallModal: (v: boolean) => void;
  isIOS: boolean;
  showGuideModal: boolean;
  setShowGuideModal: (v: boolean) => void;
  showSecurityModal?: boolean;
  setShowSecurityModal?: (v: boolean) => void;
}

export const GuideAndInstallModals: React.FC<GuideAndInstallModalsProps> = ({
  showInstallModal,
  setShowInstallModal,
  isIOS,
  showGuideModal,
  setShowGuideModal,
  showSecurityModal = false,
  setShowSecurityModal,
}) => {
  return (
    <>
      {/* MODAL PANDUAN INSTALL APLIKASI (PWA) */}
      {showInstallModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md overflow-y-auto no-print">
          <div className="min-h-full w-full flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-[#0E131F] border border-indigo-500/35 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4 my-4">
              <div className="flex justify-between items-start gap-3 border-b border-slate-800/80 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white">
                      Install Aplikasi SellerMetrics Pro
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Akses instan dari layar utama & berjalan 100% offline
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowInstallModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                {isIOS ? (
                  <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-2.5">
                    <div className="font-bold text-amber-300 flex items-center gap-1.5">
                      <span>Cara Install di iPhone / iPad (Safari):</span>
                    </div>
                    <ol className="space-y-2 text-slate-300 list-decimal list-inside leading-relaxed">
                      <li>
                        Ketuk ikon{' '}
                        <strong className="text-white inline-flex items-center gap-1">
                          <Share2 className="w-3.5 h-3.5 text-sky-400 inline" />{' '}
                          Bagikan (Share)
                        </strong>{' '}
                        di bagian bawah browser Safari.
                      </li>
                      <li>
                        Gulir ke bawah lalu pilih menu{' '}
                        <strong className="text-white inline-flex items-center gap-1">
                          <PlusSquare className="w-3.5 h-3.5 text-emerald-400 inline" />{' '}
                          Tambah ke Layar Utama (Add to Home Screen)
                        </strong>
                        .
                      </li>
                      <li>
                        Ketuk <strong className="text-white">Tambah</strong> di
                        pojok kanan atas.
                      </li>
                    </ol>
                  </div>
                ) : (
                  <>
                    <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-2">
                      <div className="font-bold text-emerald-400">
                        1. Pengguna HP Android (Chrome):
                      </div>
                      <p className="text-slate-400 leading-relaxed">
                        Ketuk ikon{' '}
                        <strong className="text-white">Titik Tiga (⋮)</strong>{' '}
                        di pojok kanan atas browser Chrome, lalu pilih{' '}
                        <strong className="text-white">
                          &ldquo;Instal aplikasi&rdquo;
                        </strong>{' '}
                        atau{' '}
                        <strong className="text-white">
                          &ldquo;Tambahkan ke Layar Utama&rdquo;
                        </strong>
                        .
                      </p>
                    </div>

                    <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-2">
                      <div className="font-bold text-sky-400">
                        2. Pengguna Laptop / PC (Chrome & Edge):
                      </div>
                      <p className="text-slate-400 leading-relaxed">
                        Klik ikon{' '}
                        <strong className="text-white">
                          Install (Monitor dengan panah unduh)
                        </strong>{' '}
                        di sebelah kanan kolom alamat URL browser bagian atas.
                      </p>
                    </div>

                    <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-2">
                      <div className="font-bold text-amber-300">
                        3. Pengguna iPhone / iPad (Safari):
                      </div>
                      <p className="text-slate-400 leading-relaxed">
                        Ketuk tombol <strong className="text-white">Share</strong>{' '}
                        lalu pilih{' '}
                        <strong className="text-white">
                          &ldquo;Add to Home Screen&rdquo;
                        </strong>
                        .
                      </p>
                    </div>
                  </>
                )}
              </div>

              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowInstallModal(false)}
                  className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors cursor-pointer"
                >
                  Mengerti
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL PANDUAN CEPAT CARA PAKAI & BACA ANGKA */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md overflow-y-auto no-print">
          <div className="min-h-full w-full flex items-center justify-center p-3 sm:p-5">
            <div className="max-w-xl w-full bg-[#0E131F] border border-orange-500/35 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4 my-4">
              <div className="flex justify-between items-start gap-3 border-b border-slate-800/80 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400 shrink-0">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white">
                      Panduan Cepat SellerMetrics Pro v5.0
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Cara membaca hasil kalkulator, GMV Max ROAS, RTS COD &
                      pasang harga di Seller Centre
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGuideModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-300 max-h-[65vh] overflow-y-auto pr-1">
                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-orange-400">
                    1. Bedanya Mode &ldquo;Cari Harga Ideal&rdquo; vs
                    &ldquo;Audit Kompetitor&rdquo;
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    •{' '}
                    <strong className="text-white">
                      Cari Harga Jual Ideal:
                    </strong>{' '}
                    Gunakan saat menentukan harga jual baru agar profit bersih
                    per pcs sesuai target (sudah otomatis mengamankan biaya
                    admin, iklan, & risiko retur COD).
                    <br />•{' '}
                    <strong className="text-white">
                      Audit Harga Kompetitor:
                    </strong>{' '}
                    Gunakan saat ingin ikut harga pasar/kompetitor dan ingin
                    tahu berapa sisa untung bersih sebenarnya.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-amber-300">
                    2. Cara Pasang &ldquo;Harga Coret&rdquo; di Shopee / TikTok
                    Shop
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Masukkan angka{' '}
                    <strong className="text-amber-300">
                      Harga Sebelum Diskon (Harga Coret)
                    </strong>{' '}
                    sebagai Harga Normal produk di Seller Centre, lalu buat{' '}
                    <strong className="text-white">Promosi Diskon Toko</strong>{' '}
                    sebesar persentase diskon yang Anda pilih (misal 35%). Hasil
                    akhirnya akan pas menjadi Harga Jual Final dan profit Anda
                    tetap utuh 100%.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-indigo-300">
                    3. Simulator Iklan GMV Max & Cadangan Retur COD (RTS)
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    •{' '}
                    <strong className="text-white">
                      Simulator Target ROAS GMV Max:
                    </strong>{' '}
                    Klik tombol target ROAS (5x, 8x, 10x, 12x, 15x) untuk
                    melihat berapa biaya iklan per pcs otomatis dan sisa profit
                    bersih Anda pada iklan GMV Max Shopee/TikTok.
                    <br />•{' '}
                    <strong className="text-rose-300">
                      Cadangan Retur COD (RTS):
                    </strong>{' '}
                    Menyisihkan cadangan biaya packing hangus & ongkir retur
                    dari paket COD gagal kirim agar profit toko tidak bocor.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-emerald-400">
                    4. Simpan SKU, Backup Excel (.CSV) & Cetak PDF
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Klik{' '}
                    <strong className="text-white">
                      Simpan ke Katalog SKU
                    </strong>{' '}
                    untuk menyimpan perhitungan produk. Buka tab{' '}
                    <strong className="text-white">SKU</strong> untuk mencari
                    produk, klik <strong className="text-white">Muat</strong>{' '}
                    jika ingin mengedit ulang, klik{' '}
                    <strong className="text-white">Export CSV</strong> untuk
                    backup ke Excel, atau{' '}
                    <strong className="text-white">Restore / Import</strong>{' '}
                    untuk memulihkan data katalog Anda kapan saja.
                  </p>
                </div>

                <div className="bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-500/30 space-y-1.5">
                  <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>
                      5. Jaminan Keamanan Arsitektur Zero-Server (Kebal Isu
                      Node.js)
                    </span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">
                    Aplikasi ini berjalan 100% sebagai{' '}
                    <strong className="text-white">
                      Client-Side Static PWA
                    </strong>{' '}
                    tanpa server Node.js di belakang layar dan tanpa database
                    cloud eksternal. Seluruh rahasia HPP pabrik dan katalog SKU
                    tersimpan lokal di browser Anda sendiri sehingga mustahil
                    bocor akibat celah keamanan server.
                  </p>
                </div>
              </div>

              <div className="pt-1 flex flex-wrap justify-between items-center gap-2">
                {setShowSecurityModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowGuideModal(false);
                      setShowSecurityModal(true);
                    }}
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Lihat Detail Audit Keamanan Sistem</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowGuideModal(false)}
                  className="w-full sm:w-auto bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 text-xs font-extrabold px-5 py-2.5 rounded-xl transition-all cursor-pointer ml-auto"
                >
                  Siap, Mengerti!
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL AUDIT KEAMANAN & PROTEKSI ARSITEKTUR ZERO-SERVER */}
      {showSecurityModal && setShowSecurityModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md overflow-y-auto no-print">
          <div className="min-h-full w-full flex items-center justify-center p-3 sm:p-5">
            <div className="max-w-xl w-full bg-[#0E131F] border border-emerald-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4 my-4">
              <div className="flex justify-between items-start gap-3 border-b border-slate-800/80 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/35 flex items-center justify-center text-emerald-400 shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                      Security Audit &bull; Static Zero-Server Architecture
                    </div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white">
                      Status Keamanan Website &amp; File SellerMetrics Pro
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowSecurityModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-emerald-950/25 border border-emerald-500/35 rounded-xl p-3.5 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-200 leading-relaxed">
                  <strong className="text-emerald-300 block mb-0.5">
                    STATUS: 100% AMAN (KEBAL CELAH SERVER NODE.JS)
                  </strong>
                  Website Anda di Netlify maupun file mandiri (
                  <code className="text-amber-300">.html</code> /{' '}
                  <code className="text-amber-300">.zip</code>) tidak
                  menjalankan server Node.js di produksi. Celah keamanan atau
                  kebocoran runtime Node.js sama sekali tidak berdampak pada
                  website Anda.
                </div>
              </div>

              <div className="space-y-2.5 text-xs text-slate-300 max-h-[58vh] overflow-y-auto pr-1">
                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <ServerOff className="w-4 h-4 text-sky-400 shrink-0" />
                    <span>
                      1. Arsitektur Murni Statis (Zero-Server Runtime)
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Node.js hanya dipakai sebagai alat pembungkus (compiler)
                    saat membuat file statis. Hasil akhirnya yang di-upload ke
                    Netlify (<code className="text-amber-300">dist/</code>)
                    murni berupa HTML, CSS, dan JavaScript statis tanpa backend
                    Node.js yang bisa disusupi hacker.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      2. Obfuskasi Hash FNV-1a pada PIN &amp; Master Lisensi
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Verifikasi Master PIN Pemilik dan Master Kode Cadangan
                    dilindungi dengan algoritma satu arah{' '}
                    <strong className="text-slate-200">
                      FNV-1a Security Hash
                    </strong>
                    , sehingga kredensial tidak tertulis telanjang di kode
                    verifikasi utama.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-indigo-400 shrink-0" />
                    <span>
                      3. Proteksi Anti-Prototype Pollution &amp; Sanitasi Import
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Fitur <em>Restore / Import CSV &amp; JSON</em> dilengkapi
                    filter pembersih properti berbahaya (
                    <code>__proto__</code>, <code>constructor</code>), batas
                    ukuran file maksimal 2MB, serta sanitasi formula berbahaya.
                  </p>
                </div>

                <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>
                      4. Netlify HTTP Security Headers (<code>_headers</code>)
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Paket ZIP Netlify Anda kini dilengkapi file{' '}
                    <code className="text-emerald-300">_headers</code> otomatis
                    (<code>X-Frame-Options: SAMEORIGIN</code>,{' '}
                    <code>X-Content-Type-Options: nosniff</code>,{' '}
                    <code>Strict-Transport-Security</code>, &amp;{' '}
                    <code>Permissions-Policy</code>) untuk mencegah pembajakan
                    iframe (clickjacking) dan pencurian data.
                  </p>
                </div>
              </div>

              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowSecurityModal(false)}
                  className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold px-5 py-2.5 rounded-xl transition-colors cursor-pointer"
                >
                  Tutup Audit Keamanan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
