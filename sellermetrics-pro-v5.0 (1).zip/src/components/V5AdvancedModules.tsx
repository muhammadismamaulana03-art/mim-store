import React, { useState, useMemo } from 'react';
import {
  Tag,
  Wallet,
  RefreshCw,
  Check,
  Copy,
  Building2,
  AlertCircle,
  TrendingUp,
  Search,
  Layers,
  ShieldAlert,
  Video,
  TicketPercent,
  MessageSquareShare,
} from 'lucide-react';
import { rp } from '../data/marketplacePresets';

interface V5AdvancedModulesProps {
  skuNama: string;
  hargaJualFinal: number;
  hpp: number;
  packing: number;
  totalModal: number;
  totalPctFee: number;
  totalPotonganTetap: number;
  biayaIklanPcs: number;
  profitBersih: number;
  danaCair: number;
  diskonCoretPct: number;
  onApplyDiskonCoret: (pct: number) => void;
  onSyncOpexAndGajiToSimulasi: (totalOpex: number, targetGaji: number) => void;
  onToast: (msg: string) => void;
}

const DISKON_TIERS = [15, 25, 35, 45, 50, 60];

const VARIANT_TEMPLATES = {
  fashion: [
    { label: 'Ukuran S / M (Standar)', step: 0 },
    { label: 'Ukuran L', step: 1 },
    { label: 'Ukuran XL', step: 2 },
    { label: 'Ukuran XXL / Jumbo', step: 3 },
  ],
  beauty: [
    { label: 'Kemasan Travel 20ml', step: 0 },
    { label: 'Kemasan Reguler 50ml', step: 1 },
    { label: 'Kemasan Besar 100ml', step: 2 },
    { label: 'Paket Bundling Full Size', step: 3 },
  ],
};

export const V5AdvancedModules: React.FC<V5AdvancedModulesProps> = ({
  skuNama,
  hargaJualFinal,
  hpp,
  packing,
  totalModal,
  totalPctFee,
  totalPotonganTetap,
  biayaIklanPcs,
  profitBersih,
  danaCair,
  diskonCoretPct,
  onApplyDiskonCoret,
  onSyncOpexAndGajiToSimulasi,
  onToast,
}) => {
  // State Modul 06: Generator Harga Coret
  const [copiedCoretTable, setCopiedCoretTable] = useState<boolean>(false);

  // State Modul 07: Overhead Toko & Target Gaji Owner
  const [opexGajiStaff, setOpexGajiStaff] = useState<number>(2200000);
  const [opexListrikInternet, setOpexListrikInternet] = useState<number>(450000);
  const [opexSewaAtk, setOpexSewaAtk] = useState<number>(650000);
  const [targetGajiOwner, setTargetGajiOwner] = useState<number>(8000000);

  // State Modul 08: Perputaran Modal Kerja & Dana Tertahan
  const [cfOrderHari, setCfOrderHari] = useState<number>(25);
  const [cfSettlementHari, setCfSettlementHari] = useState<number>(5);
  const [cfRestockLeadHari, setCfRestockLeadHari] = useState<number>(7);

  // State Modul 09: Detektor Kebocoran Dana Cair Aktual
  const [actualSettlementRp, setActualSettlementRp] = useState<number | null>(
    null
  );

  // State Modul 10: Kalkulator Harga Multi-Varian Ukuran / Kemasan
  const [variantMode, setVariantMode] = useState<'fashion' | 'beauty'>(
    'fashion'
  );
  const [hppStepPerSize, setHppStepPerSize] = useState<number>(4000);
  const [copiedVariantTable, setCopiedVariantTable] = useState<boolean>(false);

  // State Modul 11: Kalkulator Live Streaming Host & Studio (TikTok / Shopee Live)
  const [liveDurasiJam, setLiveDurasiJam] = useState<number>(3);
  const [liveFeeHostPerJam, setLiveFeeHostPerJam] = useState<number>(35000);
  const [liveBonusHostPct, setLiveBonusHostPct] = useState<number>(3);
  const [liveTargetOrderSesi, setLiveTargetOrderSesi] = useState<number>(20);

  // State Modul 12: Simulator Keamanan Voucher Minimum Belanja Bertingkat
  const [voucherTier1DiskonRp, setVoucherTier1DiskonRp] =
    useState<number>(3000);
  const [voucherTier2DiskonRp, setVoucherTier2DiskonRp] =
    useState<number>(10000);
  const [voucherTier3DiskonRp, setVoucherTier3DiskonRp] =
    useState<number>(20000);

  // State Modul 13: Generator Skrip Undangan & Brief Affiliate Kreator
  const [briefKomisiPct, setBriefKomisiPct] = useState<number>(10);
  const [briefKeunggulanProduk, setBriefKeunggulanProduk] = useState<string>(
    'Bahan premium, stok ribuan siap kirim hari ini, rating 4.9 bintang & konversi tinggi di Live/Video'
  );
  const [copiedCreatorBrief, setCopiedCreatorBrief] = useState<boolean>(false);

  // Perhitungan Modul 06: Generator Harga Coret Psikologis
  const strikeThroughMatrix = useMemo(() => {
    const baseHarga = Math.max(0, hargaJualFinal || 0);
    return DISKON_TIERS.map((pct) => {
      const pembagi = 1 - pct / 100;
      const hargaCoretMurni =
        pembagi > 0.05 ? Math.ceil(baseHarga / pembagi) : baseHarga;
      const ribuan = Math.floor(hargaCoretMurni / 1000) * 1000;
      const hargaCoretCantik =
        hargaCoretMurni % 1000 <= 900 ? ribuan + 900 : ribuan + 1900;
      const hargaJatuhCantik = Math.round(hargaCoretCantik * (1 - pct / 100));

      return {
        pct,
        hargaCoretMurni,
        hargaCoretCantik,
        hargaJatuhCantik,
        selisihDiskonNominal: hargaCoretMurni - baseHarga,
      };
    });
  }, [hargaJualFinal]);

  // Perhitungan Modul 07: BEP Operasional & Target Gaji Owner
  const overheadResult = useMemo(() => {
    const gaji = Math.max(0, Number(opexGajiStaff) || 0);
    const utilitas = Math.max(0, Number(opexListrikInternet) || 0);
    const sewa = Math.max(0, Number(opexSewaAtk) || 0);
    const gajiOwner = Math.max(0, Number(targetGajiOwner) || 0);

    const totalFixedCostBulan = gaji + utilitas + sewa;
    const totalBebanPlusOwner = totalFixedCostBulan + gajiOwner;
    const labaPerPcs = Math.max(0, profitBersih || 0);

    const bepTokoBulanPcs =
      labaPerPcs > 0 ? Math.ceil(totalFixedCostBulan / labaPerPcs) : 0;
    const bepTokoHariPcs =
      bepTokoBulanPcs > 0 ? Math.ceil(bepTokoBulanPcs / 30) : 0;

    const targetOwnerBulanPcs =
      labaPerPcs > 0 ? Math.ceil(totalBebanPlusOwner / labaPerPcs) : 0;
    const targetOwnerHariPcs =
      targetOwnerBulanPcs > 0 ? Math.ceil(targetOwnerBulanPcs / 30) : 0;

    const omzetWajibBulan = targetOwnerBulanPcs * (hargaJualFinal || 0);

    return {
      totalFixedCostBulan,
      totalBebanPlusOwner,
      bepTokoBulanPcs,
      bepTokoHariPcs,
      targetOwnerBulanPcs,
      targetOwnerHariPcs,
      omzetWajibBulan,
    };
  }, [
    opexGajiStaff,
    opexListrikInternet,
    opexSewaAtk,
    targetGajiOwner,
    profitBersih,
    hargaJualFinal,
  ]);

  // Perhitungan Modul 08: Perputaran Modal Kerja & Dana Tertahan
  const cashflowResult = useMemo(() => {
    const orderHari = Math.max(1, Number(cfOrderHari) || 1);
    const hariCair = Math.max(1, Number(cfSettlementHari) || 1);
    const hariRestock = Math.max(1, Number(cfRestockLeadHari) || 1);

    const modalPerPcs = Math.max(0, totalModal || 0);
    const cairPerPcs = Math.max(0, danaCair || 0);
    const omsetPerPcs = Math.max(0, hargaJualFinal || 0);

    const paketTertahan = orderHari * hariCair;
    const omsetTertahan = paketTertahan * omsetPerPcs;
    const danaCairTertahan = paketTertahan * cairPerPcs;
    const modalHppTertahan = paketTertahan * modalPerPcs;

    const stokBufferRestockPcs = orderHari * hariRestock;
    const modalBufferRestockRp = stokBufferRestockPcs * modalPerPcs;

    const totalModalKerjaAman = modalHppTertahan + modalBufferRestockRp;
    const totalSiklusHari = hariCair + hariRestock;

    return {
      orderHari,
      hariCair,
      hariRestock,
      paketTertahan,
      omsetTertahan,
      danaCairTertahan,
      modalHppTertahan,
      stokBufferRestockPcs,
      modalBufferRestockRp,
      totalModalKerjaAman,
      totalSiklusHari,
    };
  }, [
    cfOrderHari,
    cfSettlementHari,
    cfRestockLeadHari,
    totalModal,
    danaCair,
    hargaJualFinal,
  ]);

  // Perhitungan Modul 09: Detektor Kebocoran Dana Cair Aktual
  const auditDanaCairResult = useMemo(() => {
    const expectedCair = Math.max(0, danaCair || 0);
    const currentActual =
      actualSettlementRp !== null
        ? Math.max(0, actualSettlementRp)
        : Math.max(0, expectedCair - 4500);
    const selisihBocorRp = expectedCair - currentActual;
    const potonganAktualRp = Math.max(0, (hargaJualFinal || 0) - currentActual);
    const potonganAktualPct =
      hargaJualFinal > 0
        ? ((potonganAktualRp / hargaJualFinal) * 100).toFixed(1)
        : '0.0';
    const potonganResmiPct =
      hargaJualFinal > 0
        ? (
            (((hargaJualFinal || 0) - expectedCair) / hargaJualFinal) *
            100
          ).toFixed(1)
        : '0.0';
    const sisaProfitAktual =
      currentActual - (totalModal || 0) - (biayaIklanPcs || 0);

    let diagnosa =
      'Dana cair sesuai dengan perhitungan potongan resmi marketplace (Aman).';
    if (selisihBocorRp > 8000) {
      diagnosa =
        '⚠️ Bocor Besar (>Rp 8.000): Cek apakah terkena denda Selisih Ongkir (berat paket aktual > berat di sistem), Voucher Kampanye Otomatis, atau Komisi Affiliate MCN tinggi!';
    } else if (selisihBocorRp > 1500) {
      diagnosa =
        '⚠️ Ada Selisih Potongan: Kemungkinan karena Biaya Layanan Live Xtra / Promo Xtra tambahan, pembulatan PPN biaya layanan, atau Voucher Toko yang lupa dimatikan.';
    }

    return {
      expectedCair,
      currentActual,
      selisihBocorRp,
      potonganAktualPct,
      potonganResmiPct,
      sisaProfitAktual,
      diagnosa,
    };
  }, [
    danaCair,
    actualSettlementRp,
    hargaJualFinal,
    totalModal,
    biayaIklanPcs,
  ]);

  // Perhitungan Modul 10: Kalkulator Harga Multi-Varian Ukuran / Kemasan
  const variantMatrixResult = useMemo(() => {
    const templates = VARIANT_TEMPLATES[variantMode];
    const stepRp = Math.max(0, Number(hppStepPerSize) || 0);
    const pembagiFee = Math.max(0.1, 1 - (totalPctFee || 0) / 100);
    const pembagiCoret = Math.max(0.1, 1 - (diskonCoretPct || 0) / 100);
    const targetLabaTetap = Math.max(0, profitBersih || 0);

    const rows = templates.map((t) => {
      const hppVarian = (hpp || 0) + t.step * stepRp;
      const modalVarian = hppVarian + (packing || 0);
      const hargaIdealRaw = Math.ceil(
        (modalVarian +
          targetLabaTetap +
          (totalPotonganTetap || 0) +
          (biayaIklanPcs || 0)) /
          pembagiFee
      );
      // Bulatkan ke ratusan .900 terdekat agar rapi
      const ribuan = Math.floor(hargaIdealRaw / 1000) * 1000;
      const hargaJualVarian =
        hargaIdealRaw % 1000 <= 900 ? ribuan + 900 : ribuan + 1900;
      const hargaCoretVarian = Math.ceil(hargaJualVarian / pembagiCoret);
      const potonganVarian =
        Math.round(hargaJualVarian * ((totalPctFee || 0) / 100)) +
        (totalPotonganTetap || 0);
      const labaVarian =
        hargaJualVarian - modalVarian - potonganVarian - (biayaIklanPcs || 0);

      return {
        label: t.label,
        step: t.step,
        hppVarian,
        modalVarian,
        hargaJualVarian,
        hargaCoretVarian,
        labaVarian,
      };
    });

    const minPrice = rows[0]?.hargaJualVarian || 1;
    const maxPrice = rows[rows.length - 1]?.hargaJualVarian || 1;
    const priceRatio = (maxPrice / Math.max(1, minPrice)).toFixed(2);
    const isRatioSafe = maxPrice / Math.max(1, minPrice) <= 4.5;

    return {
      rows,
      priceRatio,
      isRatioSafe,
    };
  }, [
    variantMode,
    hppStepPerSize,
    hpp,
    packing,
    totalPctFee,
    totalPotonganTetap,
    biayaIklanPcs,
    profitBersih,
    diskonCoretPct,
  ]);

  const handleCopyStrikeThroughTable = () => {
    const nama = skuNama.trim() || 'Produk Marketplace';
    const rows = strikeThroughMatrix
      .map(
        (r) =>
          `• Diskon ${r.pct}% → Input Harga Awal: *${rp(r.hargaCoretMurni)}* (Cantik: ${rp(r.hargaCoretCantik)})`
      )
      .join('\n');
    const teks =
      `*TABEL GENERATOR HARGA CORET SELLER CENTRE — v5.0*\n` +
      `📦 Produk: *${nama}*\n` +
      `🎯 Target Harga Jual Bersih: *${rp(hargaJualFinal)}*\n` +
      `----------------------------------------\n` +
      `${rows}\n` +
      `----------------------------------------\n` +
      `_Ketik Harga Awal di atas pada menu Promosi Diskon Toko di Shopee / TikTok Seller Centre._`;
    navigator.clipboard.writeText(teks);
    setCopiedCoretTable(true);
    onToast('Tabel Generator Harga Coret disalin ke Clipboard!');
    setTimeout(() => setCopiedCoretTable(false), 2200);
  };

  const handleCopyVariantTable = () => {
    const nama = skuNama.trim() || 'Produk Marketplace';
    const rows = variantMatrixResult.rows
      .map(
        (r) =>
          `• *${r.label}* (HPP ${rp(r.hppVarian)}) → Harga Coret: ~${rp(r.hargaCoretVarian)}~ | *Harga Jual: ${rp(r.hargaJualVarian)}* (Laba: ${rp(r.labaVarian)})`
      )
      .join('\n');
    const teks =
      `*DAFTAR HARGA MULTI-VARIAN UKURAN / KEMASAN — v5.0*\n` +
      `📦 Produk: *${nama}* (Diskon Toko ${diskonCoretPct}%)\n` +
      `----------------------------------------\n` +
      `${rows}\n` +
      `----------------------------------------\n` +
      `✅ Rasio Rentang Harga Varian: ${variantMatrixResult.priceRatio}x (Aman untuk Shopee & TikTok Shop)`;
    navigator.clipboard.writeText(teks);
    setCopiedVariantTable(true);
    onToast('Tabel Harga Multi-Varian disalin ke Clipboard!');
    setTimeout(() => setCopiedVariantTable(false), 2200);
  };

  // Perhitungan Modul 11: Kalkulator Live Streaming Host & Studio BEP
  const liveSessionResult = useMemo(() => {
    const jam = Math.max(1, Number(liveDurasiJam) || 1);
    const feeJam = Math.max(0, Number(liveFeeHostPerJam) || 0);
    const bonusPct = Math.max(0, Number(liveBonusHostPct) || 0);
    const orderSesi = Math.max(1, Number(liveTargetOrderSesi) || 1);

    const harga = Math.max(0, hargaJualFinal || 0);
    const labaDasarPcs = Math.max(0, profitBersih || 0);
    const bonusHostPerPcs = Math.round(harga * (bonusPct / 100));
    const labaSetelahBonusHostPcs = labaDasarPcs - bonusHostPerPcs;

    const biayaTetapHostSesi = jam * feeJam;
    const totalBonusHostSesi = orderSesi * bonusHostPerPcs;
    const totalBiayaLiveSesi = biayaTetapHostSesi + totalBonusHostSesi;

    const omzetSesiLive = orderSesi * harga;
    const labaKotorSesi = orderSesi * labaSetelahBonusHostPcs;
    const netProfitSesiLive = labaKotorSesi - biayaTetapHostSesi;
    const netProfitBulananLive = netProfitSesiLive * 30;

    const bepOrderSesi =
      labaSetelahBonusHostPcs > 0
        ? Math.ceil(biayaTetapHostSesi / labaSetelahBonusHostPcs)
        : 0;
    const roasLiveSession =
      totalBiayaLiveSesi > 0
        ? (omzetSesiLive / totalBiayaLiveSesi).toFixed(1)
        : '0.0';

    return {
      jam,
      feeJam,
      bonusPct,
      orderSesi,
      bonusHostPerPcs,
      labaSetelahBonusHostPcs,
      biayaTetapHostSesi,
      totalBiayaLiveSesi,
      omzetSesiLive,
      netProfitSesiLive,
      netProfitBulananLive,
      bepOrderSesi,
      roasLiveSession,
    };
  }, [
    liveDurasiJam,
    liveFeeHostPerJam,
    liveBonusHostPct,
    liveTargetOrderSesi,
    hargaJualFinal,
    profitBersih,
  ]);

  // Perhitungan Modul 12: Simulator Keamanan Voucher Minimum Belanja Bertingkat
  const voucherGuardResult = useMemo(() => {
    const harga = Math.max(0, hargaJualFinal || 0);
    const modal = Math.max(0, hpp || 0);
    const pack = Math.max(0, packing || 0);
    const pctFee = Math.max(0, totalPctFee || 0);
    const biayaTetap = Math.max(0, totalPotonganTetap || 0);
    const iklan = Math.max(0, biayaIklanPcs || 0);

    const buildTier = (
      tierName: string,
      qty: number,
      voucherDiskonRp: number
    ) => {
      const minBelanjaRp = harga * qty;
      const omzetSetelahVoucher = Math.max(0, minBelanjaRp - voucherDiskonRp);
      const modalProdukTotal = modal * qty;
      const modalPackingResi = Math.round(pack + pack * (qty - 1) * 0.5);
      const potonganMpRp =
        Math.round(omzetSetelahVoucher * (pctFee / 100)) + biayaTetap;
      const labaSebelumVoucher =
        minBelanjaRp -
        modalProdukTotal -
        modalPackingResi -
        (Math.round(minBelanjaRp * (pctFee / 100)) + biayaTetap) -
        iklan;
      const maxVoucherAmanRp = Math.max(
        0,
        Math.floor(labaSebelumVoucher * 0.65)
      );
      const labaBersihResi =
        omzetSetelahVoucher -
        modalProdukTotal -
        modalPackingResi -
        potonganMpRp -
        iklan;
      const marginPct =
        omzetSetelahVoucher > 0
          ? ((labaBersihResi / omzetSetelahVoucher) * 100).toFixed(1)
          : '0.0';

      return {
        tierName,
        qty,
        minBelanjaRp,
        voucherDiskonRp,
        maxVoucherAmanRp,
        labaBersihResi,
        marginPct,
        isSafe: labaBersihResi > 0 && voucherDiskonRp <= maxVoucherAmanRp,
      };
    };

    return [
      buildTier(
        'Voucher Ikuti Toko (1 Pcs)',
        1,
        Math.max(0, Number(voucherTier1DiskonRp) || 0)
      ),
      buildTier(
        'Voucher Belanja 2 Pcs',
        2,
        Math.max(0, Number(voucherTier2DiskonRp) || 0)
      ),
      buildTier(
        'Voucher VIP Borong 3 Pcs',
        3,
        Math.max(0, Number(voucherTier3DiskonRp) || 0)
      ),
    ];
  }, [
    hargaJualFinal,
    hpp,
    packing,
    totalPctFee,
    totalPotonganTetap,
    biayaIklanPcs,
    voucherTier1DiskonRp,
    voucherTier2DiskonRp,
    voucherTier3DiskonRp,
  ]);

  // Perhitungan Modul 13: Generator Undangan & Skrip Brief Affiliate Kreator
  const creatorBriefData = useMemo(() => {
    const nama = skuNama.trim() || 'Produk Best Seller Kami';
    const harga = Math.max(0, hargaJualFinal || 0);
    const pembagiCoret = Math.max(0.1, 1 - (diskonCoretPct || 0) / 100);
    const hargaCoret = Math.ceil(harga / pembagiCoret);
    const komisiPct = Math.max(1, Number(briefKomisiPct) || 10);
    const komisiPerPcsRp = Math.round(harga * (komisiPct / 100));
    const potensi15PcsHari = komisiPerPcsRp * 15;
    const potensi30Hari = potensi15PcsHari * 30;

    const scriptText =
      `Halo Kak Kreator! 👋 Semoga konten & live-nya makin ramai ya!\n\n` +
      `Kami dari Official Store ingin mengundang Kakak untuk kolaborasi *Affiliate Eksklusif* produk unggulan kami:\n` +
      `📦 *Produk:* ${nama}\n` +
      `🏷️ *Harga Promo:* ${rp(harga)} (Harga Normal Coret ~${rp(hargaCoret)}~)\n` +
      `💰 *Komisi Spesial Kakak:* *${komisiPct}% (${rp(komisiPerPcsRp)} / pcs terjual!)*\n\n` +
      `✨ *Kenapa Produk Ini Gampang Pecah Telur di Keranjang Kuning/Oren?*\n` +
      `• ${briefKeunggulanProduk}\n` +
      `• Simulasi Cuan Kakak: Laku 15 pcs/hari saja = *+${rp(potensi15PcsHari)}/hari* (*${rp(potensi30Hari)}/bulan* bersih ke saldo Affiliate Kakak!)\n\n` +
      `🎁 *Sampel Gratis Siap Kirim!* Jika Kakak tertarik masukkan ke Showcase / Keranjang Kuning, balas pesan ini dengan alamat pengiriman ya Kak. Terima kasih! 🙏`;

    return {
      komisiPct,
      komisiPerPcsRp,
      potensi15PcsHari,
      potensi30Hari,
      scriptText,
    };
  }, [
    skuNama,
    hargaJualFinal,
    diskonCoretPct,
    briefKomisiPct,
    briefKeunggulanProduk,
  ]);

  const handleCopyCreatorBrief = () => {
    navigator.clipboard.writeText(creatorBriefData.scriptText);
    setCopiedCreatorBrief(true);
    onToast('Skrip Undangan Affiliate Kreator berhasil disalin!');
    setTimeout(() => setCopiedCreatorBrief(false), 2200);
  };

  return (
    <div className="space-y-6">
      {/* MODUL 06: GENERATOR HARGA CORET PSIKOLOGIS (STRIKE-THROUGH PRICE MATRIX) */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-orange-500/30 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3.5">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-orange-400 uppercase tracking-wide">
              <Tag className="w-3.5 h-3.5" />
              <span>Modul 06 · Psychological Strike-Through Generator</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Generator &ldquo;Harga Coret&rdquo; Seller Centre (Diskon 15% – 60%)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Agar harga jual akhir tetap jatuh aman di{' '}
              <strong className="text-amber-300 font-mono">
                {rp(hargaJualFinal)}
              </strong>
              , berikut adalah{' '}
              <strong className="text-white">Harga Sebelum Diskon</strong> yang
              wajib Anda ketik di Seller Centre:
            </p>
          </div>

          <button
            type="button"
            onClick={handleCopyStrikeThroughTable}
            className="bg-orange-500/15 hover:bg-orange-500/25 border border-orange-500/35 text-orange-300 font-bold text-xs px-3.5 py-2 rounded-xl inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
          >
            {copiedCoretTable ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300">Tabel Disalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Salin Panduan Harga Coret</span>
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {strikeThroughMatrix.map((item) => {
            const isActive = diskonCoretPct === item.pct;
            return (
              <div
                key={item.pct}
                className={`p-3 rounded-xl border flex flex-col justify-between space-y-2.5 transition-all ${
                  isActive
                    ? 'bg-orange-500/15 border-orange-400/70 ring-1 ring-orange-500/30'
                    : 'bg-[#090D16] border-slate-800/90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded font-mono">
                      Diskon {item.pct}%
                    </span>
                    {isActive && (
                      <span className="text-[9px] font-bold text-emerald-400">
                        AKTIF
                      </span>
                    )}
                  </div>
                  <div className="mt-2">
                    <span className="text-[10px] text-slate-400 block">
                      Ketik Harga Awal:
                    </span>
                    <div className="text-sm font-mono font-extrabold text-white tabular-nums line-through decoration-rose-500/80">
                      {rp(item.hargaCoretMurni)}
                    </div>
                  </div>
                  <div className="mt-1.5 pt-1.5 border-t border-slate-800/80">
                    <span className="text-[10px] text-slate-400 block">
                      Opsi Cantik (.900):
                    </span>
                    <div className="text-xs font-mono font-bold text-amber-300 tabular-nums">
                      {rp(item.hargaCoretCantik)}
                    </div>
                    <span className="text-[9px] text-slate-500 block">
                      Jatuh di: {rp(item.hargaJatuhCantik)}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onApplyDiskonCoret(item.pct);
                    onToast(
                      `Diskon Coret ${item.pct}% (Harga Awal ${rp(item.hargaCoretMurni)}) diterapkan!`
                    );
                  }}
                  className={`w-full py-1.5 px-2 rounded-lg text-[10px] font-bold transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-orange-500 text-slate-950'
                      : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200'
                  }`}
                >
                  {isActive ? 'Sedang Dipakai' : `Pakai Diskon ${item.pct}%`}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODUL 07: KALKULATOR BIAYA OPERASIONAL TOKO (OVERHEAD) & TARGET GAJI OWNER */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-sky-500/30 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-4">
          <div className="border-b border-slate-800/80 pb-3">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-sky-400 uppercase tracking-wide">
              <Building2 className="w-3.5 h-3.5" />
              <span>Modul 07 · Store Overhead &amp; Owner Salary Planner</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Kalkulator Biaya Tetap Toko (Overhead) &amp; Target Gaji Owner
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Jangan sampai untung produk habis untuk bayar listrik &amp; admin!
              Hitung berapa paket/hari yang wajib keluar untuk menutup operasional
              dan menggaji Anda sebagai Owner:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                Gaji Admin / Packing (Rp/Bln)
              </label>
              <input
                type="number"
                value={opexGajiStaff}
                onChange={(e) =>
                  setOpexGajiStaff(Math.max(0, parseFloat(e.target.value) || 0))
                }
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                Listrik, WiFi &amp; Kuota (Rp/Bln)
              </label>
              <input
                type="number"
                value={opexListrikInternet}
                onChange={(e) =>
                  setOpexListrikInternet(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                Sewa Gudang / Lakban / ATK
              </label>
              <input
                type="number"
                value={opexSewaAtk}
                onChange={(e) =>
                  setOpexSewaAtk(Math.max(0, parseFloat(e.target.value) || 0))
                }
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-emerald-400 mb-1">
                Target Gaji Bersih Owner (Rp)
              </label>
              <input
                type="number"
                value={targetGajiOwner}
                onChange={(e) =>
                  setTargetGajiOwner(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-full bg-emerald-950/25 text-emerald-300 p-2.5 rounded-xl border border-emerald-500/40 font-mono font-extrabold text-xs tabular-nums"
              />
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Total Beban Tetap Toko / Bln
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-rose-400 mt-1 tabular-nums">
                {rp(overheadResult.totalFixedCostBulan)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Diluar modal HPP barang
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Titik Impas Toko (BEP Opex)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                {overheadResult.bepTokoHariPcs} Pcs / Hari
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                ({overheadResult.bepTokoBulanPcs.toLocaleString('id-ID')} pcs/bln
                agar tidak rugi)
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-emerald-500/30">
              <span className="text-[11px] text-emerald-300 font-semibold block">
                Wajib Laku (Opex + Gaji Owner)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-emerald-400 mt-1 tabular-nums">
                {overheadResult.targetOwnerHariPcs} Pcs / Hari
              </div>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                Total {overheadResult.targetOwnerBulanPcs.toLocaleString('id-ID')}{' '}
                pcs/bulan
              </span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-sky-950/40 via-[#090D16] to-[#090D16] p-4 sm:p-5 rounded-2xl border border-sky-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold text-sky-300 uppercase tracking-wide block">
                Target Omzet Bulanan (Menutup Opex + Gaji Owner{' '}
                {rp(targetGajiOwner)})
              </span>
              <div className="text-2xl sm:text-3xl font-mono font-extrabold text-white mt-1 tabular-nums">
                {rp(overheadResult.omzetWajibBulan)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Dengan profit produk saat ini ({rp(profitBersih)}/pcs), pastikan
                minimal{' '}
                <strong className="text-emerald-300 font-mono">
                  {overheadResult.targetOwnerHariPcs} resi/hari
                </strong>{' '}
                terkirim.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                onSyncOpexAndGajiToSimulasi(
                  overheadResult.totalFixedCostBulan,
                  targetGajiOwner
                );
              }}
              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer shrink-0 inline-flex items-center gap-1.5"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Sinkronkan ke Menu Simulasi</span>
            </button>
          </div>
        </div>
      </div>

      {/* MODUL 08: SIMULATOR PERPUTARAN MODAL KERJA & DANA TERTAHAN (CASHFLOW & RESTOCK GUARD) */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-amber-500/30 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-4">
          <div className="border-b border-slate-800/80 pb-3">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wide">
              <Wallet className="w-3.5 h-3.5" />
              <span>Modul 08 · Working Capital &amp; Settlement Guard</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Simulator Perputaran Modal Kerja &amp; Dana Tertahan Marketplace
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Mengapa toko yang ramai order sering kehabisan uang tunai saat mau
              kulakan lagi? Karena dana penjualan masih mengendap di proses
              pengiriman (*settlement*). Hitung kebutuhan modal kerja aman Anda:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div>
              <label className="block text-[10px] font-semibold text-slate-300 mb-1">
                Order Rata-Rata / Hari
              </label>
              <input
                type="number"
                value={cfOrderHari}
                onChange={(e) =>
                  setCfOrderHari(Math.max(1, parseFloat(e.target.value) || 1))
                }
                className="w-full bg-[#090D16] text-amber-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-slate-300 mb-1">
                Lama Dana Cair (Hari)
              </label>
              <input
                type="number"
                value={cfSettlementHari}
                onChange={(e) =>
                  setCfSettlementHari(
                    Math.max(1, parseFloat(e.target.value) || 1)
                  )
                }
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-slate-300 mb-1">
                Waktu Tunggu Restock (Hr)
              </label>
              <input
                type="number"
                value={cfRestockLeadHari}
                onChange={(e) =>
                  setCfRestockLeadHari(
                    Math.max(1, parseFloat(e.target.value) || 1)
                  )
                }
                className="w-full bg-[#090D16] text-sky-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
              />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#090D16] border border-slate-800/80 text-[11px] text-slate-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              Selama <strong className="text-white">{cfSettlementHari} hari</strong>{' '}
              pengiriman hingga pembeli klik &ldquo;Pesanan Diterima&rdquo;, ada{' '}
              <strong className="text-amber-300">
                {cashflowResult.paketTertahan} paket
              </strong>{' '}
              yang uangnya belum masuk ke rekening Anda.
            </span>
          </div>
        </div>

        <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Saldo Mengendap di MP ({cfSettlementHari} Hr)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                {rp(cashflowResult.danaCairTertahan)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Modal HPP terikat: {rp(cashflowResult.modalHppTertahan)}
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Buffer Stok Tunggu Pabrik ({cfRestockLeadHari} Hr)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-sky-300 mt-1 tabular-nums">
                {rp(cashflowResult.modalBufferRestockRp)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Wajib cadangan {cashflowResult.stokBufferRestockPcs} pcs di gudang
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-amber-500/30">
              <span className="text-[11px] text-amber-300 font-semibold block">
                Siklus Putaran Kas (Cash Cycle)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-white mt-1 tabular-nums">
                {cashflowResult.totalSiklusHari} Hari
              </div>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                Dari kulakan s/d saldo cair
              </span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-amber-950/40 via-[#090D16] to-[#090D16] p-4 sm:p-5 rounded-2xl border border-amber-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5" />
                <span>
                  Total Modal Kerja Aman Wajib Siap (Agar Stok Tidak Pernah
                  Kosong)
                </span>
              </span>
              <div className="text-2xl sm:text-3xl font-mono font-extrabold text-emerald-400 mt-1 tabular-nums">
                {rp(cashflowResult.totalModalKerjaAman)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Siapkan dana cadangan ini untuk membiayai{' '}
                <strong className="text-white">
                  {cashflowResult.paketTertahan +
                    cashflowResult.stokBufferRestockPcs}{' '}
                  pcs
                </strong>{' '}
                selama menunggu pencairan saldo marketplace &amp; pengiriman
                restock pabrik.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* MODUL 09: DETEKTOR KEBOCORAN DANA CAIR (AUDIT PENCAIRAN AKTUAL SELLER CENTRE) */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-rose-500/30 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-4">
          <div className="border-b border-slate-800/80 pb-3">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-rose-400 uppercase tracking-wide">
              <Search className="w-3.5 h-3.5" />
              <span>Modul 09 · Settlement Leakage &amp; Discrepancy Detector</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Detektor &ldquo;Kebocoran Dana Cair&rdquo; (Audit Penghasilan Aktual)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Merasa dana cair di menu <em>Penghasilan Saya</em> lebih kecil dari
              seharusnya? Masukkan angka Dana Cair Aktual dari 1 nomor pesanan
              untuk melacak kebocorannya:
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-medium text-slate-300">
                  Nominal Dana Cair Aktual di Saldo (Rp):
                </label>
                <span className="text-[10px] font-mono text-emerald-400">
                  Seharusnya: {rp(auditDanaCairResult.expectedCair)}
                </span>
              </div>
              <input
                type="number"
                value={auditDanaCairResult.currentActual}
                onChange={(e) =>
                  setActualSettlementRp(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-full bg-[#090D16] text-amber-300 p-3 rounded-xl border border-slate-800 font-mono font-extrabold text-sm tabular-nums"
              />
            </div>

            <div className="p-3 rounded-xl bg-[#090D16] border border-slate-800 text-[11px] text-slate-300 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{auditDanaCairResult.diagnosa}</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Selisih / Bocor per Pesanan
              </span>
              <div
                className={`text-base sm:text-lg font-mono font-extrabold mt-1 tabular-nums ${
                  auditDanaCairResult.selisihBocorRp > 0
                    ? 'text-rose-400'
                    : 'text-emerald-400'
                }`}
              >
                {auditDanaCairResult.selisihBocorRp > 0
                  ? `-${rp(auditDanaCairResult.selisihBocorRp)}`
                  : 'Rp 0 (Aman)'}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Dari target cair {rp(auditDanaCairResult.expectedCair)}
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Total Potongan Aktual (%)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                {auditDanaCairResult.potonganAktualPct}%
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Target potongan awal: {auditDanaCairResult.potonganResmiPct}%
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Sisa Laba Riil Pesanan Ini
              </span>
              <div
                className={`text-base sm:text-lg font-mono font-extrabold mt-1 tabular-nums ${
                  auditDanaCairResult.sisaProfitAktual >= 0
                    ? 'text-emerald-400'
                    : 'text-rose-400'
                }`}
              >
                {rp(auditDanaCairResult.sisaProfitAktual)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Setelah dipotong HPP &amp; iklan
              </span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-rose-950/30 via-[#090D16] to-[#090D16] p-4 sm:p-5 rounded-2xl border border-rose-500/30">
            <span className="text-[11px] font-bold text-rose-300 uppercase tracking-wide block">
              Potensi Kebocoran Bulanan Jika Tidak Diperbaiki (Pada 500 Resi/Bln)
            </span>
            <div className="text-2xl sm:text-3xl font-mono font-extrabold text-rose-400 mt-1 tabular-nums">
              {auditDanaCairResult.selisihBocorRp > 0
                ? `-${rp(auditDanaCairResult.selisihBocorRp * 500)} / bulan`
                : 'Rp 0 (Tidak Ada Kebocoran)'}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Selalu audit minimal 3 sampel pesanan per minggu di menu Rincian
              Penghasilan Seller Centre untuk mencegah kebocoran margin.
            </p>
          </div>
        </div>
      </div>

      {/* MODUL 10: KALKULATOR HARGA MULTI-VARIAN UKURAN / KEMASAN (S-XXL / 30ML-100ML) */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-indigo-500/30 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-indigo-400 uppercase tracking-wide">
              <Layers className="w-3.5 h-3.5" />
              <span>Modul 10 · Multi-Variant Size &amp; Tier Pricing Engine</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Kalkulator Harga Multi-Varian Ukuran / Kemasan (S–XXL / 20ml–100ml)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Punya varian ukuran yang HPP-nya naik bertahap? Hitung otomatis
              Harga Jual &amp; Harga Coret tiap ukuran agar margin tetap utuh dan
              tidak melanggar batas rasio harga varian Shopee/TikTok:
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <div className="flex bg-[#090D16] p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setVariantMode('fashion')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  variantMode === 'fashion'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                👕 Ukuran S–XXL
              </button>
              <button
                type="button"
                onClick={() => setVariantMode('beauty')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  variantMode === 'beauty'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                💄 Kemasan ml
              </button>
            </div>

            <div className="bg-[#090D16] px-3 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2">
              <span className="text-[11px] text-slate-400">
                Selisih HPP/Tingkat:
              </span>
              <input
                type="number"
                value={hppStepPerSize}
                onChange={(e) =>
                  setHppStepPerSize(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-24 bg-[#0E131F] text-amber-300 px-2 py-1 rounded-lg border border-slate-700 font-mono font-bold text-xs text-center"
              />
            </div>

            <button
              type="button"
              onClick={handleCopyVariantTable}
              className="bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/35 text-indigo-300 font-bold text-xs px-3.5 py-2 rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedVariantTable ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Disalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Tabel Varian</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {variantMatrixResult.rows.map((v) => (
            <div
              key={v.label}
              className="bg-[#090D16] p-4 rounded-xl border border-slate-800/90 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-extrabold text-white">
                  {v.label}
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  HPP {rp(v.hppVarian)}
                </span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block">
                  Harga Coret (Diskon {diskonCoretPct}%):
                </span>
                <div className="text-xs font-mono text-slate-400 line-through decoration-rose-500/80">
                  {rp(v.hargaCoretVarian)}
                </div>
              </div>

              <div>
                <span className="text-[10px] text-indigo-300 font-semibold block">
                  Harga Jual Tayang Varian:
                </span>
                <div className="text-lg font-mono font-extrabold text-amber-300 tabular-nums">
                  {rp(v.hargaJualVarian)}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex justify-between items-center text-[11px]">
                <span className="text-slate-400">Profit Bersih:</span>
                <strong className="font-mono text-emerald-400">
                  {rp(v.labaVarian)}/pcs
                </strong>
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 rounded-xl bg-[#090D16] border border-slate-800/90 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-slate-400">
            Rasio Rentang Harga Varian Termahal vs Termurah:{' '}
            <strong className="text-white font-mono">
              {variantMatrixResult.priceRatio}x lipat
            </strong>
          </span>
          <span
            className={`font-bold ${
              variantMatrixResult.isRatioSafe
                ? 'text-emerald-400'
                : 'text-rose-400'
            }`}
          >
            {variantMatrixResult.isRatioSafe
              ? '✅ Aman! Sesuai aturan batas rasio varian Shopee & TikTok Shop (< 5x)'
              : '⚠️ Perhatian: Rentang harga varian terlalu jauh (> 4.5x), pisahkan jadi link produk tersendiri!'}
          </span>
        </div>
      </div>

      {/* MODUL 11: KALKULATOR LIVE STREAMING HOST & SEWA STUDIO (TIKTOK / SHOPEE LIVE BEP) */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-rose-500/30 grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 space-y-4">
          <div className="border-b border-slate-800/80 pb-3">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-rose-400 uppercase tracking-wide">
              <Video className="w-3.5 h-3.5" />
              <span>Modul 11 · Live Streaming Host &amp; Session BEP</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Kalkulator Gaji Host Live Streaming &amp; Target BEP per Sesi
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Sewa Host Live per jam tapi takut boncos kalau penonton sepi?
              Hitung minimal order wajib per sesi Live agar biaya host tertutup
              dan toko tetap untung bersih:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Durasi 1 Sesi Live (Jam):
              </label>
              <input
                type="number"
                min={1}
                value={liveDurasiJam}
                onChange={(e) =>
                  setLiveDurasiJam(Math.max(1, parseFloat(e.target.value) || 1))
                }
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Fee Host Live / Jam (Rp):
              </label>
              <input
                type="number"
                min={0}
                value={liveFeeHostPerJam}
                onChange={(e) =>
                  setLiveFeeHostPerJam(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-full bg-[#090D16] text-amber-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Bonus Komisi Host (% GMV):
              </label>
              <input
                type="number"
                step="0.5"
                min={0}
                value={liveBonusHostPct}
                onChange={(e) =>
                  setLiveBonusHostPct(
                    Math.max(0, parseFloat(e.target.value) || 0)
                  )
                }
                className="w-full bg-[#090D16] text-rose-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Estimasi Order / Sesi (Pcs):
              </label>
              <input
                type="number"
                min={1}
                value={liveTargetOrderSesi}
                onChange={(e) =>
                  setLiveTargetOrderSesi(
                    Math.max(1, parseFloat(e.target.value) || 1)
                  )
                }
                className="w-full bg-[#090D16] text-emerald-400 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
              />
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Minimal Order BEP Sesi Live
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                Wajib {liveSessionResult.bepOrderSesi} Pcs
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Untuk menutup fee jam {rp(liveSessionResult.biayaTetapHostSesi)}
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Total Biaya Host (Fee + Bonus)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-rose-400 mt-1 tabular-nums">
                {rp(liveSessionResult.totalBiayaLiveSesi)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Efisiensi ROAS Live: {liveSessionResult.roasLiveSession}x
              </span>
            </div>

            <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">
                Omzet Kotor Sesi ({liveSessionResult.jam} Jam)
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-white mt-1 tabular-nums">
                {rp(liveSessionResult.omzetSesiLive)}
              </div>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Pada {liveSessionResult.orderSesi} pcs checkout sukses
              </span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-rose-950/35 via-[#090D16] to-[#090D16] p-4 sm:p-5 rounded-2xl border border-rose-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[11px] font-bold text-rose-300 uppercase tracking-wide block">
                Laba Bersih Toko per Sesi Live ({liveSessionResult.jam} Jam)
              </span>
              <div
                className={`text-2xl sm:text-3xl font-mono font-extrabold mt-1 tabular-nums ${
                  liveSessionResult.netProfitSesiLive >= 0
                    ? 'text-emerald-400'
                    : 'text-rose-400'
                }`}
              >
                {rp(liveSessionResult.netProfitSesiLive)} / sesi
              </div>
              <span className="text-xs text-slate-400 block mt-1">
                Estimasi rutin 1 sesi/hari (30 hari):{' '}
                <strong className="text-white font-mono">
                  {rp(liveSessionResult.netProfitBulananLive)} / bulan
                </strong>
              </span>
            </div>
            <div className="text-xs text-slate-300 bg-[#0E131F] px-3.5 py-2.5 rounded-xl border border-slate-800 max-w-xs">
              💡 Berikan target minimal{' '}
              <strong className="text-amber-300">
                {liveSessionResult.bepOrderSesi + 5} pcs checkout
              </strong>{' '}
              kepada Host Live Anda sebagai KPI wajib di setiap sesi{' '}
              {liveSessionResult.jam} jam.
            </div>
          </div>
        </div>
      </div>

      {/* MODUL 12: SIMULATOR KEAMANAN VOUCHER MINIMUM BELANJA BERTINGKAT */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-emerald-500/30 space-y-4">
        <div className="border-b border-slate-800/80 pb-3.5">
          <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 uppercase tracking-wide">
            <TicketPercent className="w-3.5 h-3.5" />
            <span>Modul 12 · Tiered Minimum Spend Voucher Safety Guard</span>
          </div>
          <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
            Simulator Keamanan Voucher Minimum Belanja Bertingkat (Anti-Bocor
            Double Diskon)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Cegah kerugian akibat pembeli menggabungkan Harga Diskon + Voucher
            Toko! Atur nominal voucher untuk pembelian 1 pcs, 2 pcs, dan 3 pcs
            beserta batas maksimal voucher aman:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Voucher Tier 1 (Min. Beli 1 Pcs) Rp:
            </label>
            <input
              type="number"
              min={0}
              value={voucherTier1DiskonRp}
              onChange={(e) =>
                setVoucherTier1DiskonRp(
                  Math.max(0, parseFloat(e.target.value) || 0)
                )
              }
              className="w-full bg-[#090D16] text-emerald-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Voucher Tier 2 (Min. Beli 2 Pcs) Rp:
            </label>
            <input
              type="number"
              min={0}
              value={voucherTier2DiskonRp}
              onChange={(e) =>
                setVoucherTier2DiskonRp(
                  Math.max(0, parseFloat(e.target.value) || 0)
                )
              }
              className="w-full bg-[#090D16] text-amber-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Voucher Tier 3 (Min. Beli 3 Pcs) Rp:
            </label>
            <input
              type="number"
              min={0}
              value={voucherTier3DiskonRp}
              onChange={(e) =>
                setVoucherTier3DiskonRp(
                  Math.max(0, parseFloat(e.target.value) || 0)
                )
              }
              className="w-full bg-[#090D16] text-sky-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {voucherGuardResult.map((tier) => (
            <div
              key={tier.tierName}
              className="bg-[#090D16] p-4 rounded-xl border border-slate-800 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-extrabold text-white">
                  {tier.tierName}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    tier.isSafe
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {tier.isSafe ? 'AMAN' : 'RAWAN BOCOR'}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Syarat Min. Belanja:</span>
                <strong className="font-mono text-white">
                  {rp(tier.minBelanjaRp)}
                </strong>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Batas Max Voucher Aman:</span>
                <strong className="font-mono text-amber-300">
                  Maks {rp(tier.maxVoucherAmanRp)}
                </strong>
              </div>
              <div className="pt-2 border-t border-slate-800/80 flex justify-between items-center text-xs">
                <span className="text-slate-400">Sisa Laba Bersih Resi:</span>
                <strong
                  className={`font-mono text-sm ${
                    tier.labaBersihResi >= 0
                      ? 'text-emerald-400'
                      : 'text-rose-400'
                  }`}
                >
                  {rp(tier.labaBersihResi)} ({tier.marginPct}%)
                </strong>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODUL 13: GENERATOR SKRIP UNDANGAN AFFILIATE & BRIEF KREATOR SIAP KIRIM */}
      <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-sky-500/30 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3.5">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-sky-400 uppercase tracking-wide">
              <MessageSquareShare className="w-3.5 h-3.5" />
              <span>Modul 13 · Creator Affiliate Invitation &amp; Pitch Generator</span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
              Generator Skrip Undangan Affiliate &amp; Brief Kreator TikTok /
              Shopee
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Buat pesan undangan profesional lengkap dengan simulasi penghasilan
              kreator agar Top Creator tertarik memasukkan produk Anda ke
              Keranjang Kuning / Showcase:
            </p>
          </div>

          <button
            type="button"
            onClick={handleCopyCreatorBrief}
            className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs px-4 py-2.5 rounded-xl inline-flex items-center justify-center gap-1.5 transition-colors shrink-0 cursor-pointer"
          >
            {copiedCreatorBrief ? (
              <>
                <Check className="w-4 h-4" />
                <span>Skrip Disalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Salin Undangan Kreator</span>
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          <div className="lg:col-span-5 space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Komisi Affiliate yang Ditawarkan (%):
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={briefKomisiPct}
                onChange={(e) =>
                  setBriefKomisiPct(
                    Math.max(1, parseFloat(e.target.value) || 10)
                  )
                }
                className="w-full bg-[#090D16] text-amber-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Poin Keunggulan Produk (Nilai Jual untuk Kreator):
              </label>
              <textarea
                rows={3}
                value={briefKeunggulanProduk}
                onChange={(e) => setBriefKeunggulanProduk(e.target.value)}
                className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 text-xs leading-relaxed"
              />
            </div>

            <div className="bg-[#090D16] p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400">Komisi Kreator per Pcs:</span>
              <strong className="font-mono text-emerald-400 text-sm">
                {rp(creatorBriefData.komisiPerPcsRp)} / pcs ({creatorBriefData.komisiPct}%)
              </strong>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="bg-[#090D16] p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="text-[11px] font-bold text-sky-400 uppercase tracking-wider">
                Preview Pesan Siap Kirim (WhatsApp / DM TikTok Affiliate):
              </div>
              <pre className="text-xs text-slate-200 whitespace-pre-wrap font-sans leading-relaxed bg-[#0E131F] p-3.5 rounded-xl border border-slate-800/90">
                {creatorBriefData.scriptText}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
