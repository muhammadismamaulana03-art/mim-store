import React from 'react';
import {
  Lock,
  Unlock,
  KeyRound,
  Settings,
  Clock,
  Check,
  Crown,
  Store,
  AlertTriangle,
  MessageCircle,
  Smartphone,
  Sun,
  Moon,
} from 'lucide-react';
import { OWNER_CONFIG } from '../utils/licenseAuth';

interface LicenseGateScreenProps {
  handleOpenAdminPrompt: () => void;
  demoExpiredNotice: boolean;
  handleVerifikasiLisensi: (e?: React.FormEvent) => void;
  inputNamaToko: string;
  setInputNamaToko: (v: string) => void;
  inputKodeLisensi: string;
  setInputKodeLisensi: (v: string) => void;
  pesanErrorLisensi: string;
  handleMulaiDemoGratis: () => void;
  waLisensiV5Url: string;
  waLisensiUrl: string;
  isInstalled: boolean;
  handleInstallAplikasi: () => void;
  themeMode: 'dark' | 'light';
  onToggleTheme: () => void;
  demoUsedCount?: number;
}

export const LicenseGateScreen: React.FC<LicenseGateScreenProps> = ({
  handleOpenAdminPrompt,
  demoExpiredNotice,
  handleVerifikasiLisensi,
  inputNamaToko,
  setInputNamaToko,
  inputKodeLisensi,
  setInputKodeLisensi,
  pesanErrorLisensi,
  handleMulaiDemoGratis,
  waLisensiV5Url,
  waLisensiUrl,
  isInstalled,
  handleInstallAplikasi,
  themeMode,
  onToggleTheme,
  demoUsedCount = 0,
}) => {
  const maxDemo = 3;
  const sisaDemo = Math.max(0, maxDemo - demoUsedCount);
  const isDemoHabis = sisaDemo <= 0;

  return (
    <div className="fixed inset-0 z-50 bg-[#06090F]/95 backdrop-blur-2xl overflow-y-auto no-print">
      <div className="min-h-full w-full flex items-center justify-center p-3 sm:p-6">
        <div className="max-w-[470px] w-full bg-[#0E131F] border border-slate-800/90 rounded-2xl p-5 sm:p-8 shadow-[0_24px_64px_rgba(0,0,0,0.65)] relative my-4">
          {/* Top Subtle Highlight Line */}
          <div className="absolute inset-x-8 sm:inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-orange-400/50 to-transparent" />

          {/* Header Row: Edition Metadata, Theme Toggle & Owner Keygen Trigger */}
          <div className="flex flex-wrap justify-between items-center gap-2 mb-5 sm:mb-6">
            <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] font-semibold tracking-wider text-orange-400 uppercase">
              <Lock className="w-3.5 h-3.5 text-orange-400 shrink-0" />
              <span>Commercial SaaS</span>
              <span className="text-slate-600">·</span>
              <span className="font-mono text-amber-300">v4.0 & v5.0</span>
            </div>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onToggleTheme}
                className="inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-[#090D16] border border-slate-800 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer shrink-0"
                title="Ganti Mode Terang / Mode Gelap"
              >
                {themeMode === 'light' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Mode Gelap</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span>Mode Terang</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleOpenAdminPrompt}
                className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs text-slate-500 hover:text-slate-300 transition-colors cursor-pointer shrink-0"
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Keygen Owner</span>
              </button>
            </div>
          </div>

          {/* Brand Title & Subtitle */}
          <div className="mb-5 sm:mb-6">
            <div className="flex items-center gap-3 mb-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-slate-950 font-extrabold text-sm shadow-lg shadow-orange-500/20 shrink-0">
                SM
              </div>
              <div className="min-w-0">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
                  SellerMetrics{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-300">
                    Pro Suite
                  </span>
                </h1>
                <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 truncate">
                  Enterprise Marketplace Profit & Margin Intelligence
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Sistem Kalkulator Anti-Boncos: Hitung HPP, Harga Coret, ROAS GMV
              Max, Komisi Affiliate, Bundling Grosir & Simulasi Profit
              Shopee/TikTok Shop.
            </p>
          </div>

          {/* Demo Expired Notice if applicable */}
          {demoExpiredNotice && (
            <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200">
              <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                Waktu Preview Demo 2 Menit telah selesai (Terpakai{' '}
                <strong>
                  {Math.min(maxDemo, demoUsedCount)}/{maxDemo}x
                </strong>
                ).{' '}
                {isDemoHabis
                  ? 'Kuota Demo Gratis Anda telah habis. Silakan aktifkan Kode Lisensi untuk pemakaian penuh selamanya.'
                  : `Anda masih memiliki sisa ${sisaDemo}x percobaan Demo, atau aktifkan Kode Lisensi untuk akses penuh tanpa batas.`}
              </span>
            </div>
          )}

          {/* Value Stack / Kenapa Harus Beli */}
          <div className="bg-[#090D16] border border-slate-800/80 rounded-xl p-3.5 sm:p-4 my-4 sm:my-5 space-y-2 text-[11px] sm:text-xs text-slate-300">
            <div className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                Rumus Reverse-Margin Akurat + Generator Harga Coret & Psikologis
              </span>
            </div>
            <div className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                ROAS Guard, Simulasi Target Gajian & Katalog SKU (CSV/PDF)
              </span>
            </div>
            <div className="pt-1.5 border-t border-slate-800/80 space-y-1.5">
              <div className="flex items-start gap-2">
                <Crown className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span className="text-amber-300 font-bold">
                  EKSKLUSIF v5.0 ULTIMATE (13 Modul Super Suite):
                </span>
              </div>
              <p className="text-[11px] text-amber-100/80 pl-6 leading-relaxed">
                • Kalkulator Bundling 1 Resi, Multi-Varian (S–XXL) &amp; 4 Marketplace
                <br />• Simulator Iklan GMV Max, Flash Sale &amp; Harga Coret (15%–60%)
                <br />• Kalkulator Gaji Host Live Streaming &amp; Voucher Bertingkat
                <br />• Komisi Affiliate, Sampel Gratis &amp; Skrip Undangan Kreator
                <br />• Overhead Gaji Owner, Modal Tertahan, Audit Dana Cair &amp; Retur COD
              </p>
            </div>
          </div>

          {/* Form Aktivasi Lisensi */}
          <form onSubmit={handleVerifikasiLisensi} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Nama Toko / Brand Anda
              </label>
              <div className="relative">
                <Store className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={inputNamaToko}
                  onChange={(e) => setInputNamaToko(e.target.value)}
                  placeholder="Contoh: Berkah Jaya Official"
                  className="w-full bg-[#090D16] text-white pl-10 pr-4 py-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/15 focus:outline-none text-sm font-medium transition-all placeholder:text-slate-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Kode Lisensi / Serial Key
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={inputKodeLisensi}
                  onChange={(e) => setInputKodeLisensi(e.target.value)}
                  placeholder="Masukkan Kode Lisensi (SM-... atau SM5-...)"
                  className="w-full bg-[#090D16] text-amber-400 pl-10 pr-4 py-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/15 focus:outline-none text-sm font-mono font-bold uppercase tracking-wider transition-all placeholder:text-slate-600 placeholder:font-sans placeholder:normal-case placeholder:tracking-normal"
                />
              </div>
            </div>

            {pesanErrorLisensi && (
              <div className="flex items-start gap-2 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3.5 py-2.5 rounded-xl font-medium">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{pesanErrorLisensi}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold py-3.5 px-4 rounded-xl text-sm shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Unlock className="w-4 h-4 stroke-[2.2] shrink-0" />
              <span>Aktivasi & Buka Aplikasi</span>
            </button>
          </form>

          {/* Divider */}
          <div className="relative flex py-4 items-center">
            <div className="flex-grow border-t border-slate-800/80"></div>
            <span className="flex-shrink mx-3 text-[11px] text-slate-500 font-medium">
              Belum Punya Lisensi?
            </span>
            <div className="flex-grow border-t border-slate-800/80"></div>
          </div>

          {/* Tombol Demo & Beli Lisensi */}
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={handleMulaiDemoGratis}
              disabled={isDemoHabis}
              className={`w-full font-semibold py-2.5 px-3 rounded-xl text-xs border transition-colors flex items-center justify-center gap-2 text-center ${
                isDemoHabis
                  ? 'bg-rose-950/20 border-rose-500/30 text-rose-400 cursor-not-allowed opacity-80'
                  : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700/80 cursor-pointer'
              }`}
            >
              <Clock
                className={`w-3.5 h-3.5 shrink-0 ${
                  isDemoHabis ? 'text-rose-400' : 'text-orange-400'
                }`}
              />
              <span>
                {isDemoHabis
                  ? 'Kuota Demo Gratis Habis (3/3 Terpakai) — Silakan Beli Lisensi'
                  : `Coba Demo Gratis 2 Menit (Sisa ${sisaDemo}x dari ${maxDemo}x Percobaan)`}
              </span>
            </button>

            <a
              href={waLisensiV5Url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold py-3 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm transition-all flex flex-wrap items-center justify-between gap-2 shadow-lg shadow-amber-500/20 relative overflow-hidden"
            >
              <span className="inline-flex items-center gap-2">
                <Crown className="w-4 h-4 shrink-0" />
                <span>Beli v5.0 Ultimate (Best Seller)</span>
              </span>
              <span className="bg-slate-950/85 px-2.5 py-1 rounded-lg text-amber-300 font-mono font-bold text-xs ml-auto">
                <s className="text-slate-400 text-[10px] mr-1.5 font-normal">
                  {OWNER_CONFIG.hargaNormalCoret}
                </s>
                <span>{OWNER_CONFIG.hargaLisensiV5}</span>
              </span>
            </a>

            <a
              href={waLisensiUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-600/90 hover:bg-emerald-500 text-white font-bold py-2.5 px-3.5 sm:px-4 rounded-xl text-xs transition-colors flex flex-wrap items-center justify-between gap-2 border border-emerald-500/30"
            >
              <span className="inline-flex items-center gap-2">
                <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                <span>Beli Lisensi Standar v4.0 Pro</span>
              </span>
              <span className="bg-slate-950/35 px-2.5 py-0.5 rounded-lg text-emerald-200 font-mono font-bold text-xs ml-auto">
                <span>{OWNER_CONFIG.hargaLisensi}</span>
              </span>
            </a>
            {!isInstalled && (
              <button
                type="button"
                onClick={handleInstallAplikasi}
                className="w-full bg-[#090D16] hover:bg-slate-900 text-indigo-300 font-semibold py-2.5 px-3 rounded-xl text-xs border border-indigo-500/30 transition-colors flex items-center justify-center gap-2 cursor-pointer text-center"
              >
                <Smartphone className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span>
                  Install Aplikasi ke Layar Utama HP / Laptop (Bisa Offline)
                </span>
              </button>
            )}
          </div>

          <p className="text-[11px] text-center text-slate-500 mt-4 leading-relaxed">
            Powered by{' '}
            <strong className="text-slate-300 font-semibold">
              {OWNER_CONFIG.brandName}
            </strong>{' '}
            · Lisensi Sekali Bayar Tanpa Langganan
          </p>
        </div>
      </div>
    </div>
  );
};
