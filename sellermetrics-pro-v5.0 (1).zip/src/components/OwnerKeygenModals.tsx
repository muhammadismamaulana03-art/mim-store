import React from 'react';
import {
  KeyRound,
  X,
  Crown,
  Check,
  Copy,
  Trash2,
  Upload,
  Download,
  MessageCircle,
} from 'lucide-react';
import { BuyerLicenseRecord } from '../data/marketplacePresets';
import { OWNER_CONFIG, formatBuyerWaNumber } from '../utils/licenseAuth';

interface OwnerKeygenModalsProps {
  showPinDialog: boolean;
  setShowPinDialog: (v: boolean) => void;
  adminPinInput: string;
  setAdminPinInput: (v: string) => void;
  adminPinError: string;
  handleVerifyAdminPin: (e: React.FormEvent) => void;
  showKeygenModal: boolean;
  setShowKeygenModal: (v: boolean) => void;
  keygenTier: 'v4' | 'v5';
  setKeygenTier: (v: 'v4' | 'v5') => void;
  keygenNamaInput: string;
  setKeygenNamaInput: (v: string) => void;
  keygenWaInput: string;
  setKeygenWaInput: (v: string) => void;
  currentKeygenCode: string;
  keygenCopied: boolean;
  handleSalinPaketLisensiPembeli: () => void;
  handleKirimWaPembeliLangsung: () => void;
  buyerHistory: BuyerLicenseRecord[];
  copiedHistoryId: string;
  handleSalinUlangRiwayatPembeli: (record: BuyerLicenseRecord) => void;
  handleKirimWaDariRiwayat: (record: BuyerLicenseRecord) => void;
  handleHapusRiwayatPembeli: (id: string) => void;
  handleExportRiwayatPembeliCSV: () => void;
  onResetDemoQuota?: () => void;
}

export const OwnerKeygenModals: React.FC<OwnerKeygenModalsProps> = ({
  showPinDialog,
  setShowPinDialog,
  adminPinInput,
  setAdminPinInput,
  adminPinError,
  handleVerifyAdminPin,
  showKeygenModal,
  setShowKeygenModal,
  keygenTier,
  setKeygenTier,
  keygenNamaInput,
  setKeygenNamaInput,
  keygenWaInput,
  setKeygenWaInput,
  currentKeygenCode,
  keygenCopied,
  handleSalinPaketLisensiPembeli,
  handleKirimWaPembeliLangsung,
  buyerHistory,
  copiedHistoryId,
  handleSalinUlangRiwayatPembeli,
  handleKirimWaDariRiwayat,
  handleHapusRiwayatPembeli,
  handleExportRiwayatPembeliCSV,
  onResetDemoQuota,
}) => {
  const [copiedPromoScript, setCopiedPromoScript] = React.useState<string>('');

  const handleCopySalesScript = (type: 'broadcast' | 'followup' | 'upsell') => {
    const appLink =
      typeof window !== 'undefined' ? window.location.href : 'https://sellermetrics.app';
    const targetStore = keygenNamaInput.trim() || 'Kak';
    let script = '';

    if (type === 'broadcast') {
      script =
        `🔥 *BANYAK ORDERAN TAPI SALDO CAIR KOK DIKIT? AWAS BONCOS POTONGAN ADMIN 2026!* 🔥\n\n` +
        `Buat teman-teman Seller Shopee, TikTok Shop & Tokopedia, jangan asal pasang harga jual atau ikut Flash Sale sebelum dihitung pakai *SellerMetrics Pro v5.0*!\n\n` +
        `✅ Hitung otomatis Harga Jual Anti-Boncos & Harga Coret Seller Centre\n` +
        `✅ Simulator ROAS Iklan GMV Max, Komisi Affiliate & BEP Sampel Gratis\n` +
        `✅ Kalkulator Paket Bundling 1 Resi, Gaji Owner & Detektor Bocor Dana Cair\n` +
        `✅ Bisa dipakai di HP & Laptop (Bisa Offline, Sekali Bayar Tanpa Langganan!)\n\n` +
        `👉 *Coba Demo Gratis 2 Menit langsung di sini:*\n${appLink}\n\n` +
        `💬 Mau amankan Lisensi Full Akses? Balas pesan ini ya!`;
    } else if (type === 'followup') {
      script =
        `Halo *${targetStore}* 👋, bagaimana tadi setelah coba *Demo SellerMetrics Pro*-nya? Sangat membantu untuk hitung HPP, ROAS GMV Max, dan jaga margin toko kan?\n\n` +
        `Saat ini sedang ada *Promo Lisensi Sekali Bayar (Aktif Selamanya)*:\n` +
        `👑 *Paket v5.0 Ultimate (Full 13 Modul Eksekutif):* *${OWNER_CONFIG.hargaLisensiV5}* _(Harga Normal ${OWNER_CONFIG.hargaNormalCoret})_ — *BEST SELLER*\n` +
        `⚡ *Paket v4.0 Pro (Standar):* *${OWNER_CONFIG.hargaLisensi}*\n\n` +
        `Mau saya buatkan Kode Lisensi resmi untuk nama toko *${targetStore}* sekarang? 😊`;
    } else {
      script =
        `Halo Owner Toko *${targetStore}* 👋, kabar gembira! Kini telah rilis *Update Besar SellerMetrics v5.0 Ultimate (13 Modul Super Suite)*:\n\n` +
        `✨ *Fitur Baru Eksklusif v5.0 (13 Modul Lengkap):*\n` +
        `1. Kalkulator Paket Bundling 1 Resi, Multi-Varian Ukuran (S–XXL) & Komparasi 4 Marketplace\n` +
        `2. Simulator Budget Iklan GMV Max & Komisi Affiliate + BEP Sampel Gratis\n` +
        `3. Generator Harga Coret Seller Centre (15%–60%) & Simulator Flash Sale\n` +
        `4. Kalkulator Gaji Host Live Streaming, Keamanan Voucher Bertingkat & Skrip Undangan Kreator\n` +
        `5. Kalkulator Overhead Gaji Owner, Modal Kerja Tertahan & Detektor Bocor Dana Cair\n\n` +
        `Khusus pengguna v4.0 seperti *${targetStore}*, cukup tambah biaya upgrade *${OWNER_CONFIG.hargaUpgradeV5} saja* (sekali bayar selamanya). Mau saya aktifkan kode upgrade *SM5-...* sekarang? 🚀`;
    }

    navigator.clipboard.writeText(script);
    setCopiedPromoScript(type);
    setTimeout(() => setCopiedPromoScript(''), 2200);
  };

  return (
    <>
      {/* MODAL PIN VERIFICATION FOR OWNER KEYGEN */}
      {showPinDialog && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md overflow-y-auto no-print">
          <div className="min-h-full w-full flex items-center justify-center p-4">
            <div className="max-w-sm w-full bg-[#0E131F] border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-indigo-400" />
                  <h3 className="text-sm font-bold text-white">
                    Verifikasi Akses Pemilik
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowPinDialog(false)}
                  className="text-slate-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Masukkan Master PIN Rahasia Pemilik untuk membuka panel
                generator lisensi pembeli (Keygen):
              </p>
              <form onSubmit={handleVerifyAdminPin} className="space-y-3">
                <input
                  type="password"
                  autoFocus
                  value={adminPinInput}
                  onChange={(e) => setAdminPinInput(e.target.value)}
                  placeholder="Masukkan Master PIN..."
                  className="w-full bg-[#090D16] text-white px-3.5 py-2.5 rounded-xl border border-slate-800 focus:border-indigo-500 focus:outline-none text-sm font-mono"
                />
                {adminPinError && (
                  <p className="text-xs text-rose-400">{adminPinError}</p>
                )}
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowPinDialog(false)}
                    className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    Buka Keygen
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL KEYGEN RAHASIA PEMILIK (OWNER PANEL) */}
      {showKeygenModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md overflow-y-auto no-print">
          <div className="min-h-full w-full flex items-center justify-center p-4">
            <div className="max-w-lg w-full bg-[#0E131F] border border-indigo-500/35 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-5 my-4">
              <div className="flex justify-between items-start gap-3 border-b border-slate-800/80 pb-4">
                <div>
                  <div className="text-[11px] font-semibold text-indigo-400 tracking-wide">
                    Owner Control Panel · License Generator
                  </div>
                  <h3 className="text-base sm:text-lg font-extrabold text-white mt-0.5">
                    Generator Lisensi Pembeli (Keygen)
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowKeygenModal(false)}
                  className="text-slate-400 hover:text-white text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-800 transition-colors inline-flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Tutup</span>
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Pilih tingkatan paket lisensi lalu ketik nama toko & nomor WA
                pembeli. Sistem akan membuat{' '}
                <strong className="text-slate-200">Kode Lisensi Unik</strong>{' '}
                yang terkunci khusus untuk nama toko tersebut.
              </p>

              {/* Pilihan Paket Lisensi (v4.0 Pro vs v5.0 Ultimate) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setKeygenTier('v4')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    keygenTier === 'v4'
                      ? 'border-orange-500/60 bg-orange-500/10'
                      : 'border-slate-800 bg-[#090D16]/70 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-white">
                      Lisensi Standar v4.0
                    </span>
                    <span className="text-[11px] font-mono font-bold text-orange-400">
                      {OWNER_CONFIG.hargaLisensi}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Kode <code className="text-orange-300">SM-...</code> (Fitur
                    v5.0 terkunci untuk upsell)
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setKeygenTier('v5')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    keygenTier === 'v5'
                      ? 'border-amber-400/70 bg-amber-500/15'
                      : 'border-slate-800 bg-[#090D16]/70 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-amber-300 inline-flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5" />
                      <span>Ultimate v5.0 / Upgrade</span>
                    </span>
                    <span className="text-[11px] font-mono font-bold text-emerald-400">
                      {OWNER_CONFIG.hargaLisensiV5}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Kode <code className="text-amber-300">SM5-...</code> (Buka
                    semua fitur v4.0 + v5.0)
                  </p>
                </button>
              </div>

              <div className="space-y-3.5 bg-[#090D16] p-4 rounded-xl border border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Nama Toko Pembeli:
                    </label>
                    <input
                      type="text"
                      value={keygenNamaInput}
                      onChange={(e) => setKeygenNamaInput(e.target.value)}
                      placeholder="Misal: Hijab Cantik Store"
                      className="w-full bg-[#0E131F] text-white px-3.5 py-2.5 rounded-xl border border-slate-700/80 text-sm font-semibold focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-emerald-300 mb-1.5">
                      No. WhatsApp Pembeli (Opsional):
                    </label>
                    <input
                      type="tel"
                      value={keygenWaInput}
                      onChange={(e) => setKeygenWaInput(e.target.value)}
                      placeholder="Misal: 081234567890"
                      className="w-full bg-[#0E131F] text-emerald-300 px-3.5 py-2.5 rounded-xl border border-slate-700/80 text-sm font-mono focus:outline-none focus:border-emerald-500 placeholder:font-sans placeholder:text-slate-600"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex flex-col gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 block">
                      Kode Lisensi{' '}
                      {keygenTier === 'v5' ? 'v5.0 Ultimate' : 'v4.0 Pro'}{' '}
                      Dihasilkan:
                    </span>
                    <span className="text-base sm:text-lg font-mono font-extrabold text-amber-400 tracking-wider break-all">
                      {currentKeygenCode}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleSalinPaketLisensiPembeli}
                      className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      {keygenCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                          <span>Tersalin & Dicatat!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 shrink-0" />
                          <span>Salin Format Chat</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleKirimWaPembeliLangsung}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/20"
                    >
                      <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>
                        {formatBuyerWaNumber(keygenWaInput)
                          ? 'Kirim WA ke Pembeli'
                          : 'Buka & Kirim via WA'}
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Template Copywriting Promosi & Follow-Up WA Siap Pakai (Owner Sales Kit) */}
              <div className="bg-[#090D16] p-4 rounded-xl border border-amber-500/30 space-y-2.5">
                <div>
                  <div className="text-xs font-extrabold text-amber-300">
                    📣 Kit Copywriting Jualan &amp; Follow-Up WA (1-Klik Salin)
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Gunakan template siap pakai ini untuk promosi ke grup Seller,
                    follow-up pengguna Demo, atau menawarkan upgrade v5.0:
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopySalesScript('broadcast')}
                    className="p-2.5 rounded-xl bg-[#0E131F] hover:bg-slate-800 border border-slate-800 text-left transition-colors cursor-pointer"
                  >
                    <div className="text-[11px] font-bold text-white flex items-center justify-between">
                      <span>📢 Iklan Grup</span>
                      {copiedPromoScript === 'broadcast' && (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {copiedPromoScript === 'broadcast'
                        ? 'Skrip Disalin!'
                        : 'Share ke Grup WA/FB'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopySalesScript('followup')}
                    className="p-2.5 rounded-xl bg-[#0E131F] hover:bg-slate-800 border border-slate-800 text-left transition-colors cursor-pointer"
                  >
                    <div className="text-[11px] font-bold text-emerald-300 flex items-center justify-between">
                      <span>🤝 Closing Demo</span>
                      {copiedPromoScript === 'followup' && (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {copiedPromoScript === 'followup'
                        ? 'Skrip Disalin!'
                        : 'Follow-up Coba Demo'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopySalesScript('upsell')}
                    className="p-2.5 rounded-xl bg-[#0E131F] hover:bg-slate-800 border border-amber-500/30 text-left transition-colors cursor-pointer"
                  >
                    <div className="text-[11px] font-bold text-amber-300 flex items-center justify-between">
                      <span>👑 Upsell ke v5.0</span>
                      {copiedPromoScript === 'upsell' && (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {copiedPromoScript === 'upsell'
                        ? 'Skrip Disalin!'
                        : `Tawarkan Upgrade (${OWNER_CONFIG.hargaUpgradeV5})`}
                    </span>
                  </button>
                </div>
              </div>

              {/* Riwayat Lisensi Pembeli */}
              <div className="bg-[#090D16] p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-xs font-extrabold text-white">
                      📋 Buku Catatan Lisensi Pembeli ({buyerHistory.length}{' '}
                      Toko)
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Otomatis tercatat setiap Anda klik &ldquo;Salin&rdquo;
                      atau &ldquo;Kirim WA&rdquo;
                    </p>
                  </div>
                  {buyerHistory.length > 0 && (
                    <button
                      type="button"
                      onClick={handleExportRiwayatPembeliCSV}
                      className="text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-emerald-300 px-2.5 py-1.5 rounded-lg border border-slate-700 transition-colors cursor-pointer"
                    >
                      Export CSV Pembeli
                    </button>
                  )}
                </div>

                {buyerHistory.length === 0 ? (
                  <div className="text-[11px] text-slate-500 py-3 text-center border border-dashed border-slate-800 rounded-lg">
                    Belum ada riwayat pembeli tercatat. Ketik nama toko di atas
                    lalu klik &ldquo;Salin Format Chat&rdquo; atau &ldquo;Kirim
                    WA&rdquo;.
                  </div>
                ) : (
                  <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                    {buyerHistory.map((item) => (
                      <div
                        key={item.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#0E131F] px-3 py-2.5 rounded-lg border border-slate-800/90 text-xs"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-white truncate">
                              {item.namaToko}
                            </span>
                            <span
                              className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                                item.tier === 'v5'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : 'bg-orange-500/15 text-orange-300'
                              }`}
                            >
                              {item.tier === 'v5' ? 'v5.0' : 'v4.0'}
                            </span>
                            {item.noWa && (
                              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                                WA: {item.noWa}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                            {item.kodeLisensi} · {item.tanggal}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleSalinUlangRiwayatPembeli(item)}
                            className="bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer"
                          >
                            {copiedHistoryId === item.id
                              ? 'Tersalin!'
                              : 'Salin'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleKirimWaDariRiwayat(item)}
                            className="bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors inline-flex items-center gap-1 cursor-pointer"
                            title="Kirim ulang lisensi via WhatsApp"
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>WA</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleHapusRiwayatPembeli(item.id)}
                            className="text-slate-500 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                            title="Hapus dari riwayat"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-[#090D16]/70 p-3.5 rounded-xl border border-slate-800/80 text-xs text-slate-400 space-y-2">
                <div>
                  <div className="font-semibold text-slate-200">
                    Master Kode Cadangan v4.0 Pro (Bebas nama toko):
                  </div>
                  <div className="font-mono text-[11px] text-orange-300 flex flex-wrap gap-2 mt-0.5">
                    <span>MIM-PRO-2026</span>
                    <span className="text-slate-600">·</span>
                    <span>SELLER-VIP-88</span>
                    <span className="text-slate-600">·</span>
                    <span>WEBCRAFT-99</span>
                  </div>
                </div>
                <div className="pt-1.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-amber-300">
                      Master Kode Cadangan v5.0 Ultimate (Bebas nama toko):
                    </div>
                    <div className="font-mono text-[11px] text-amber-300 flex flex-wrap gap-2 mt-0.5">
                      <span>MIM-ULTIMATE-V5</span>
                      <span className="text-slate-600">·</span>
                      <span>SELLER-V5-99</span>
                      <span className="text-slate-600">·</span>
                      <span>WEBCRAFT-V5</span>
                    </div>
                  </div>
                  {onResetDemoQuota && (
                    <button
                      type="button"
                      onClick={onResetDemoQuota}
                      className="bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer shrink-0"
                    >
                      Reset Kuota Demo (0/3)
                    </button>
                  )}
                </div>
              </div>

              {/* Tombol Download Paket Update Web (Netlify ZIP) & File HTML Mandiri */}
              <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
                <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-300 leading-relaxed">
                    <strong className="text-indigo-300 block">
                      🚀 File Siap Upload ke Netlify (Update Web Utama v5.0):
                    </strong>
                    Download file <code className="text-amber-300">.zip</code>{' '}
                    ini lalu pilih{' '}
                    <strong className="text-white">
                      &ldquo;browse files to upload&rdquo;
                    </strong>{' '}
                    di menu Deploys Netlify Anda.
                  </div>
                  <a
                    href="/sellermetrics-update-netlify.zip"
                    download="sellermetrics-update-netlify.zip"
                    className="w-full sm:w-auto bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 text-xs font-extrabold px-4 py-2.5 rounded-xl transition-all inline-flex items-center justify-center gap-1.5 shrink-0 shadow-md"
                  >
                    <Upload className="w-3.5 h-3.5 shrink-0" />
                    <span>Download ZIP Update Netlify</span>
                  </a>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                  <div className="text-[11px] text-slate-400">
                    Atau simpan file cadangan mandiri 1 file (
                    <code className="text-amber-300">.html</code>):
                  </div>
                  <a
                    href="/SellerMetrics-Pro-v4.0.html"
                    download="SellerMetrics-Pro-v5.0-Standalone.html"
                    className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3.5 py-2 rounded-xl border border-slate-700 transition-colors inline-flex items-center justify-center gap-1.5 shrink-0"
                  >
                    <Download className="w-3.5 h-3.5 shrink-0" />
                    <span>Download File .HTML (v5.0)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
