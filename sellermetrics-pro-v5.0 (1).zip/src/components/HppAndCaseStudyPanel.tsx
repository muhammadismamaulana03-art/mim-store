import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  Calculator,
  ChevronDown,
  ChevronUp,
  Check,
  PackageCheck,
  ShieldAlert,
  Copy,
} from 'lucide-react';
import { rp } from '../data/marketplacePresets';

export interface CaseStudyPreset {
  id: string;
  badge: string;
  title: string;
  kode: string;
  nama: string;
  hpp: number;
  packing: number;
  targetUntung: number;
  presetMp: string;
  kategori: string;
  diskonCoretPct: number;
}

export const CASE_STUDY_PRESETS: CaseStudyPreset[] = [
  {
    id: 'fashion-hijab',
    badge: '👕 Fashion',
    title: 'Hijab / Kemeja (HPP 35rb)',
    kode: 'FS-HIJAB-01',
    nama: 'Pashmina Silk Crinkle Premium',
    hpp: 35000,
    packing: 1500,
    targetUntung: 18000,
    presetMp: 'shopee-star',
    kategori: 'fashion',
    diskonCoretPct: 35,
  },
  {
    id: 'skincare-serum',
    badge: '💄 Beauty',
    title: 'Skincare / Serum (HPP 42rb)',
    kode: 'SK-SERUM-02',
    nama: 'Brightening Niacinamide Serum',
    hpp: 42000,
    packing: 2000,
    targetUntung: 25000,
    presetMp: 'tiktok-shop',
    kategori: 'beauty',
    diskonCoretPct: 40,
  },
  {
    id: 'home-living',
    badge: '🏠 Rumah Tangga',
    title: 'Alat Rumah (HPP 22rb)',
    kode: 'HM-ORGANIZER-03',
    nama: 'Rak Kosmetik Akrilik Putar',
    hpp: 22000,
    packing: 2500,
    targetUntung: 12000,
    presetMp: 'shopee-star',
    kategori: 'home',
    diskonCoretPct: 30,
  },
  {
    id: 'gadget-acc',
    badge: '📱 Aksesoris',
    title: 'Produk Murah (HPP 8.5rb)',
    kode: 'EL-KABEL-04',
    nama: 'Kabel Data Fast Charging 65W',
    hpp: 8500,
    packing: 1000,
    targetUntung: 6500,
    presetMp: 'tokopedia-lazada',
    kategori: 'elektronik',
    diskonCoretPct: 45,
  },
];

interface HppAndCaseStudyPanelProps {
  onApplyCaseStudy: (preset: CaseStudyPreset) => void;
  onApplyLandedHpp: (hppPerPcs: number) => void;
  skuKode: string;
  skuNama: string;
  hargaCoret: number;
  hargaJualFinal: number;
  diskonCoretPct: number;
  batasHargaBawahImpas: number;
  onToast: (msg: string) => void;
}

export const HppAndCaseStudyPanel: React.FC<HppAndCaseStudyPanelProps> = ({
  onApplyCaseStudy,
  onApplyLandedHpp,
  skuKode,
  skuNama,
  hargaCoret,
  hargaJualFinal,
  diskonCoretPct,
  batasHargaBawahImpas,
  onToast,
}) => {
  const [showLandedCalc, setShowLandedCalc] = useState<boolean>(false);
  const [notaSupplierTotal, setNotaSupplierTotal] = useState<number>(3200000);
  const [qtyBeliTotal, setQtyBeliTotal] = useState<number>(100);
  const [ongkirKargo, setOngkirKargo] = useState<number>(150000);
  const [biayaKarungLabel, setBiayaKarungLabel] = useState<number>(50000);
  const [estimasiRejectPcs, setEstimasiRejectPcs] = useState<number>(2);
  const [copiedBriefAdmin, setCopiedBriefAdmin] = useState<boolean>(false);

  const landedResult = useMemo(() => {
    const nota = Math.max(0, Number(notaSupplierTotal) || 0);
    const qtyTotal = Math.max(1, Number(qtyBeliTotal) || 1);
    const kargo = Math.max(0, Number(ongkirKargo) || 0);
    const ekstra = Math.max(0, Number(biayaKarungLabel) || 0);
    const reject = Math.max(
      0,
      Math.min(qtyTotal - 1, Number(estimasiRejectPcs) || 0)
    );

    const qtyLayakJual = Math.max(1, qtyTotal - reject);
    const totalBiayaKulakan = nota + kargo + ekstra;
    const hppAwalTanpaKargo = Math.round(nota / qtyTotal);
    const hppBersihPerPcs = Math.ceil(totalBiayaKulakan / qtyLayakJual);
    const bebanEkstraPerPcs = Math.max(0, hppBersihPerPcs - hppAwalTanpaKargo);

    return {
      qtyLayakJual,
      totalBiayaKulakan,
      hppAwalTanpaKargo,
      hppBersihPerPcs,
      bebanEkstraPerPcs,
    };
  }, [
    notaSupplierTotal,
    qtyBeliTotal,
    ongkirKargo,
    biayaKarungLabel,
    estimasiRejectPcs,
  ]);

  const handleCopyBriefAdmin = () => {
    const kode = skuKode.trim() || 'SKU-TOKO';
    const nama = skuNama.trim() || 'Produk Marketplace';
    const teks =
      `*SOP PATOKAN HARGA ADMIN TOKO (RAHASIA INTERNAL)*\n` +
      `📦 Produk: *${nama}* (${kode})\n` +
      `----------------------------------------\n` +
      `🏷️ *Harga Asli (Sebelum Diskon):* ${rp(hargaCoret)}\n` +
      `🔥 *Diskon Toko Aktif:* ${diskonCoretPct}%\n` +
      `✅ *Harga Jual Tayang (Nett):* *${rp(hargaJualFinal)}*\n` +
      `⚠️ *Batas Bawah Harga Flash Sale / Tawar Grosir:* *${rp(batasHargaBawahImpas)}*\n` +
      `----------------------------------------\n` +
      `_Catatan Admin: Dilarang memasang harga promo di bawah Batas Bawah tanpa persetujuan Owner._`;
    navigator.clipboard.writeText(teks);
    setCopiedBriefAdmin(true);
    onToast('SOP Patokan Harga Admin (Tanpa HPP) berhasil disalin!');
    setTimeout(() => setCopiedBriefAdmin(false), 2200);
  };

  return (
    <div className="space-y-3">
      {/* 1. Baris Preset Contoh Studi Kasus (Onboarding Cepat Pembeli Baru) */}
      <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-2xl border border-slate-800/90 space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Baru Buka Aplikasi? 1-Klik Muat Contoh Studi Kasus:</span>
          </div>
          <button
            type="button"
            onClick={handleCopyBriefAdmin}
            className="text-[11px] font-semibold text-sky-300 hover:text-sky-200 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 px-2.5 py-1 rounded-lg inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Salin instruksi harga untuk Admin CS/Gudang tanpa membocorkan HPP modal pabrik"
          >
            {copiedBriefAdmin ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-300">SOP Admin Disalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>Salin SOP Harga ke Admin (Tanpa HPP)</span>
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {CASE_STUDY_PRESETS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onApplyCaseStudy(item)}
              className="p-2.5 rounded-xl bg-[#090D16] hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/40 text-left transition-all cursor-pointer group"
            >
              <div className="text-[10px] font-extrabold text-amber-400 group-hover:text-amber-300">
                {item.badge}
              </div>
              <div className="text-[11px] font-bold text-white mt-0.5 truncate">
                {item.title}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Asisten Hitung HPP Kulakan / Produksi & Barang Reject (Landed Cost) */}
      <div className="bg-[#0E131F] rounded-2xl border border-indigo-500/30 overflow-hidden">
        <button
          type="button"
          onClick={() => setShowLandedCalc((prev) => !prev)}
          className="w-full p-3.5 sm:px-5 flex items-center justify-between gap-3 text-left hover:bg-slate-900/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-300 shrink-0">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-extrabold text-white flex flex-wrap items-center gap-1.5">
                <span>
                  Bingung Hitung HPP per Pcs dari Nota Kulakan / Kargo / Konveksi?
                </span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-mono">
                  Asisten HPP Kulakan
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Hitung otomatis HPP bersih per pcs setelah ditambah ongkir kargo,
                biaya label, dan potongan barang cacat/reject pabrik.
              </p>
            </div>
          </div>
          <div className="text-indigo-300 shrink-0">
            {showLandedCalc ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </div>
        </button>

        {showLandedCalc && (
          <div className="p-4 sm:p-5 border-t border-slate-800/90 bg-[#090D16]/70 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              <div className="col-span-2 sm:col-span-1">
                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                  Total Nota Supplier (Rp)
                </label>
                <input
                  type="number"
                  value={notaSupplierTotal}
                  onChange={(e) =>
                    setNotaSupplierTotal(
                      Math.max(0, parseFloat(e.target.value) || 0)
                    )
                  }
                  className="w-full bg-[#0E131F] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                  Jml Barang (Pcs)
                </label>
                <input
                  type="number"
                  value={qtyBeliTotal}
                  onChange={(e) =>
                    setQtyBeliTotal(
                      Math.max(1, parseFloat(e.target.value) || 1)
                    )
                  }
                  className="w-full bg-[#0E131F] text-amber-300 p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                  Ongkir Kargo (Rp)
                </label>
                <input
                  type="number"
                  value={ongkirKargo}
                  onChange={(e) =>
                    setOngkirKargo(
                      Math.max(0, parseFloat(e.target.value) || 0)
                    )
                  }
                  className="w-full bg-[#0E131F] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                  Biaya Label/Karung
                </label>
                <input
                  type="number"
                  value={biayaKarungLabel}
                  onChange={(e) =>
                    setBiayaKarungLabel(
                      Math.max(0, parseFloat(e.target.value) || 0)
                    )
                  }
                  className="w-full bg-[#0E131F] text-white p-2.5 rounded-xl border border-slate-800 font-mono font-bold text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-rose-300 mb-1">
                  Barang Cacat (Pcs)
                </label>
                <input
                  type="number"
                  value={estimasiRejectPcs}
                  onChange={(e) =>
                    setEstimasiRejectPcs(
                      Math.max(0, parseFloat(e.target.value) || 0)
                    )
                  }
                  className="w-full bg-[#0E131F] text-rose-300 p-2.5 rounded-xl border border-rose-500/30 font-mono font-bold text-xs tabular-nums"
                />
              </div>
            </div>

            <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-xl border border-indigo-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1 text-xs">
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-slate-400">
                  <span className="inline-flex items-center gap-1">
                    <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>
                      Stok Layak Jual:{' '}
                      <strong className="text-white font-mono">
                        {landedResult.qtyLayakJual} Pcs
                      </strong>
                    </span>
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>
                      Beban Kargo + Reject:{' '}
                      <strong className="text-amber-300 font-mono">
                        +{rp(landedResult.bebanEkstraPerPcs)}/pcs
                      </strong>
                    </span>
                  </span>
                </div>
                <div className="text-sm font-extrabold text-white">
                  HPP Bersih Sebenarnya:{' '}
                  <span className="text-indigo-300 font-mono text-base">
                    {rp(landedResult.hppBersihPerPcs)} / pcs
                  </span>{' '}
                  <span className="text-[11px] font-normal text-slate-400">
                    (Harga nota awal: {rp(landedResult.hppAwalTanpaKargo)}/pcs)
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onApplyLandedHpp(landedResult.hppBersihPerPcs);
                  setShowLandedCalc(false);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer shrink-0 inline-flex items-center justify-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Gunakan HPP {rp(landedResult.hppBersihPerPcs)}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
