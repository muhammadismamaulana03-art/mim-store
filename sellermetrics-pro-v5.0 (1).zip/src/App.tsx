/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Lock,
  Calculator,
  TrendingUp,
  Package,
  Copy,
  Check,
  Download,
  Printer,
  Trash2,
  Clock,
  ShieldCheck,
  AlertTriangle,
  ArrowUpRight,
  Tag,
  X,
  MessageCircle,
  Code2,
  Globe,
  Save,
  Search,
  Target,
  BarChart3,
  RotateCcw,
  Megaphone,
  Upload,
  FileSpreadsheet,
  Smartphone,
  WifiOff,
  HelpCircle,
  Layers,
  Zap,
  Crown,
  Award,
  Sun,
  Moon,
} from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';
import {
  OWNER_CONFIG,
  verifyOwnerPin,
  verifyMasterBackupKey,
  generateSerialKey,
  formatBuyerWaNumber,
  safeParseJson,
  sanitizeImportedString,
} from './utils/licenseAuth';
import {
  SkuItem,
  BuyerLicenseRecord,
  PRESETS_MP,
  PRESETS_KATEGORI,
  GMV_MAX_ROAS_TARGETS,
  rp,
} from './data/marketplacePresets';
import { LicenseGateScreen } from './components/LicenseGateScreen';
import { OwnerKeygenModals } from './components/OwnerKeygenModals';
import { GuideAndInstallModals } from './components/GuideAndInstallModals';
import {
  HppAndCaseStudyPanel,
  CaseStudyPreset,
} from './components/HppAndCaseStudyPanel';
import { V5AdvancedModules } from './components/V5AdvancedModules';

function openExternalUrl(url: string) {
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

export default function App() {
  // Lisensi & Gate State
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [licenseTier, setLicenseTier] = useState<'v4' | 'v5'>('v4');
  const [licensedStore, setLicensedStore] = useState<string>('Official Store');
  const [inputNamaToko, setInputNamaToko] = useState<string>('');
  const [inputKodeLisensi, setInputKodeLisensi] = useState<string>('');
  const [pesanErrorLisensi, setPesanErrorLisensi] = useState<string>('');
  const [upgradeKodeInput, setUpgradeKodeInput] = useState<string>('');
  const [upgradeError, setUpgradeError] = useState<string>('');

  // Demo Mode State (Maksimal 3x Percobaan @ 2 Menit per Perangkat)
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [demoSecondsLeft, setDemoSecondsLeft] = useState<number>(120);
  const [demoUsedCount, setDemoUsedCount] = useState<number>(() => {
    try {
      const saved = parseInt(
        localStorage.getItem('sm_pro_demo_used_count') || '0',
        10
      );
      return Number.isNaN(saved) ? 0 : Math.max(0, saved);
    } catch {
      return 0;
    }
  });

  // Admin PIN & Keygen Modal State
  const [showPinDialog, setShowPinDialog] = useState<boolean>(false);
  const [adminPinInput, setAdminPinInput] = useState<string>('');
  const [adminPinError, setAdminPinError] = useState<string>('');
  const [showKeygenModal, setShowKeygenModal] = useState<boolean>(false);
  const [keygenNamaInput, setKeygenNamaInput] = useState<string>('');
  const [keygenWaInput, setKeygenWaInput] = useState<string>('');
  const [keygenTier, setKeygenTier] = useState<'v4' | 'v5'>('v5');
  const [keygenCopied, setKeygenCopied] = useState<boolean>(false);
  const [buyerHistory, setBuyerHistory] = useState<BuyerLicenseRecord[]>([]);
  const [copiedHistoryId, setCopiedHistoryId] = useState<string>('');

  // Navigation State
  const [activeMenu, setActiveMenu] = useState<
    'kalkulator' | 'proyeksi' | 'v5suite' | 'database'
  >('kalkulator');

  // Kalkulator State
  const [calcMode, setCalcMode] = useState<'ideal' | 'kompetitor'>('ideal');
  const [selectedPreset, setSelectedPreset] = useState<string>('shopee-star');
  const [selectedCategory, setSelectedCategory] = useState<string>('home');
  const [customHargaFinal, setCustomHargaFinal] = useState<number | null>(null);
  const [showAwamGuide, setShowAwamGuide] = useState<boolean>(true);
  const [skuKode, setSkuKode] = useState<string>('');
  const [skuNama, setSkuNama] = useState<string>('');
  const [inHpp, setInHpp] = useState<number>(55000);
  const [inPacking, setInPacking] = useState<number>(1500);
  const [inTargetUntung, setInTargetUntung] = useState<number>(20000);
  const [inHargaKompetitor, setInHargaKompetitor] = useState<number>(99000);
  const [inAdminPct, setInAdminPct] = useState<number>(6.5);
  const [inOngkirPct, setInOngkirPct] = useState<number>(4.0);
  const [inAffPct, setInAffPct] = useState<number>(5.0);
  const [inBiayaProses, setInBiayaProses] = useState<number>(1250);
  const [inVoucherToko, setInVoucherToko] = useState<number>(2000);
  const [inDiskonCoretPct, setInDiskonCoretPct] = useState<number>(35);
  const [inBiayaIklanPcs, setInBiayaIklanPcs] = useState<number>(0);
  const [inRtsCodPct, setInRtsCodPct] = useState<number>(0);

  // Proyeksi Bulanan & Target Gajian State
  const [simQtyHari, setSimQtyHari] = useState<number>(25);
  const [simReturCodPct, setSimReturCodPct] = useState<number>(3.0);
  const [simOpexBulanan, setSimOpexBulanan] = useState<number>(3500000);
  const [targetGajianBulanan, setTargetGajianBulanan] =
    useState<number>(10000000);
  const [copiedProyeksiWa, setCopiedProyeksiWa] = useState<boolean>(false);

  // v5.0 Ultimate Suite State (Bundling, Flash Sale, GMV Max Ads & Affiliate Creator)
  const [bundleDiskon2Pct, setBundleDiskon2Pct] = useState<number>(5);
  const [bundleDiskon3Pct, setBundleDiskon3Pct] = useState<number>(8);
  const [bundleDiskon5Pct, setBundleDiskon5Pct] = useState<number>(12);
  const [bundleHematPackingPct, setBundleHematPackingPct] =
    useState<number>(50);
  const [flashSaleHarga, setFlashSaleHarga] = useState<number>(79000);
  const [flashSaleKuota, setFlashSaleKuota] = useState<number>(50);
  const [flashSaleNormalQty, setFlashSaleNormalQty] = useState<number>(150);
  const [gmvDailyBudget, setGmvDailyBudget] = useState<number>(150000);
  const [gmvTargetRoas, setGmvTargetRoas] = useState<number>(8);
  const [affSampleQty, setAffSampleQty] = useState<number>(5);
  const [affSampleOngkir, setAffSampleOngkir] = useState<number>(10000);
  const [affTargetSalesQty, setAffTargetSalesQty] = useState<number>(40);

  // Database SKU State
  const [skuDatabase, setSkuDatabase] = useState<SkuItem[]>([]);
  const [searchQuerySku, setSearchQuerySku] = useState<string>('');
  const [confirmResetDb, setConfirmResetDb] = useState<boolean>(false);

  // Feedback Toast / Copy State
  const [copiedWaReport, setCopiedWaReport] = useState<boolean>(false);
  const [copiedV5Report, setCopiedV5Report] = useState<boolean>(false);
  const [savedSkuFeedback, setSavedSkuFeedback] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('');
  const [demoExpiredNotice, setDemoExpiredNotice] = useState<boolean>(false);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);
  const [showGuideModal, setShowGuideModal] = useState<boolean>(false);
  const [showSecurityModal, setShowSecurityModal] = useState<boolean>(false);
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    try {
      return localStorage.getItem('sm_pro_theme') === 'light'
        ? 'light'
        : 'dark';
    } catch {
      return 'dark';
    }
  });

  // Sync class theme-light on document.body
  useEffect(() => {
    document.body.classList.toggle('theme-light', themeMode === 'light');
    try {
      localStorage.setItem('sm_pro_theme', themeMode);
    } catch {
      // ignore storage errors
    }
  }, [themeMode]);

  // Apakah fitur eksklusif v5.0 terbuka (Lisensi v5 atau Mode Preview Demo)
  const isV5Unlocked = licenseTier === 'v5' || isDemoMode;

  // PWA Install & Offline Hook
  const { isInstallable, isInstalled, isIOS, isOnline, install } =
    usePWAInstall();

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2800);
  };

  const handleToggleTheme = () => {
    setThemeMode((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      triggerToast(
        next === 'light'
          ? '☀️ Mode Terang (Daylight) diaktifkan!'
          : '🌙 Mode Gelap (Dark) diaktifkan!'
      );
      return next;
    });
  };

  const handlePromptUpgradeV5 = (namaFitur: string) => {
    triggerToast(
      `👑 Fitur "${namaFitur}" eksklusif di v5.0 Ultimate! Silakan Upgrade.`
    );
    setActiveMenu('v5suite');
  };

  const handleInstallAplikasi = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        triggerToast(
          'SellerMetrics Pro berhasil di-install di perangkat Anda!'
        );
      }
    } else {
      setShowInstallModal(true);
    }
  };

  // Load saved license & SKU database on mount
  useEffect(() => {
    const savedStore = localStorage.getItem('sm_pro_licensed_store');
    const savedKey = localStorage.getItem('sm_pro_license_key');
    const savedTier = localStorage.getItem('sm_pro_license_tier') as
      | 'v4'
      | 'v5'
      | null;
    if (savedStore && savedKey) {
      setLicensedStore(savedStore);
      setLicenseTier(savedTier === 'v5' ? 'v5' : 'v4');
      setIsUnlocked(true);
    }

    try {
      const savedDb = JSON.parse(localStorage.getItem('sm_pro_sku_db') || '[]');
      if (Array.isArray(savedDb)) {
        setSkuDatabase(
          savedDb.map((item, idx) => ({
            ...item,
            id: item.id || `${item.kode || 'SKU'}-${idx}-${Date.now()}`,
          }))
        );
      }
    } catch {
      setSkuDatabase([]);
    }

    // Load saved Buyer License History (Owner Keygen)
    try {
      const savedBuyers = JSON.parse(
        localStorage.getItem('sm_pro_buyer_history') || '[]'
      );
      if (Array.isArray(savedBuyers)) {
        setBuyerHistory(savedBuyers);
      }
    } catch {
      setBuyerHistory([]);
    }

    // Load Auto-Saved Calculator & v5.0 Draft Inputs
    try {
      const savedDraft = JSON.parse(
        localStorage.getItem('sm_pro_draft_inputs') || 'null'
      );
      if (savedDraft && typeof savedDraft === 'object') {
        if (
          savedDraft.calcMode === 'ideal' ||
          savedDraft.calcMode === 'kompetitor'
        )
          setCalcMode(savedDraft.calcMode);
        if (typeof savedDraft.selectedPreset === 'string')
          setSelectedPreset(savedDraft.selectedPreset);
        if (typeof savedDraft.selectedCategory === 'string')
          setSelectedCategory(savedDraft.selectedCategory);
        if (
          typeof savedDraft.customHargaFinal === 'number' ||
          savedDraft.customHargaFinal === null
        )
          setCustomHargaFinal(savedDraft.customHargaFinal);
        if (typeof savedDraft.skuKode === 'string')
          setSkuKode(savedDraft.skuKode);
        if (typeof savedDraft.skuNama === 'string')
          setSkuNama(savedDraft.skuNama);
        if (typeof savedDraft.inHpp === 'number') setInHpp(savedDraft.inHpp);
        if (typeof savedDraft.inPacking === 'number')
          setInPacking(savedDraft.inPacking);
        if (typeof savedDraft.inTargetUntung === 'number')
          setInTargetUntung(savedDraft.inTargetUntung);
        if (typeof savedDraft.inHargaKompetitor === 'number')
          setInHargaKompetitor(savedDraft.inHargaKompetitor);
        if (typeof savedDraft.inAdminPct === 'number')
          setInAdminPct(savedDraft.inAdminPct);
        if (typeof savedDraft.inOngkirPct === 'number')
          setInOngkirPct(savedDraft.inOngkirPct);
        if (typeof savedDraft.inAffPct === 'number')
          setInAffPct(savedDraft.inAffPct);
        if (typeof savedDraft.inBiayaProses === 'number')
          setInBiayaProses(savedDraft.inBiayaProses);
        if (typeof savedDraft.inVoucherToko === 'number')
          setInVoucherToko(savedDraft.inVoucherToko);
        if (typeof savedDraft.inDiskonCoretPct === 'number')
          setInDiskonCoretPct(savedDraft.inDiskonCoretPct);
        if (typeof savedDraft.inBiayaIklanPcs === 'number')
          setInBiayaIklanPcs(savedDraft.inBiayaIklanPcs);
        if (typeof savedDraft.inRtsCodPct === 'number')
          setInRtsCodPct(savedDraft.inRtsCodPct);
        if (typeof savedDraft.simQtyHari === 'number')
          setSimQtyHari(savedDraft.simQtyHari);
        if (typeof savedDraft.simReturCodPct === 'number')
          setSimReturCodPct(savedDraft.simReturCodPct);
        if (typeof savedDraft.simOpexBulanan === 'number')
          setSimOpexBulanan(savedDraft.simOpexBulanan);
        if (typeof savedDraft.targetGajianBulanan === 'number')
          setTargetGajianBulanan(savedDraft.targetGajianBulanan);
        if (typeof savedDraft.bundleDiskon2Pct === 'number')
          setBundleDiskon2Pct(savedDraft.bundleDiskon2Pct);
        if (typeof savedDraft.bundleDiskon3Pct === 'number')
          setBundleDiskon3Pct(savedDraft.bundleDiskon3Pct);
        if (typeof savedDraft.bundleDiskon5Pct === 'number')
          setBundleDiskon5Pct(savedDraft.bundleDiskon5Pct);
        if (typeof savedDraft.bundleHematPackingPct === 'number')
          setBundleHematPackingPct(savedDraft.bundleHematPackingPct);
        if (typeof savedDraft.flashSaleHarga === 'number')
          setFlashSaleHarga(savedDraft.flashSaleHarga);
        if (typeof savedDraft.flashSaleKuota === 'number')
          setFlashSaleKuota(savedDraft.flashSaleKuota);
        if (typeof savedDraft.flashSaleNormalQty === 'number')
          setFlashSaleNormalQty(savedDraft.flashSaleNormalQty);
        if (typeof savedDraft.gmvDailyBudget === 'number')
          setGmvDailyBudget(savedDraft.gmvDailyBudget);
        if (typeof savedDraft.gmvTargetRoas === 'number')
          setGmvTargetRoas(savedDraft.gmvTargetRoas);
        if (typeof savedDraft.affSampleQty === 'number')
          setAffSampleQty(savedDraft.affSampleQty);
        if (typeof savedDraft.affSampleOngkir === 'number')
          setAffSampleOngkir(savedDraft.affSampleOngkir);
        if (typeof savedDraft.affTargetSalesQty === 'number')
          setAffTargetSalesQty(savedDraft.affTargetSalesQty);
      }
    } catch {
      // Ignore draft parse error
    }
  }, []);

  // Auto-Save Calculator & v5.0 Inputs on change
  useEffect(() => {
    const draft = {
      calcMode,
      selectedPreset,
      selectedCategory,
      customHargaFinal,
      skuKode,
      skuNama,
      inHpp,
      inPacking,
      inTargetUntung,
      inHargaKompetitor,
      inAdminPct,
      inOngkirPct,
      inAffPct,
      inBiayaProses,
      inVoucherToko,
      inDiskonCoretPct,
      inBiayaIklanPcs,
      inRtsCodPct,
      simQtyHari,
      simReturCodPct,
      simOpexBulanan,
      targetGajianBulanan,
      bundleDiskon2Pct,
      bundleDiskon3Pct,
      bundleDiskon5Pct,
      bundleHematPackingPct,
      flashSaleHarga,
      flashSaleKuota,
      flashSaleNormalQty,
      gmvDailyBudget,
      gmvTargetRoas,
      affSampleQty,
      affSampleOngkir,
      affTargetSalesQty,
    };
    localStorage.setItem('sm_pro_draft_inputs', JSON.stringify(draft));
  }, [
    calcMode,
    selectedPreset,
    selectedCategory,
    customHargaFinal,
    skuKode,
    skuNama,
    inHpp,
    inPacking,
    inTargetUntung,
    inHargaKompetitor,
    inAdminPct,
    inOngkirPct,
    inAffPct,
    inBiayaProses,
    inVoucherToko,
    inDiskonCoretPct,
    inBiayaIklanPcs,
    inRtsCodPct,
    simQtyHari,
    simReturCodPct,
    simOpexBulanan,
    targetGajianBulanan,
    bundleDiskon2Pct,
    bundleDiskon3Pct,
    bundleDiskon5Pct,
    bundleHematPackingPct,
    flashSaleHarga,
    flashSaleKuota,
    flashSaleNormalQty,
    gmvDailyBudget,
    gmvTargetRoas,
    affSampleQty,
    affSampleOngkir,
    affTargetSalesQty,
  ]);

  // Demo Timer Countdown
  useEffect(() => {
    if (!isDemoMode) return;
    const timer = setInterval(() => {
      setDemoSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsDemoMode(false);
          setIsUnlocked(false);
          setDemoExpiredNotice(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isDemoMode]);

  // Format Demo Timer MM:SS
  const demoTimerFormatted = useMemo(() => {
    const m = String(Math.floor(demoSecondsLeft / 60)).padStart(2, '0');
    const s = String(demoSecondsLeft % 60).padStart(2, '0');
    return `${m}:${s}`;
  }, [demoSecondsLeft]);

  // Perhitungan Kalkulator Utama
  const calcResult = useMemo(() => {
    const hpp = Number(inHpp) || 0;
    const packing = Number(inPacking) || 0;
    const adminPct = Number(inAdminPct) || 0;
    const ongkirPct = Number(inOngkirPct) || 0;
    const affPct = Number(inAffPct) || 0;
    const biayaProses = Number(inBiayaProses) || 0;
    const voucherToko = Number(inVoucherToko) || 0;
    const diskonCoretPct = Math.min(
      90,
      Math.max(0, Number(inDiskonCoretPct) || 0)
    );
    const biayaIklanPcs = Math.max(0, Number(inBiayaIklanPcs) || 0);
    const rtsCodPct = isV5Unlocked
      ? Math.min(50, Math.max(0, Number(inRtsCodPct) || 0))
      : 0;

    // Cadangan kerugian retur per pcs terjual (Khusus v5.0 Ultimate)
    const rugiPerPaketRetur = packing + 5000;
    const cadanganRtsPcs = Math.round((rtsCodPct / 100) * rugiPerPaketRetur);

    const totalModal = hpp + packing;
    const totalPotonganTetap = biayaProses + voucherToko + cadanganRtsPcs;
    const totalPctFee = adminPct + ongkirPct + affPct;
    const pembagi = 1 - totalPctFee / 100;
    const targetUntungNominal = Number(inTargetUntung) || 0;

    const hargaIdealMurni =
      pembagi > 0.05
        ? Math.ceil(
            (totalModal +
              targetUntungNominal +
              totalPotonganTetap +
              biayaIklanPcs) /
              pembagi
          )
        : 0;

    let hargaJualFinal = 0;
    let profitBersih = 0;

    if (calcMode === 'ideal') {
      if (customHargaFinal !== null && customHargaFinal > 0) {
        hargaJualFinal = customHargaFinal;
        const feeNominal = hargaJualFinal * (totalPctFee / 100);
        profitBersih = Math.round(
          hargaJualFinal -
            totalModal -
            feeNominal -
            totalPotonganTetap -
            biayaIklanPcs
        );
      } else {
        profitBersih = targetUntungNominal;
        hargaJualFinal = hargaIdealMurni;
      }
    } else {
      hargaJualFinal = Number(inHargaKompetitor) || 0;
      const feeNominal = hargaJualFinal * (totalPctFee / 100);
      profitBersih = Math.round(
        hargaJualFinal - totalModal - feeNominal - totalPotonganTetap
      );
    }

    const profitSetelahIklan =
      calcMode === 'ideal' ? profitBersih : profitBersih - biayaIklanPcs;
    const profitSebelumIklan =
      calcMode === 'ideal' ? profitBersih + biayaIklanPcs : profitBersih;

    const pembagiDiskon = 1 - diskonCoretPct / 100;
    const hargaCoret =
      pembagiDiskon > 0
        ? Math.ceil(hargaJualFinal / pembagiDiskon)
        : hargaJualFinal;

    const nominalFeePct = Math.round(hargaJualFinal * (totalPctFee / 100));
    const totalSemuaFee = nominalFeePct + biayaProses + voucherToko;
    const danaCair = hargaJualFinal - totalSemuaFee;
    const netMarginPctNum =
      hargaJualFinal > 0 ? (profitSetelahIklan / hargaJualFinal) * 100 : 0;
    const netMarginPct = netMarginPctNum.toFixed(1);

    // ROAS Guard
    const maxCpa = Math.max(0, profitSebelumIklan);
    const minRoas = maxCpa > 0 ? (hargaJualFinal / maxCpa).toFixed(1) : '0.0';
    const safeRoas =
      maxCpa > 0 ? (hargaJualFinal / (maxCpa * 0.5)).toFixed(1) : '0.0';
    const actualRoas =
      biayaIklanPcs > 0
        ? (hargaJualFinal / biayaIklanPcs).toFixed(1)
        : null;

    // Simulator Iklan GMV Max / Target ROAS Otomatis (5x, 8x, 10x, 12x, 15x)
    const gmvMaxSimulations = GMV_MAX_ROAS_TARGETS.map((item) => {
      const cpaGmv =
        hargaJualFinal > 0 ? Math.round(hargaJualFinal / item.roas) : 0;
      const sisaLaba = profitSebelumIklan - cpaGmv;
      return {
        roas: item.roas,
        label: item.label,
        cpaGmv,
        sisaLaba,
        isSafe: sisaLaba >= profitSebelumIklan * 0.45 && sisaLaba > 0,
        isBepOrLoss: sisaLaba <= 0,
      };
    });

    // 3 Opsi Rekomendasi Harga Psikologis
    const baseAcuan =
      calcMode === 'ideal' ? hargaIdealMurni : Number(inHargaKompetitor) || 0;
    const sisaRibu = baseAcuan % 1000;
    const opsi900 =
      baseAcuan > 0
        ? sisaRibu <= 900
          ? Math.floor(baseAcuan / 1000) * 1000 + 900
          : (Math.floor(baseAcuan / 1000) + 1) * 1000 + 900
        : 0;
    const opsiRibuan =
      baseAcuan > 0 ? Math.ceil((baseAcuan + 50) / 1000) * 1000 : 0;
    const opsiPuluh900 =
      baseAcuan > 0
        ? (() => {
            const candidate4900 =
              Math.floor(baseAcuan / 10000) * 10000 + 4900;
            const candidate9900 =
              Math.floor(baseAcuan / 10000) * 10000 + 9900;
            const candidateNext4900 =
              (Math.floor(baseAcuan / 10000) + 1) * 10000 + 4900;
            if (candidate4900 > opsi900) return candidate4900;
            if (candidate9900 > opsi900) return candidate9900;
            return candidateNext4900;
          })()
        : 0;

    const hitungLabaDariHarga = (h: number) =>
      Math.round(
        h -
          totalModal -
          h * (totalPctFee / 100) -
          totalPotonganTetap -
          biayaIklanPcs
      );

    const opsiPsikologis = [
      {
        label: 'Psikologis .900',
        harga: opsi900,
        laba: hitungLabaDariHarga(opsi900),
      },
      {
        label: 'Bulat Ribuan',
        harga: opsiRibuan,
        laba: hitungLabaDariHarga(opsiRibuan),
      },
      {
        label: 'Cantik x9.900',
        harga: opsiPuluh900,
        laba: hitungLabaDariHarga(opsiPuluh900),
      },
    ].filter(
      (x, idx, arr) =>
        x.harga > 0 && arr.findIndex((y) => y.harga === x.harga) === idx
    );

    // Komposisi Bar
    let pModal = 45;
    let pFee = 30;
    let pProfit = 25;
    if (hargaJualFinal > 0) {
      pModal = Math.max(
        0,
        Math.min(100, Math.round((totalModal / hargaJualFinal) * 100))
      );
      pFee = Math.max(
        0,
        Math.min(
          100,
          Math.round(
            ((totalSemuaFee + cadanganRtsPcs + biayaIklanPcs) /
              hargaJualFinal) *
              100
          )
        )
      );
      pProfit = Math.max(0, 100 - pModal - pFee);
    }

    return {
      hpp,
      totalModal,
      packing,
      totalPotonganTetap: biayaProses + voucherToko,
      cadanganRtsPcs,
      rtsCodPct,
      totalPctFee,
      biayaIklanPcs,
      hargaIdealMurni,
      hargaJualFinal,
      profitBersih: profitSetelahIklan,
      profitSebelumIklan,
      profitSetelahIklan,
      diskonCoretPct,
      hargaCoret,
      nominalFeePct,
      totalSemuaFee,
      danaCair,
      netMarginPctNum,
      netMarginPct,
      maxCpa,
      minRoas,
      safeRoas,
      actualRoas,
      gmvMaxSimulations,
      opsiPsikologis,
      pModal,
      pFee,
      pProfit,
    };
  }, [
    calcMode,
    customHargaFinal,
    inHpp,
    inPacking,
    inTargetUntung,
    inHargaKompetitor,
    inAdminPct,
    inOngkirPct,
    inAffPct,
    inBiayaProses,
    inVoucherToko,
    inDiskonCoretPct,
    inBiayaIklanPcs,
    inRtsCodPct,
    isV5Unlocked,
  ]);

  // Perhitungan Proyeksi Bulanan, Risiko COD & Kalkulator Target Gajian
  const proyeksiResult = useMemo(() => {
    const qtyHari = Number(simQtyHari) || 0;
    const returPct = Number(simReturCodPct) || 0;
    const opex = Number(simOpexBulanan) || 0;
    const targetGajian = Math.max(0, Number(targetGajianBulanan) || 0);

    const totalQtyBulan = qtyHari * 30;
    const qtyRetur = Math.round(totalQtyBulan * (returPct / 100));
    const qtySukses = totalQtyBulan - qtyRetur;

    const omsetKotor = qtySukses * (calcResult.hargaJualFinal || 0);
    const rugiPerRetur = (calcResult.packing || 1500) + 5000;
    const rugiReturCod = qtyRetur * rugiPerRetur;
    const labaKotorProduk = qtySukses * (calcResult.profitBersih || 0);
    const netProfitBulan = labaKotorProduk - rugiReturCod - opex;

    const bepPcs =
      calcResult.profitBersih > 0
        ? Math.ceil(opex / calcResult.profitBersih)
        : 0;

    const rasioSukses = Math.max(0.1, 1 - returPct / 100);
    const rasioRetur = Math.max(0, returPct / 100);
    const labaEfektifPerOrder =
      rasioSukses * (calcResult.profitBersih || 0) - rasioRetur * rugiPerRetur;

    const wajibOrderBulan =
      labaEfektifPerOrder > 0
        ? Math.ceil((targetGajian + opex) / labaEfektifPerOrder)
        : 0;
    const wajibOrderHari =
      wajibOrderBulan > 0 ? Math.ceil(wajibOrderBulan / 30) : 0;
    const modalStokTarget = wajibOrderBulan * (calcResult.totalModal || 0);
    const omsetTargetGajian =
      Math.round(wajibOrderBulan * rasioSukses) *
      (calcResult.hargaJualFinal || 0);

    return {
      totalQtyBulan,
      qtyRetur,
      qtySukses,
      omsetKotor,
      rugiReturCod,
      labaKotorProduk,
      netProfitBulan,
      bepPcs,
      targetGajian,
      wajibOrderBulan,
      wajibOrderHari,
      modalStokTarget,
      omsetTargetGajian,
      labaEfektifPerOrder,
    };
  }, [
    simQtyHari,
    simReturCodPct,
    simOpexBulanan,
    targetGajianBulanan,
    calcResult,
  ]);

  // Perhitungan Eksklusif v5.0 Ultimate Suite (6 Modul Super Suite)
  const v5Result = useMemo(() => {
    const hargaSatuan = calcResult.hargaJualFinal || 0;
    const hppSatuan = calcResult.hpp || 0;
    const packSatuan = calcResult.packing || 0;
    const pctFee = calcResult.totalPctFee || 0;
    const biayaProsesOrder = Number(inBiayaProses) || 0;
    const voucherOrder = Number(inVoucherToko) || 0;
    const biayaIklan = calcResult.biayaIklanPcs || 0;

    // 1. Kalkulator Paket Bundling (1 Resi)
    const rawHematPack = Number(bundleHematPackingPct);
    const faktorHematPack = Math.max(
      0,
      Math.min(100, Number.isNaN(rawHematPack) ? 50 : rawHematPack)
    );
    const packPcsTambahan = Math.round(
      packSatuan * (1 - faktorHematPack / 100)
    );

    const hitungBundle = (qty: number, diskonPct: number) => {
      const hargaNormalTotal = hargaSatuan * qty;
      const hargaPaket = Math.round(hargaNormalTotal * (1 - diskonPct / 100));
      const hematPembeli = hargaNormalTotal - hargaPaket;
      const modalProdukTotal = hppSatuan * qty;
      const modalPackingNormal = packSatuan * qty;
      const modalPackingTotal = Math.round(
        packSatuan +
          packSatuan * (qty - 1) * (1 - faktorHematPack / 100)
      );
      const hematPackingNominal = modalPackingNormal - modalPackingTotal;
      const feePersenNominal = Math.round(hargaPaket * (pctFee / 100));
      const totalPotonganResi =
        feePersenNominal + biayaProsesOrder + voucherOrder;
      const labaBersihResi = Math.round(
        hargaPaket -
          modalProdukTotal -
          modalPackingTotal -
          totalPotonganResi -
          biayaIklan
      );
      const labaPerPcs = Math.round(labaBersihResi / qty);
      const marginPct =
        hargaPaket > 0
          ? ((labaBersihResi / hargaPaket) * 100).toFixed(1)
          : '0.0';

      return {
        qty,
        diskonPct,
        hargaNormalTotal,
        hargaPaket,
        hematPembeli,
        modalPackingTotal,
        hematPackingNominal,
        totalPotonganResi,
        labaBersihResi,
        labaPerPcs,
        marginPct,
      };
    };

    const tier1 = hitungBundle(1, 0);
    const tier2 = hitungBundle(2, Number(bundleDiskon2Pct) || 0);
    const tier3 = hitungBundle(3, Number(bundleDiskon3Pct) || 0);
    const tier5 = hitungBundle(5, Number(bundleDiskon5Pct) || 0);

    const bundlingTiers = [tier2, tier3, tier5, tier1];

    // 2. Matriks Komparasi Multi-Marketplace Sekaligus
    const mpComparisons = PRESETS_MP.map((mp) => {
      const totalPct = mp.adm + mp.ongkir + mp.aff;
      const fixedFee = mp.proses + voucherOrder;
      const pembagi = 1 - totalPct / 100;
      const targetProfit =
        calcMode === 'ideal'
          ? Number(inTargetUntung) || 20000
          : calcResult.profitBersih;
      const hargaIdealMp =
        pembagi > 0.05
          ? Math.ceil(
              (calcResult.totalModal + targetProfit + fixedFee + biayaIklan) /
                pembagi
            )
          : 0;
      const potonganJikaHargaSama =
        Math.round(hargaSatuan * (totalPct / 100)) + fixedFee;
      const profitJikaHargaSama = Math.round(
        hargaSatuan -
          calcResult.totalModal -
          potonganJikaHargaSama -
          biayaIklan
      );
      const marginJikaHargaSama =
        hargaSatuan > 0
          ? ((profitJikaHargaSama / hargaSatuan) * 100).toFixed(1)
          : '0.0';
      const minRoasMp =
        profitJikaHargaSama + biayaIklan > 0
          ? (hargaSatuan / (profitJikaHargaSama + biayaIklan)).toFixed(1)
          : '0.0';

      return {
        ...mp,
        totalPct,
        hargaIdealMp,
        potonganJikaHargaSama,
        profitJikaHargaSama,
        marginJikaHargaSama,
        minRoasMp,
      };
    });

    const bestMp = [...mpComparisons].sort(
      (a, b) => b.profitJikaHargaSama - a.profitJikaHargaSama
    )[0];

    // 3. Simulator Campaign Flash Sale & Event Kembar
    const fsHarga = Number(flashSaleHarga) || 0;
    const fsKuota = Math.max(0, Number(flashSaleKuota) || 0);
    const fsNormalQty = Math.max(0, Number(flashSaleNormalQty) || 0);
    const fsFeeNominal =
      Math.round(fsHarga * (pctFee / 100)) + biayaProsesOrder;
    const fsProfitPerPcs = Math.round(
      fsHarga - calcResult.totalModal - fsFeeNominal
    );
    const fsTotalProfitOrLoss = fsProfitPerPcs * fsKuota;
    const fsLabaPenjualanNormal = fsNormalQty * calcResult.profitBersih;
    const fsNetCampaignProfit = fsTotalProfitOrLoss + fsLabaPenjualanNormal;
    const fsBepNormalQty =
      fsTotalProfitOrLoss < 0 && calcResult.profitBersih > 0
        ? Math.ceil(Math.abs(fsTotalProfitOrLoss) / calcResult.profitBersih)
        : 0;

    // 4. Simulator Budget Iklan Harian & Target ROAS GMV Max (Modul 04 v5.0)
    const budgetHarian = Math.max(0, Number(gmvDailyBudget) || 0);
    const targetRoasVal = Math.max(1, Number(gmvTargetRoas) || 8);
    const gmvOmsetHarian = Math.round(budgetHarian * targetRoasVal);
    const gmvEstOrderHari =
      hargaSatuan > 0 ? Math.max(1, Math.round(gmvOmsetHarian / hargaSatuan)) : 0;
    const gmvCpaPerOrder =
      gmvEstOrderHari > 0
        ? Math.round(budgetHarian / gmvEstOrderHari)
        : Math.round(hargaSatuan / targetRoasVal);
    const gmvLabaPerOrder = calcResult.profitSebelumIklan - gmvCpaPerOrder;
    const gmvNetProfitHarian = gmvEstOrderHari * gmvLabaPerOrder;
    const gmvNetProfitBulanan = gmvNetProfitHarian * 30;

    // 5. Kalkulator Komisi Affiliate, Top Creator & BEP Sampel Gratis (Modul 05 v5.0)
    const baseFeeTanpaAff =
      (Number(inAdminPct) || 0) + (Number(inOngkirPct) || 0);
    const sampleQty = Math.max(0, Number(affSampleQty) || 0);
    const sampleOngkir = Math.max(0, Number(affSampleOngkir) || 0);
    const targetSalesKreator = Math.max(1, Number(affTargetSalesQty) || 30);
    const totalModalSampel =
      sampleQty * (calcResult.totalModal + sampleOngkir);

    const affiliateTiers = [
      { id: 'std', name: 'Affiliate Standar', pct: 5 },
      { id: 'active', name: 'Kreator Aktif', pct: 8 },
      { id: 'top', name: 'Top Creator / Live', pct: 12 },
      { id: 'mcn', name: 'Exclusive MCN / Host', pct: 15 },
    ].map((t) => {
      const komisiRp = Math.round(hargaSatuan * (t.pct / 100));
      const feeMpNominal = Math.round(hargaSatuan * (baseFeeTanpaAff / 100));
      const labaPerPcsKreator = Math.round(
        hargaSatuan -
          calcResult.totalModal -
          feeMpNominal -
          biayaProsesOrder -
          voucherOrder -
          komisiRp
      );
      const bepSampelPcs =
        labaPerPcsKreator > 0 && totalModalSampel > 0
          ? Math.ceil(totalModalSampel / labaPerPcsKreator)
          : 0;
      const netProfitKolaborasi =
        targetSalesKreator * labaPerPcsKreator - totalModalSampel;

      return {
        ...t,
        komisiRp,
        labaPerPcsKreator,
        bepSampelPcs,
        netProfitKolaborasi,
      };
    });

    return {
      bundlingTiers,
      tier1,
      tier2,
      tier3,
      tier5,
      packPcsTambahan,
      mpComparisons,
      bestMp,
      fsHarga,
      fsKuota,
      fsNormalQty,
      fsProfitPerPcs,
      fsTotalProfitOrLoss,
      fsLabaPenjualanNormal,
      fsNetCampaignProfit,
      fsBepNormalQty,
      budgetHarian,
      targetRoasVal,
      gmvOmsetHarian,
      gmvEstOrderHari,
      gmvCpaPerOrder,
      gmvLabaPerOrder,
      gmvNetProfitHarian,
      gmvNetProfitBulanan,
      totalModalSampel,
      targetSalesKreator,
      affiliateTiers,
    };
  }, [
    calcResult,
    calcMode,
    inTargetUntung,
    inAdminPct,
    inOngkirPct,
    inBiayaProses,
    inVoucherToko,
    bundleDiskon2Pct,
    bundleDiskon3Pct,
    bundleDiskon5Pct,
    bundleHematPackingPct,
    flashSaleHarga,
    flashSaleKuota,
    flashSaleNormalQty,
    gmvDailyBudget,
    gmvTargetRoas,
    affSampleQty,
    affSampleOngkir,
    affTargetSalesQty,
  ]);

  // Analitik Eksekutif Portofolio Katalog SKU (v5.0)
  const skuAnalytics = useMemo(() => {
    if (skuDatabase.length === 0) {
      return {
        avgMargin: '0.0',
        avgProfit: 0,
        winnerSku: null as SkuItem | null,
        healthyCount: 0,
        riskCount: 0,
      };
    }
    const totalProfit = skuDatabase.reduce(
      (acc, item) => acc + (Number(item.profitBersih) || 0),
      0
    );
    const totalMargin = skuDatabase.reduce(
      (acc, item) => acc + (parseFloat(item.netMarginPct) || 0),
      0
    );
    const winnerSku = [...skuDatabase].sort(
      (a, b) => (b.profitBersih || 0) - (a.profitBersih || 0)
    )[0];
    const healthyCount = skuDatabase.filter(
      (x) => (parseFloat(x.netMarginPct) || 0) >= 12 && x.profitBersih > 0
    ).length;
    const riskCount = skuDatabase.length - healthyCount;

    return {
      avgMargin: (totalMargin / skuDatabase.length).toFixed(1),
      avgProfit: Math.round(totalProfit / skuDatabase.length),
      winnerSku,
      healthyCount,
      riskCount,
    };
  }, [skuDatabase]);

  // Filter Database SKU Berdasarkan Search Query
  const filteredSkuDatabase = useMemo(() => {
    const q = searchQuerySku.trim().toLowerCase();
    if (!q) return skuDatabase;
    return skuDatabase.filter(
      (item) =>
        item.kode.toLowerCase().includes(q) ||
        item.nama.toLowerCase().includes(q)
    );
  }, [skuDatabase, searchQuerySku]);

  // Handlers Lisensi
  const handleVerifikasiLisensi = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const namaInput = inputNamaToko.trim();
    const kodeInput = inputKodeLisensi.trim().toUpperCase();

    if (verifyOwnerPin(kodeInput)) {
      setShowKeygenModal(true);
      setPesanErrorLisensi('');
      return;
    }

    if (!namaInput) {
      setPesanErrorLisensi('Mohon isi Nama Toko / Brand Anda terlebih dahulu.');
      return;
    }

    const expectedKeyV4 = generateSerialKey(namaInput, 'v4');
    const expectedKeyV5 = generateSerialKey(namaInput, 'v5');

    if (
      kodeInput === expectedKeyV5 ||
      verifyMasterBackupKey(kodeInput, 'v5')
    ) {
      localStorage.setItem('sm_pro_licensed_store', namaInput);
      localStorage.setItem('sm_pro_license_key', kodeInput);
      localStorage.setItem('sm_pro_license_tier', 'v5');
      setLicenseTier('v5');
      setIsDemoMode(false);
      setDemoExpiredNotice(false);
      setLicensedStore(namaInput);
      setIsUnlocked(true);
      setPesanErrorLisensi('');
      triggerToast('Lisensi v5.0 Ultimate berhasil diaktifkan!');
    } else if (
      kodeInput === expectedKeyV4 ||
      verifyMasterBackupKey(kodeInput, 'v4')
    ) {
      localStorage.setItem('sm_pro_licensed_store', namaInput);
      localStorage.setItem('sm_pro_license_key', kodeInput);
      localStorage.setItem('sm_pro_license_tier', 'v4');
      setLicenseTier('v4');
      setIsDemoMode(false);
      setDemoExpiredNotice(false);
      setLicensedStore(namaInput);
      setIsUnlocked(true);
      setPesanErrorLisensi('');
      triggerToast('Lisensi v4.0 Pro berhasil diaktifkan!');
    } else {
      setPesanErrorLisensi(
        `Kode Lisensi tidak valid untuk nama toko '${namaInput}'. Silakan hubungi Admin.`
      );
    }
  };

  const handleUpgradeKeV5InApp = (e: React.FormEvent) => {
    e.preventDefault();
    const kode = upgradeKodeInput.trim().toUpperCase();
    const expectedKeyV5 = generateSerialKey(licensedStore, 'v5');

    if (kode === expectedKeyV5 || verifyMasterBackupKey(kode, 'v5')) {
      localStorage.setItem('sm_pro_license_key', kode);
      localStorage.setItem('sm_pro_license_tier', 'v5');
      setLicenseTier('v5');
      setUpgradeKodeInput('');
      setUpgradeError('');
      triggerToast(
        `Selamat! Toko ${licensedStore} berhasil Upgrade ke v5.0 Ultimate!`
      );
    } else {
      setUpgradeError(
        `Kode Upgrade v5.0 tidak sesuai untuk toko "${licensedStore}". Pastikan kode diawali SM5-...`
      );
    }
  };

  const handleMulaiDemoGratis = () => {
    const maxDemo = 3;
    if (demoUsedCount >= maxDemo) {
      setPesanErrorLisensi(
        'Kuota Preview Demo Gratis (3x) telah habis di perangkat ini. Silakan beli Kode Lisensi resmi untuk membuka akses penuh selamanya.'
      );
      return;
    }
    const nextCount = demoUsedCount + 1;
    setDemoUsedCount(nextCount);
    try {
      localStorage.setItem('sm_pro_demo_used_count', String(nextCount));
    } catch {
      // ignore storage error
    }
    setDemoExpiredNotice(false);
    setPesanErrorLisensi('');
    setLicensedStore(`Mode Preview Demo (${nextCount}/${maxDemo}x Percobaan)`);
    setLicenseTier('v5');
    setDemoSecondsLeft(120);
    setIsDemoMode(true);
    setIsUnlocked(true);
    triggerToast(
      `Preview Demo Gratis dimulai (Percobaan ke-${nextCount} dari ${maxDemo})`
    );
  };

  const handleResetDemoQuota = () => {
    setDemoUsedCount(0);
    setDemoExpiredNotice(false);
    try {
      localStorage.removeItem('sm_pro_demo_used_count');
    } catch {
      // ignore
    }
    triggerToast('Kuota Demo Gratis di perangkat ini berhasil direset (0/3)!');
  };

  const handleKunciKembali = () => {
    localStorage.removeItem('sm_pro_licensed_store');
    localStorage.removeItem('sm_pro_license_key');
    localStorage.removeItem('sm_pro_license_tier');
    setIsDemoMode(false);
    setIsUnlocked(false);
  };

  // Handlers Owner Keygen
  const handleOpenAdminPrompt = () => {
    setAdminPinInput('');
    setAdminPinError('');
    setShowPinDialog(true);
  };

  const handleVerifyAdminPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyOwnerPin(adminPinInput)) {
      setShowPinDialog(false);
      setShowKeygenModal(true);
    } else {
      setAdminPinError('Kode Master PIN Pemilik tidak valid. Akses ditolak.');
    }
  };

  const currentKeygenStore = keygenNamaInput.trim() || 'Berkah Jaya';
  const currentKeygenCode = generateSerialKey(currentKeygenStore, keygenTier);

  const buildBuyerChatText = (
    namaToko: string,
    kode: string,
    tier: 'v4' | 'v5'
  ) => {
    const labelEdisi =
      tier === 'v5'
        ? 'ULTIMATE EDITION v5.0 (FULL SUITE)'
        : 'PRO EDITION v4.0';
    return (
      `*AKSES LISENSI RESMI SELLERMETRICS — ${labelEdisi}*\n` +
      `Terima kasih telah melakukan pembelian! Berikut data aktivasi Anda:\n\n` +
      `🏪 Nama Toko: *${namaToko}*\n` +
      `🔑 Kode Lisensi: *${kode}*\n` +
      `🌐 Link Aplikasi: ${window.location.href}\n\n` +
      `_Masukkan Nama Toko & Kode Lisensi persis seperti di atas untuk membuka akses aplikasi selamanya._`
    );
  };

  const simpanRiwayatPembeli = (
    namaToko: string,
    kode: string,
    tier: 'v4' | 'v5',
    rawWa: string
  ) => {
    const cleanWa = formatBuyerWaNumber(rawWa);
    const newRecord: BuyerLicenseRecord = {
      id: `${kode}-${Date.now()}`,
      namaToko,
      noWa: cleanWa || undefined,
      tier,
      kodeLisensi: kode,
      hargaLabel:
        tier === 'v5' ? OWNER_CONFIG.hargaLisensiV5 : OWNER_CONFIG.hargaLisensi,
      tanggal: new Date().toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
    };

    const existingIdx = buyerHistory.findIndex(
      (b) =>
        b.namaToko.toLowerCase() === namaToko.toLowerCase() && b.tier === tier
    );
    let updatedHistory: BuyerLicenseRecord[];
    if (existingIdx >= 0) {
      updatedHistory = [...buyerHistory];
      updatedHistory[existingIdx] = newRecord;
    } else {
      updatedHistory = [newRecord, ...buyerHistory];
    }
    setBuyerHistory(updatedHistory);
    localStorage.setItem(
      'sm_pro_buyer_history',
      JSON.stringify(updatedHistory)
    );
  };

  const handleSalinPaketLisensiPembeli = () => {
    const teks = buildBuyerChatText(
      currentKeygenStore,
      currentKeygenCode,
      keygenTier
    );
    navigator.clipboard.writeText(teks);
    setKeygenCopied(true);
    simpanRiwayatPembeli(
      currentKeygenStore,
      currentKeygenCode,
      keygenTier,
      keygenWaInput
    );
    setTimeout(() => setKeygenCopied(false), 2500);
  };

  const handleKirimWaPembeliLangsung = () => {
    const teks = buildBuyerChatText(
      currentKeygenStore,
      currentKeygenCode,
      keygenTier
    );
    navigator.clipboard.writeText(teks);
    simpanRiwayatPembeli(
      currentKeygenStore,
      currentKeygenCode,
      keygenTier,
      keygenWaInput
    );
    const cleanWa = formatBuyerWaNumber(keygenWaInput);
    const waUrl = cleanWa
      ? `https://wa.me/${cleanWa}?text=${encodeURIComponent(teks)}`
      : `https://wa.me/?text=${encodeURIComponent(teks)}`;
    openExternalUrl(waUrl);
  };

  const handleSalinUlangRiwayatPembeli = (record: BuyerLicenseRecord) => {
    const teks = buildBuyerChatText(
      record.namaToko,
      record.kodeLisensi,
      record.tier
    );
    navigator.clipboard.writeText(teks);
    setCopiedHistoryId(record.id);
    setTimeout(() => setCopiedHistoryId(''), 2000);
  };

  const handleKirimWaDariRiwayat = (record: BuyerLicenseRecord) => {
    const teks = buildBuyerChatText(
      record.namaToko,
      record.kodeLisensi,
      record.tier
    );
    const cleanWa = formatBuyerWaNumber(record.noWa || '');
    const waUrl = cleanWa
      ? `https://wa.me/${cleanWa}?text=${encodeURIComponent(teks)}`
      : `https://wa.me/?text=${encodeURIComponent(teks)}`;
    openExternalUrl(waUrl);
  };

  const handleHapusRiwayatPembeli = (id: string) => {
    const updated = buyerHistory.filter((b) => b.id !== id);
    setBuyerHistory(updated);
    localStorage.setItem('sm_pro_buyer_history', JSON.stringify(updated));
  };

  const handleExportRiwayatPembeliCSV = () => {
    if (buyerHistory.length === 0) return;
    let csv =
      'Tanggal,Nama Toko Pembeli,No WhatsApp,Paket Lisensi,Kode Lisensi,Harga\n';
    buyerHistory.forEach((b) => {
      csv += `"${b.tanggal}","${b.namaToko}","${b.noWa || '-'}","${b.tier === 'v5' ? 'v5.0 Ultimate' : 'v4.0 Pro'}","${b.kodeLisensi}","${b.hargaLabel}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Riwayat_Pembeli_SellerMetrics_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  // Handlers Kalkulator & Database
  const handlePilihPresetMP = (preset: (typeof PRESETS_MP)[0]) => {
    setSelectedPreset(preset.id);
    setCustomHargaFinal(null);
    const activeKat = PRESETS_KATEGORI.find((k) => k.id === selectedCategory);
    const rateKategori = activeKat?.rates[preset.id] ?? preset.adm;
    setInAdminPct(rateKategori);
    setInOngkirPct(preset.ongkir);
    setInAffPct(preset.aff);
    setInBiayaProses(preset.proses);
    triggerToast(
      `Preset ${preset.name} (${activeKat?.name || 'Standar'}: Adm ${rateKategori}%) diterapkan!`
    );
  };

  const handlePilihKategori = (kat: (typeof PRESETS_KATEGORI)[0]) => {
    setSelectedCategory(kat.id);
    setCustomHargaFinal(null);
    const rate = kat.rates[selectedPreset] ?? inAdminPct;
    setInAdminPct(rate);
    const mpLabel =
      PRESETS_MP.find((m) => m.id === selectedPreset)?.name || 'Marketplace';
    triggerToast(
      `Kategori ${kat.name} (${kat.katLabel}) → Biaya Admin ${mpLabel} diset ke ${rate}%`
    );
  };

  const handleTerapkanHargaPsikologis = (
    hargaBulat: number,
    labaBaru: number
  ) => {
    if (calcMode === 'ideal') {
      setCustomHargaFinal(hargaBulat);
    } else {
      setInHargaKompetitor(hargaBulat);
    }
    triggerToast(
      `Harga Psikologis ${rp(hargaBulat)} diterapkan! Laba Bersih menjadi ${rp(labaBaru)}/pcs`
    );
  };

  const handleTerapkanGmvMaxRoas = (roas: number, cpaNominal: number) => {
    if (!isV5Unlocked) {
      handlePromptUpgradeV5('Simulator Target ROAS GMV Max');
      return;
    }
    setCustomHargaFinal(null);
    setInBiayaIklanPcs(cpaNominal);
    triggerToast(
      `Target ROAS GMV Max ${roas}x diterapkan → Budget Iklan diset ${rp(cpaNominal)}/pcs`
    );
  };

  const handleApplyCaseStudy = (preset: CaseStudyPreset) => {
    setCustomHargaFinal(null);
    setCalcMode('ideal');
    setSkuKode(preset.kode);
    setSkuNama(preset.nama);
    setInHpp(preset.hpp);
    setInPacking(preset.packing);
    setInTargetUntung(preset.targetUntung);
    setInDiskonCoretPct(preset.diskonCoretPct);
    setSelectedPreset(preset.presetMp);
    setSelectedCategory(preset.kategori);
    const mpObj = PRESETS_MP.find((m) => m.id === preset.presetMp);
    const katObj = PRESETS_KATEGORI.find((k) => k.id === preset.kategori);
    if (mpObj) {
      const admRate = katObj?.rates[mpObj.id] ?? mpObj.adm;
      setInAdminPct(admRate);
      setInOngkirPct(mpObj.ongkir);
      setInAffPct(mpObj.aff);
      setInBiayaProses(mpObj.proses);
    }
    triggerToast(`Studi Kasus "${preset.nama}" berhasil dimuat!`);
  };

  const handleSimpanKeDatabaseSKU = () => {
    const cleanKode =
      skuKode.trim() || 'SKU-' + Math.floor(100 + Math.random() * 900);
    const cleanNama = skuNama.trim() || 'Produk Marketplace';

    const newItem: SkuItem = {
      id: `${cleanKode}-${Date.now()}`,
      kode: cleanKode,
      nama: cleanNama,
      hpp: Number(inHpp) || 0,
      totalModal: calcResult.totalModal,
      packing: calcResult.packing,
      targetUntung: Number(inTargetUntung) || 0,
      hargaKompetitor: Number(inHargaKompetitor) || 0,
      calcMode,
      selectedPreset,
      adminPct: Number(inAdminPct) || 0,
      ongkirPct: Number(inOngkirPct) || 0,
      affPct: Number(inAffPct) || 0,
      biayaProses: Number(inBiayaProses) || 0,
      voucherToko: Number(inVoucherToko) || 0,
      diskonCoretPct: calcResult.diskonCoretPct,
      biayaIklanPcs: calcResult.biayaIklanPcs,
      rtsCodPct: calcResult.rtsCodPct,
      hargaCoret: calcResult.hargaCoret,
      hargaJualFinal: calcResult.hargaJualFinal,
      totalSemuaFee: calcResult.totalSemuaFee,
      minRoas: calcResult.minRoas,
      profitBersih: calcResult.profitBersih,
      profitSetelahIklan: calcResult.profitSetelahIklan,
      netMarginPct: calcResult.netMarginPct,
      updatedAt: new Date().toLocaleDateString('id-ID'),
    };

    const existingIndex = skuDatabase.findIndex(
      (x) => x.kode.toUpperCase() === cleanKode.toUpperCase()
    );
    let updated: SkuItem[];
    if (existingIndex >= 0) {
      updated = [...skuDatabase];
      updated[existingIndex] = newItem;
      triggerToast(`SKU ${cleanKode} berhasil diperbarui di Katalog!`);
    } else {
      updated = [newItem, ...skuDatabase];
      triggerToast(`Produk ${cleanKode} berhasil disimpan ke Katalog SKU!`);
    }

    setSkuDatabase(updated);
    localStorage.setItem('sm_pro_sku_db', JSON.stringify(updated));
    setSkuKode('');
    setSkuNama('');
    setSavedSkuFeedback(true);
    setTimeout(() => setSavedSkuFeedback(false), 2500);
  };

  const handleMuatContohSKU = () => {
    const sampleItems: SkuItem[] = [
      {
        id: `SKU-HJ01-${Date.now()}-1`,
        kode: 'HJ-Pashmina-01',
        nama: 'Pashmina Silk Premium Crinkle',
        hpp: 32000,
        packing: 1500,
        totalModal: 33500,
        targetUntung: 18000,
        calcMode: 'ideal',
        selectedPreset: 'shopee-star',
        adminPct: 6.5,
        ongkirPct: 4.0,
        affPct: 5.0,
        biayaProses: 1250,
        voucherToko: 1500,
        diskonCoretPct: 35,
        biayaIklanPcs: 2500,
        hargaCoret: 103399,
        hargaJualFinal: 67209,
        totalSemuaFee: 13167,
        minRoas: '3.3',
        profitBersih: 18000,
        profitSetelahIklan: 18000,
        netMarginPct: '26.8',
      },
      {
        id: `SKU-SK02-${Date.now()}-2`,
        kode: 'SK-Serum-02',
        nama: 'Brightening Niacinamide Serum 20ml',
        hpp: 45000,
        packing: 2000,
        totalModal: 47000,
        targetUntung: 28000,
        calcMode: 'ideal',
        selectedPreset: 'tiktok-shop',
        adminPct: 6.0,
        ongkirPct: 3.0,
        affPct: 8.0,
        biayaProses: 1000,
        voucherToko: 2000,
        diskonCoretPct: 40,
        biayaIklanPcs: 4000,
        hargaCoret: 164659,
        hargaJualFinal: 98796,
        totalSemuaFee: 19795,
        minRoas: '3.1',
        profitBersih: 28000,
        profitSetelahIklan: 28000,
        netMarginPct: '28.3',
      },
      {
        id: `SKU-KM03-${Date.now()}-3`,
        kode: 'KM-Kemeja-03',
        nama: 'Kemeja Linen Oversize Wanita',
        hpp: 58000,
        packing: 1500,
        totalModal: 59500,
        targetUntung: 25000,
        calcMode: 'ideal',
        selectedPreset: 'shopee-mall',
        adminPct: 8.0,
        ongkirPct: 4.5,
        affPct: 5.0,
        biayaProses: 1250,
        voucherToko: 2000,
        diskonCoretPct: 30,
        biayaIklanPcs: 0,
        hargaCoret: 151949,
        hargaJualFinal: 106364,
        totalSemuaFee: 21864,
        minRoas: '4.3',
        profitBersih: 25000,
        profitSetelahIklan: 25000,
        netMarginPct: '23.5',
      },
    ];

    const updated = [...sampleItems, ...skuDatabase];
    setSkuDatabase(updated);
    localStorage.setItem('sm_pro_sku_db', JSON.stringify(updated));
    triggerToast('3 Contoh Produk berhasil dimuat ke Katalog SKU!');
  };

  const handleImportFileSKU = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Security Guard: Batas maksimal ukuran file import 2 MB
    if (file.size > 2 * 1024 * 1024) {
      triggerToast('Ukuran file terlalu besar (Maksimal 2 MB).');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = String(event.target?.result || '');
      try {
        if (file.name.endsWith('.json')) {
          const parsed = safeParseJson<Record<string, unknown> | SkuItem[]>(
            content
          );
          const rawSkuArray = Array.isArray(parsed)
            ? parsed
            : Array.isArray((parsed as Record<string, unknown>)?.skuDatabase)
            ? ((parsed as Record<string, unknown>).skuDatabase as SkuItem[])
            : null;

          const draftObj = !Array.isArray(parsed)
            ? (parsed?.draftInputs as Record<string, unknown> | undefined)
            : undefined;

          if (draftObj && typeof draftObj === 'object') {
            localStorage.setItem(
              'sm_pro_draft_inputs',
              JSON.stringify(draftObj)
            );
            const d = draftObj;
            if (typeof d.inHpp === 'number') setInHpp(d.inHpp);
            if (typeof d.inPacking === 'number') setInPacking(d.inPacking);
            if (typeof d.inTargetUntung === 'number')
              setInTargetUntung(d.inTargetUntung);
            if (typeof d.inAdminPct === 'number') setInAdminPct(d.inAdminPct);
            if (typeof d.inOngkirPct === 'number')
              setInOngkirPct(d.inOngkirPct);
            if (typeof d.inAffPct === 'number') setInAffPct(d.inAffPct);
            if (typeof d.inBiayaProses === 'number')
              setInBiayaProses(d.inBiayaProses);
            if (typeof d.inVoucherToko === 'number')
              setInVoucherToko(d.inVoucherToko);
            if (typeof d.inDiskonCoretPct === 'number')
              setInDiskonCoretPct(d.inDiskonCoretPct);
          }

          if (rawSkuArray) {
            const normalized: SkuItem[] = rawSkuArray
              .slice(0, 1000)
              .map((item: SkuItem, i: number) => ({
                ...item,
                id: sanitizeImportedString(
                  item.id || `IMP-${i}-${Date.now()}`,
                  64
                ),
                kode: sanitizeImportedString(item.kode || `SKU-${i + 1}`, 40),
                nama: sanitizeImportedString(
                  item.nama || 'Produk Import',
                  100
                ),
                totalModal: Number(item.totalModal) || 0,
                packing: Number(item.packing) || 1500,
                hargaCoret: Number(item.hargaCoret) || 0,
                hargaJualFinal: Number(item.hargaJualFinal) || 0,
                totalSemuaFee: Number(item.totalSemuaFee) || 0,
                minRoas: sanitizeImportedString(item.minRoas || '0.0', 12),
                profitBersih: Number(item.profitBersih) || 0,
                netMarginPct: sanitizeImportedString(
                  item.netMarginPct || '0.0',
                  12
                ),
              }));
            const merged = [...normalized, ...skuDatabase];
            setSkuDatabase(merged);
            localStorage.setItem('sm_pro_sku_db', JSON.stringify(merged));
            triggerToast(
              `Backup berhasil dipulihkan (${normalized.length} SKU & Pengaturan Toko)!`
            );
          }
          return;
        }

        const lines = content
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean);
        if (lines.length < 2) {
          triggerToast('File CSV kosong atau format tidak sesuai');
          return;
        }

        const importedItems: SkuItem[] = [];
        for (let i = 1; i < Math.min(lines.length, 1001); i++) {
          const cols =
            lines[i]
              .match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g)
              ?.map((c) => c.replace(/^"|"$/g, '').trim()) || [];
          if (cols.length >= 8) {
            const kode = sanitizeImportedString(cols[0] || `SKU-${i}`, 40);
            const nama = sanitizeImportedString(
              cols[1] || 'Produk Import',
              100
            );
            const totalModal = parseFloat(cols[2]) || 0;
            const hargaCoret = parseFloat(cols[3]) || 0;
            const hargaJualFinal = parseFloat(cols[4]) || 0;
            const totalSemuaFee = parseFloat(cols[5]) || 0;

            let biayaIklanPcs = 0;
            let minRoas = '0.0';
            let profitBersih = 0;
            let netMarginPct = '0.0';

            if (cols.length >= 9) {
              biayaIklanPcs = parseFloat(cols[6]) || 0;
              minRoas = (cols[7] || '0.0').replace('x', '');
              profitBersih = parseFloat(cols[8]) || 0;
              netMarginPct = (cols[9] || '0.0').replace('%', '');
            } else {
              minRoas = (cols[6] || '0.0').replace('x', '');
              profitBersih = parseFloat(cols[7]) || 0;
              netMarginPct = (cols[8] || '0.0').replace('%', '');
            }

            importedItems.push({
              id: `CSV-${kode}-${i}-${Date.now()}`,
              kode,
              nama,
              totalModal,
              hpp: Math.max(0, totalModal - 1500),
              packing: 1500,
              hargaCoret,
              hargaJualFinal,
              totalSemuaFee,
              biayaIklanPcs,
              minRoas,
              profitBersih,
              netMarginPct,
            });
          }
        }

        if (importedItems.length > 0) {
          const merged = [...importedItems, ...skuDatabase];
          setSkuDatabase(merged);
          localStorage.setItem('sm_pro_sku_db', JSON.stringify(merged));
          triggerToast(
            `${importedItems.length} SKU berhasil dipulihkan dari file CSV!`
          );
        } else {
          triggerToast('Format kolom CSV tidak dikenali');
        }
      } catch {
        triggerToast('Gagal membaca file. Pastikan file CSV/JSON valid.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleMuatSkuKeKalkulator = (item: SkuItem) => {
    setCustomHargaFinal(null);
    setSkuKode(item.kode);
    setSkuNama(item.nama);
    if (item.hpp !== undefined) {
      setInHpp(item.hpp);
    } else {
      setInHpp(Math.max(0, item.totalModal - (item.packing || 0)));
    }
    setInPacking(item.packing || 0);
    if (item.calcMode) setCalcMode(item.calcMode);
    if (item.selectedPreset) setSelectedPreset(item.selectedPreset);
    if (item.targetUntung !== undefined) setInTargetUntung(item.targetUntung);
    if (item.hargaKompetitor !== undefined) {
      setInHargaKompetitor(item.hargaKompetitor);
    } else {
      setInHargaKompetitor(item.hargaJualFinal);
    }
    if (item.adminPct !== undefined) setInAdminPct(item.adminPct);
    if (item.ongkirPct !== undefined) setInOngkirPct(item.ongkirPct);
    if (item.affPct !== undefined) setInAffPct(item.affPct);
    if (item.biayaProses !== undefined) setInBiayaProses(item.biayaProses);
    if (item.voucherToko !== undefined) setInVoucherToko(item.voucherToko);
    if (item.diskonCoretPct !== undefined)
      setInDiskonCoretPct(item.diskonCoretPct);
    if (item.biayaIklanPcs !== undefined)
      setInBiayaIklanPcs(item.biayaIklanPcs);
    if (item.rtsCodPct !== undefined) setInRtsCodPct(item.rtsCodPct);

    setActiveMenu('kalkulator');
    triggerToast(`SKU ${item.kode} dimuat kembali ke Kalkulator`);
  };

  const handleHapusSatuSku = (idOrKode: string, kodeLabel: string) => {
    const updated = skuDatabase.filter(
      (item) => (item.id || item.kode) !== idOrKode
    );
    setSkuDatabase(updated);
    localStorage.setItem('sm_pro_sku_db', JSON.stringify(updated));
    triggerToast(`SKU ${kodeLabel} telah dihapus dari Katalog`);
  };

  const handleSalinLaporanWA = () => {
    const kodeProduk =
      skuKode.trim() || 'SKU-' + Math.floor(100 + Math.random() * 900);
    const namaProduk = skuNama.trim() || 'Produk Marketplace';
    const mpLabel =
      PRESETS_MP.find((m) => m.id === selectedPreset)?.name || 'Marketplace';
    const katLabel =
      PRESETS_KATEGORI.find((k) => k.id === selectedCategory)?.name || 'Umum';
    const barisIklan =
      calcResult.biayaIklanPcs > 0
        ? `• Budget Iklan / Pcs: -${rp(calcResult.biayaIklanPcs)}\n`
        : '';
    const barisRts =
      calcResult.cadanganRtsPcs > 0
        ? `• Cadangan Risiko Retur COD (${calcResult.rtsCodPct}%): -${rp(calcResult.cadanganRtsPcs)}\n`
        : '';
    const t =
      `*KARTU HPP & HARGA JUAL — SELLERMETRICS PRO v5.0*\n` +
      `📦 Produk: *${namaProduk}* (${kodeProduk})\n` +
      `🏪 Platform: *${mpLabel}* · Kategori: *${katLabel}*\n` +
      `----------------------------------------\n` +
      `• Modal (HPP + Packing): ${rp(calcResult.totalModal)}\n` +
      `• Harga Coret (Diskon ${calcResult.diskonCoretPct}%): ~${rp(calcResult.hargaCoret)}~\n` +
      `• *Harga Jual Final: ${rp(calcResult.hargaJualFinal)}*\n` +
      `• Total Potongan MP (${calcResult.totalPctFee.toFixed(1)}% + Biaya Proses): -${rp(calcResult.totalSemuaFee)}\n` +
      `• Dana Cair Bersih ke Saldo: ${rp(calcResult.danaCair)}\n` +
      barisRts +
      barisIklan +
      `• Batas Max Iklan / Pcs: ${rp(calcResult.maxCpa)} (Min ROAS: *${calcResult.minRoas}x* | Aman: *${calcResult.safeRoas}x*)\n` +
      `----------------------------------------\n` +
      `💰 *PROFIT BERSIH: ${rp(calcResult.profitBersih)} /pcs (${calcResult.netMarginPct}%)*`;
    navigator.clipboard.writeText(t);
    setCopiedWaReport(true);
    triggerToast('Kartu HPP & ROAS berhasil disalin ke WhatsApp!');
    setTimeout(() => setCopiedWaReport(false), 2000);
  };

  const handleSalinLaporanProyeksiWA = () => {
    const namaProduk = skuNama.trim() || 'Produk Marketplace';
    const t =
      `*SIMULASI PROYEKSI BULANAN & TARGET GAJIAN — SELLERMETRICS PRO*\n` +
      `📦 Produk: *${namaProduk}* (Profit: ${rp(calcResult.profitBersih)}/pcs)\n` +
      `----------------------------------------\n` +
      `🎯 *TARGET GAJIAN / LABA BERSIH: ${rp(proyeksiResult.targetGajian)}/Bulan*\n` +
      `• Wajib Terjual: *${proyeksiResult.wajibOrderHari.toLocaleString('id-ID')} Pcs/Hari* (${proyeksiResult.wajibOrderBulan.toLocaleString('id-ID')} Pcs/Bulan)\n` +
      `• Modal Stok Wajib Disiapkan: *${rp(proyeksiResult.modalStokTarget)}*\n` +
      `• Estimasi Omset Target: *${rp(proyeksiResult.omsetTargetGajian)}*\n` +
      `----------------------------------------\n` +
      `📊 *SIMULASI OPERASIONAL SAAT INI (${simQtyHari} Pcs/Hari):*\n` +
      `• Total Terkirim Sukses: ${proyeksiResult.qtySukses.toLocaleString('id-ID')} Pcs (Retur COD ${simReturCodPct}%: ${proyeksiResult.qtyRetur} Pcs)\n` +
      `• Estimasi Omset Kotor: ${rp(proyeksiResult.omsetKotor)}\n` +
      `• Biaya Operasional + Rugi Retur: -${rp(simOpexBulanan + proyeksiResult.rugiReturCod)}\n` +
      `💰 *LABA BERSIH TOKO / BULAN: ${rp(proyeksiResult.netProfitBulan)}*`;
    navigator.clipboard.writeText(t);
    setCopiedProyeksiWa(true);
    triggerToast('Laporan Proyeksi & Target Gajian disalin ke WhatsApp!');
    setTimeout(() => setCopiedProyeksiWa(false), 2200);
  };

  const handleSalinLaporanV5WA = () => {
    const namaProduk = skuNama.trim() || 'Produk Marketplace';
    const kodeProduk = skuKode.trim() || 'SKU-UTAMA';
    const b2 = v5Result.bundlingTiers.find((x) => x.qty === 2);
    const b3 = v5Result.bundlingTiers.find((x) => x.qty === 3);
    const b5 = v5Result.bundlingTiers.find((x) => x.qty === 5);

    const barisMp = v5Result.mpComparisons
      .map(
        (m) =>
          `• ${m.name} (Fee ${m.totalPct.toFixed(1)}%): Ideal *${rp(m.hargaIdealMp)}* | Laba di Hrg Saat Ini: *${rp(m.profitJikaHargaSama)}/pcs*`
      )
      .join('\n');

    const t =
      `*STRATEGI EKSEKUTIF v5.0 ULTIMATE — SELLERMETRICS PRO*\n` +
      `📦 Produk: *${namaProduk}* (${kodeProduk})\n` +
      `🏷️ Harga Satuan Saat Ini: *${rp(calcResult.hargaJualFinal)}* (Laba: ${rp(calcResult.profitBersih)}/pcs)\n` +
      `----------------------------------------\n` +
      `🔥 *REKOMENDASI PAKET BUNDLING 1 RESI:*\n` +
      `• Paket 2 Pcs (Diskon ${bundleDiskon2Pct}%): *${rp(b2?.hargaPaket || 0)}* → Laba Resi: *${rp(b2?.labaBersihResi || 0)}*\n` +
      `• Paket 3 Pcs (Diskon ${bundleDiskon3Pct}%): *${rp(b3?.hargaPaket || 0)}* → Laba Resi: *${rp(b3?.labaBersihResi || 0)}*\n` +
      `• Paket Grosir 5 Pcs (Diskon ${bundleDiskon5Pct}%): *${rp(b5?.hargaPaket || 0)}* → Laba Resi: *${rp(b5?.labaBersihResi || 0)}*\n` +
      `----------------------------------------\n` +
      `📊 *KOMPARASI 4 MARKETPLACE SEKALIGUS:*\n` +
      `${barisMp}\n` +
      `----------------------------------------\n` +
      `🎯 *SIMULASI IKLAN GMV MAX (ROAS ${v5Result.targetRoasVal}x | Budget ${rp(v5Result.budgetHarian)}/hr):*\n` +
      `• Est. Order Iklan: ${v5Result.gmvEstOrderHari} Pcs/hr (CPA: ${rp(v5Result.gmvCpaPerOrder)}/pcs)\n` +
      `• Laba Bersih Iklan: *${rp(v5Result.gmvNetProfitHarian)}/hari* (${rp(v5Result.gmvNetProfitBulanan)}/bln)\n` +
      `----------------------------------------\n` +
      `⚡ *SIMULASI CAMPAIGN FLASH SALE:*\n` +
      `• Harga Flash Sale: ${rp(flashSaleHarga)} (${flashSaleKuota} Pcs) → Laba/Rugi: ${rp(v5Result.fsTotalProfitOrLoss)}\n` +
      `• Konversi Harga Normal (${flashSaleNormalQty} Pcs) → Laba: +${rp(v5Result.fsLabaPenjualanNormal)}\n` +
      `💰 *TOTAL NET PROFIT CAMPAIGN: ${rp(v5Result.fsNetCampaignProfit)}*`;

    navigator.clipboard.writeText(t);
    setCopiedV5Report(true);
    triggerToast('Ringkasan Strategi v5.0 berhasil disalin ke Clipboard!');
    setTimeout(() => setCopiedV5Report(false), 2200);
  };

  const handleExportKeCSV = () => {
    if (skuDatabase.length === 0) return;
    let csv =
      'Kode SKU,Nama Produk,Total Modal,Harga Coret,Harga Jual Final,Total Potongan MP,Budget Iklan/Pcs,Min ROAS,Profit Bersih,Margin (%)\n';
    skuDatabase.forEach((r) => {
      csv += `"${r.kode}","${r.nama}",${r.totalModal},${r.hargaCoret},${r.hargaJualFinal},${r.totalSemuaFee},${r.biayaIklanPcs || 0},${r.minRoas},${r.profitBersih},${r.netMarginPct}%\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Katalog_Harga_SellerMetrics_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  const handleBackupFullDeviceJSON = () => {
    let draftInputs = null;
    try {
      draftInputs = JSON.parse(
        localStorage.getItem('sm_pro_draft_inputs') || 'null'
      );
    } catch {
      draftInputs = null;
    }
    const payload = {
      type: 'sm_pro_full_backup',
      version: '5.0',
      storeName: licensedStore,
      exportedAt: new Date().toISOString(),
      skuDatabase,
      draftInputs,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_Penuh_SellerMetrics_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    triggerToast(
      'File Backup Penuh (.JSON) berhasil diunduh untuk pindah HP/Laptop!'
    );
  };

  const handleResetDatabaseSKU = () => {
    localStorage.removeItem('sm_pro_sku_db');
    setSkuDatabase([]);
    setConfirmResetDb(false);
    triggerToast('Seluruh Database SKU telah direset');
  };

  // WhatsApp Direct Links
  const waLisensiUrl = `https://wa.me/${OWNER_CONFIG.waNumber}?text=${encodeURIComponent(
    `Halo ${OWNER_CONFIG.brandName}, saya sudah mencoba Demo *SellerMetrics Pro* dan ingin membeli *Kode Lisensi v4.0 Pro (${OWNER_CONFIG.hargaLisensi})*. Mohon info pembayarannya.`
  )}`;

  const waLisensiV5Url = `https://wa.me/${OWNER_CONFIG.waNumber}?text=${encodeURIComponent(
    `Halo ${OWNER_CONFIG.brandName}, saya ingin membeli langsung *Kode Lisensi SellerMetrics v5.0 Ultimate Full Suite (${OWNER_CONFIG.hargaLisensiV5})* (Termasuk 13 Modul Eksekutif: Bundling, Multi-MP, GMV Max Ads, Live Host BEP, Voucher Guard, Komisi Affiliate & Flash Sale). Mohon info pembayarannya.`
  )}`;

  const waUpgradeV5Url = `https://wa.me/${OWNER_CONFIG.waNumber}?text=${encodeURIComponent(
    `Halo ${OWNER_CONFIG.brandName}, saya pengguna Toko *${licensedStore}* dan ingin *Upgrade ke Lisensi v5.0 Ultimate (${OWNER_CONFIG.hargaUpgradeV5})* untuk membuka 13 Modul Super Suite (Bundling, Multi-MP, GMV Max Ads, Live Host BEP, Voucher Guard, Affiliate Creator & Proteksi Retur COD).`
  )}`;

  const waSourceCodeUrl = `https://wa.me/${OWNER_CONFIG.waNumber}?text=${encodeURIComponent(
    `Halo ${OWNER_CONFIG.brandName}, saya tertarik membeli *Source Code White-Label SellerMetrics Pro (${OWNER_CONFIG.hargaSourceCode})* agar bisa saya jual kembali. Bisa minta infonya?`
  )}`;

  const waJasaWebUrl = `https://wa.me/${OWNER_CONFIG.waNumber}?text=${encodeURIComponent(
    `Halo ${OWNER_CONFIG.brandName}, saya ingin konsultasi pembuatan *Website Katalog / Toko Online* untuk bisnis saya.`
  )}`;

  const currentPrintDate = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div
      className={`min-h-screen bg-[#080B12] text-slate-100 pb-16 sm:pb-20 relative overflow-x-hidden ${
        themeMode === 'light' ? 'theme-light' : ''
      }`}
    >
      {/* Subtle Ambient Executive Background Lighting */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden no-print">
        <div className="absolute -top-48 left-1/2 -translate-x-1/2 w-[100vw] max-w-[900px] h-[420px] bg-gradient-to-b from-orange-500/[0.07] via-amber-500/[0.03] to-transparent blur-3xl rounded-full" />
        <div className="absolute top-1/3 -right-48 w-[80vw] max-w-[500px] h-[500px] bg-indigo-500/[0.04] blur-3xl rounded-full" />
      </div>

      {/* 1. LAYAR KUNCI LISENSI (LICENSE GATE) */}
      {!isUnlocked && (
        <LicenseGateScreen
          handleOpenAdminPrompt={handleOpenAdminPrompt}
          demoExpiredNotice={demoExpiredNotice}
          handleVerifikasiLisensi={handleVerifikasiLisensi}
          inputNamaToko={inputNamaToko}
          setInputNamaToko={setInputNamaToko}
          inputKodeLisensi={inputKodeLisensi}
          setInputKodeLisensi={setInputKodeLisensi}
          pesanErrorLisensi={pesanErrorLisensi}
          handleMulaiDemoGratis={handleMulaiDemoGratis}
          waLisensiV5Url={waLisensiV5Url}
          waLisensiUrl={waLisensiUrl}
          isInstalled={isInstalled}
          handleInstallAplikasi={handleInstallAplikasi}
          themeMode={themeMode}
          onToggleTheme={handleToggleTheme}
          demoUsedCount={demoUsedCount}
        />
      )}

      {/* 2. MODAL VERIFIKASI PIN & KEYGEN OWNER */}
      <OwnerKeygenModals
        showPinDialog={showPinDialog}
        setShowPinDialog={setShowPinDialog}
        adminPinInput={adminPinInput}
        setAdminPinInput={setAdminPinInput}
        adminPinError={adminPinError}
        handleVerifyAdminPin={handleVerifyAdminPin}
        showKeygenModal={showKeygenModal}
        setShowKeygenModal={setShowKeygenModal}
        keygenTier={keygenTier}
        setKeygenTier={setKeygenTier}
        keygenNamaInput={keygenNamaInput}
        setKeygenNamaInput={setKeygenNamaInput}
        keygenWaInput={keygenWaInput}
        setKeygenWaInput={setKeygenWaInput}
        currentKeygenCode={currentKeygenCode}
        keygenCopied={keygenCopied}
        handleSalinPaketLisensiPembeli={handleSalinPaketLisensiPembeli}
        handleKirimWaPembeliLangsung={handleKirimWaPembeliLangsung}
        buyerHistory={buyerHistory}
        copiedHistoryId={copiedHistoryId}
        handleSalinUlangRiwayatPembeli={handleSalinUlangRiwayatPembeli}
        handleKirimWaDariRiwayat={handleKirimWaDariRiwayat}
        handleHapusRiwayatPembeli={handleHapusRiwayatPembeli}
        handleExportRiwayatPembeliCSV={handleExportRiwayatPembeliCSV}
        onResetDemoQuota={handleResetDemoQuota}
      />

      {/* 2B & 2C. MODAL INSTALL PWA, PANDUAN CEPAT & AUDIT KEAMANAN */}
      <GuideAndInstallModals
        showInstallModal={showInstallModal}
        setShowInstallModal={setShowInstallModal}
        isIOS={isIOS}
        showGuideModal={showGuideModal}
        setShowGuideModal={setShowGuideModal}
        showSecurityModal={showSecurityModal}
        setShowSecurityModal={setShowSecurityModal}
      />

      {/* 3. TOP NAVBAR & DEMO TIMER BAR */}
      {isDemoMode && (
        <div className="bg-gradient-to-r from-rose-600 via-orange-600 to-amber-600 text-white px-3 sm:px-4 py-2 text-xs font-semibold no-print">
          <div className="max-w-6xl mx-auto flex flex-wrap justify-between items-center gap-2">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 shrink-0" />
              <span>
                MODE DEMO ({Math.min(3, demoUsedCount)}/3x Percobaan) · Sisa:{' '}
                <strong className="font-mono font-extrabold underline">
                  {demoTimerFormatted}
                </strong>
              </span>
            </div>
            <a
              href={waLisensiV5Url}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-slate-950/90 hover:bg-slate-950 text-amber-300 px-2.5 sm:px-3 py-1 rounded-lg text-[11px] font-bold transition-colors inline-flex items-center gap-1"
            >
              <Crown className="w-3 h-3 shrink-0" />
              <span>Beli v5.0 Ultimate</span>
              <ArrowUpRight className="w-3 h-3 shrink-0" />
            </a>
          </div>
        </div>
      )}

      {/* Responsive Header across Mobile, Tablet, Laptop & Desktop */}
      <header className="border-b border-slate-800/80 bg-[#080B12]/90 sticky top-0 z-30 backdrop-blur-xl no-print">
        <div className="max-w-6xl mx-auto px-3 sm:px-6 py-2.5 md:py-0 md:h-16 flex flex-col md:flex-row md:items-center md:justify-between gap-2.5 md:gap-6">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-sm shrink-0">
                SM
              </div>
              <span className="font-extrabold text-white text-sm sm:text-base tracking-tight">
                SellerMetrics <span className="text-orange-400">Pro</span>
              </span>
            </div>

            <div className="flex items-center gap-1.5 md:hidden">
              <button
                type="button"
                onClick={handleToggleTheme}
                title="Ganti Mode Terang / Gelap"
                className="bg-[#0E131F] text-slate-300 border border-slate-800 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1 shrink-0 cursor-pointer"
              >
                {themeMode === 'light' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Gelap</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span>Terang</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleKunciKembali}
                title="Kunci / Ganti Lisensi"
                className="bg-[#0E131F] hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 border border-slate-800 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Kunci</span>
              </button>
            </div>
          </div>

          <nav className="grid grid-cols-2 sm:grid-cols-4 md:flex items-center gap-1 bg-[#0E131F] p-1 rounded-xl border border-slate-800/90 w-full md:w-auto">
            <button
              type="button"
              onClick={() => setActiveMenu('kalkulator')}
              className={`px-2 sm:px-3 py-2 md:py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMenu === 'kalkulator'
                  ? 'bg-orange-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Kalkulator</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveMenu('proyeksi')}
              className={`px-2 sm:px-3 py-2 md:py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMenu === 'proyeksi'
                  ? 'bg-orange-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Simulasi</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveMenu('v5suite')}
              className={`px-2 sm:px-3 py-2 md:py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMenu === 'v5suite'
                  ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 font-extrabold shadow-sm'
                  : 'text-amber-300 hover:text-amber-200'
              }`}
            >
              <Crown className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Super Suite</span>
              <span
                className={`text-[9px] font-mono font-extrabold px-1 py-0.2 rounded ${
                  activeMenu === 'v5suite'
                    ? 'bg-slate-950/25 text-slate-950'
                    : 'bg-amber-500/20 text-amber-300'
                }`}
              >
                v5.0
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveMenu('database')}
              className={`px-2 sm:px-3 py-2 md:py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMenu === 'database'
                  ? 'bg-orange-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Package className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">SKU ({skuDatabase.length})</span>
            </button>
          </nav>

          <div className="hidden md:flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleToggleTheme}
              title="Ganti Mode Terang / Mode Gelap"
              className="bg-[#0E131F] hover:bg-slate-800/80 text-slate-300 border border-slate-800 px-3 py-2 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {themeMode === 'light' ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Mode Gelap</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Mode Terang</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={handleKunciKembali}
              title="Kunci / Ganti Lisensi"
              className="bg-[#0E131F] hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 border border-slate-800 hover:border-rose-800/50 px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Kunci</span>
            </button>
          </div>
        </div>
      </header>

      {/* 4. ISI UTAMA APLIKASI (4 MENU TAB) */}
      <main className="max-w-6xl mx-auto px-3 sm:px-6 mt-4 sm:mt-6 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-5 pb-3.5 border-b border-slate-800/60 no-print">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] sm:text-xs text-slate-400">
            <span className="font-semibold text-slate-200">
              Enterprise E-Commerce Margin, ROAS &amp; Profit Intelligence
            </span>
            <span aria-hidden="true" className="hidden sm:inline text-slate-600">
              ·
            </span>
            <span className="text-emerald-400 font-medium inline-flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              <span>Licensed: {licensedStore}</span>
            </span>
            <span aria-hidden="true" className="text-slate-600">
              ·
            </span>
            {licenseTier === 'v5' ? (
              <span className="text-amber-300 font-bold inline-flex items-center gap-1 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-md">
                <Crown className="w-3 h-3 shrink-0" />
                <span>v5.0 Ultimate</span>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => setActiveMenu('v5suite')}
                className="text-orange-300 hover:text-amber-200 font-semibold inline-flex items-center gap-1 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 px-2 py-0.5 rounded-md transition-colors cursor-pointer"
              >
                <span>v4.0 Pro</span>
                <span className="text-amber-300 underline ml-1">
                  Upgrade v5.0 →
                </span>
              </button>
            )}
            {!isOnline && (
              <>
                <span aria-hidden="true" className="text-slate-600">
                  ·
                </span>
                <span className="text-amber-300 font-semibold inline-flex items-center gap-1 bg-amber-500/10 border border-amber-500/25 px-2 py-0.5 rounded-md">
                  <WifiOff className="w-3 h-3 shrink-0" />
                  <span>Mode Offline Aktif</span>
                </span>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {toastMessage && (
              <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/25 px-3 py-1 rounded-lg">
                <Check className="w-3.5 h-3.5 shrink-0" />
                <span>{toastMessage}</span>
              </div>
            )}
            {toastMessage && (
              <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/95 border border-emerald-500/50 text-emerald-200 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold whitespace-nowrap backdrop-blur-md no-print">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 stroke-[2.5]" />
                <span>{toastMessage}</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowSecurityModal(true)}
              className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              title="Lihat Audit Keamanan Arsitektur Zero-Server (Kebal Isu Node.js)"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Status Aman</span>
            </button>

            <button
              type="button"
              onClick={() => setShowGuideModal(true)}
              className="bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700/80 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5 text-orange-400 shrink-0" />
              <span>Panduan</span>
            </button>

            {!isInstalled && (
              <button
                type="button"
                onClick={handleInstallAplikasi}
                className="bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span>Install Aplikasi</span>
              </button>
            )}
          </div>
        </div>

        {/* MENU 1: KALKULATOR HPP, HARGA CORET & ROAS IKLAN */}
        {activeMenu === 'kalkulator' && (
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
            {/* Kolom Kiri: Input Parameter */}
            <div className="lg:col-span-7 space-y-4 sm:space-y-5">
              {/* Preset Studi Kasus 1-Klik & Asisten HPP Kulakan / Reject */}
              <HppAndCaseStudyPanel
                onApplyCaseStudy={handleApplyCaseStudy}
                onApplyLandedHpp={(hppBersih) => {
                  setCustomHargaFinal(null);
                  setInHpp(hppBersih);
                  triggerToast(
                    `HPP Kulakan Bersih (${rp(hppBersih)}/pcs) diterapkan ke Kalkulator!`
                  );
                }}
                skuKode={skuKode}
                skuNama={skuNama}
                hargaCoret={calcResult.hargaCoret}
                hargaJualFinal={calcResult.hargaJualFinal}
                diskonCoretPct={calcResult.diskonCoretPct}
                batasHargaBawahImpas={
                  1 - calcResult.totalPctFee / 100 > 0.05
                    ? Math.ceil(
                        (calcResult.totalModal + (Number(inBiayaProses) || 0)) /
                          (1 - calcResult.totalPctFee / 100)
                      )
                    : calcResult.totalModal
                }
                onToast={triggerToast}
              />

              {/* Sub-Mode Switcher */}
              <div className="bg-[#0E131F] p-2 rounded-2xl border border-slate-800/90 space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setCalcMode('ideal');
                      setCustomHargaFinal(null);
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer text-center ${
                      calcMode === 'ideal'
                        ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Target className="w-3.5 h-3.5 shrink-0" />
                    <span>Cari Harga Jual Ideal (Target Untung)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCalcMode('kompetitor');
                      setCustomHargaFinal(null);
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer text-center ${
                      calcMode === 'kompetitor'
                        ? 'bg-gradient-to-r from-sky-400 to-blue-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Search className="w-3.5 h-3.5 shrink-0" />
                    <span>Audit Harga Kompetitor (Cek Margin)</span>
                  </button>
                </div>
                <div className="px-2.5 py-1.5 rounded-xl bg-[#090D16]/80 border border-slate-800/70 text-[11px] text-slate-400 flex items-start gap-2">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {calcMode === 'ideal' ? (
                      <>
                        <strong className="text-amber-300">
                          Cara Pakai Mode Ideal:
                        </strong>{' '}
                        Kamu tentukan mau untung bersih berapa Rupiah per pcs,
                        lalu sistem menghitungkan{' '}
                        <strong className="text-white">Harga Jual Final</strong>{' '}
                        yang wajib dipasang di toko agar tidak tergerus potongan
                        admin.
                      </>
                    ) : (
                      <>
                        <strong className="text-sky-300">
                          Cara Pakai Mode Kompetitor:
                        </strong>{' '}
                        Masukkan harga jual pasaran/kompetitor, lalu sistem
                        membongkar berapa{' '}
                        <strong className="text-white">
                          Sisa Untung Bersihmu
                        </strong>{' '}
                        setelah dipotong admin &amp; iklan.
                      </>
                    )}
                  </span>
                </div>
              </div>

              {/* Step 1: Preset Marketplace & Kategori Produk (2026) */}
              <div className="bg-[#0E131F] p-4 sm:p-5 rounded-2xl border border-slate-800/90 space-y-4">
                <div>
                  <div className="flex flex-wrap justify-between items-center gap-1.5 mb-2.5">
                    <h2 className="text-xs font-bold text-slate-200 tracking-wide">
                      01. Pilih Platform Marketplace &amp; Kategori Barang
                      (2026)
                    </h2>
                    <span className="text-[11px] text-orange-400 font-medium">
                      1-Klik Isi Otomatis Biaya Admin
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5">
                    {PRESETS_MP.map((preset) => {
                      const isSelected = selectedPreset === preset.id;
                      const activeKat = PRESETS_KATEGORI.find(
                        (k) => k.id === selectedCategory
                      );
                      const admRate =
                        activeKat?.rates[preset.id] ?? preset.adm;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => handlePilihPresetMP(preset)}
                          className={`p-2.5 sm:p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'border-orange-500/60 bg-orange-500/10 shadow-sm'
                              : 'border-slate-800/90 bg-[#090D16]/70 hover:border-slate-700'
                          }`}
                        >
                          <div className="text-xs font-bold text-white leading-snug">
                            {preset.name}
                          </div>
                          <div
                            className={`text-[10px] sm:text-[11px] font-mono mt-1 leading-tight ${
                              isSelected ? 'text-orange-300' : 'text-slate-400'
                            }`}
                          >
                            Adm {admRate}% + Xtra {preset.ongkir}%
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Pilihan Kategori Produk */}
                <div className="pt-3 border-t border-slate-800/80">
                  <div className="flex flex-wrap items-center justify-between gap-1 mb-2">
                    <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>
                        Pilih Kategori Produk (Otomatis Sesuaikan % Admin
                        Kategori A–E):
                      </span>
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 sm:gap-2">
                    {PRESETS_KATEGORI.map((kat) => {
                      const isKatSelected = selectedCategory === kat.id;
                      const rateForCurrentMp =
                        kat.rates[selectedPreset] ?? inAdminPct;
                      return (
                        <button
                          key={kat.id}
                          type="button"
                          onClick={() => handlePilihKategori(kat)}
                          className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                            isKatSelected
                              ? 'border-amber-400/70 bg-amber-500/15 shadow-sm ring-1 ring-amber-500/25'
                              : 'border-slate-800 bg-[#090D16]/70 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[11px] font-extrabold text-white truncate">
                              {kat.name}
                            </span>
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-[9px] font-mono text-slate-400">
                              {kat.katLabel}
                            </span>
                            <span
                              className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                                isKatSelected
                                  ? 'bg-amber-500/25 text-amber-300'
                                  : 'bg-slate-800 text-slate-300'
                              }`}
                            >
                              Adm {rateForCurrentMp}%
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Step 2: Data Produk & Modal */}
              <div className="bg-[#0E131F] p-4 sm:p-5 rounded-2xl border border-slate-800/90 space-y-4">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 border-b border-slate-800/80 pb-3.5">
                  <h2 className="text-xs font-bold text-slate-200 tracking-wide">
                    02. Struktur HPP &amp; Target Profit
                  </h2>
                  <div className="grid grid-cols-1 sm:flex gap-2 w-full sm:w-auto">
                    <input
                      type="text"
                      value={skuKode}
                      onChange={(e) => setSkuKode(e.target.value)}
                      placeholder="Kode SKU (Mis: BJ-01)"
                      className="bg-[#090D16] text-xs text-amber-300 px-3 py-2 rounded-lg border border-slate-800 focus:border-orange-500 focus:outline-none w-full sm:w-36 font-mono placeholder:text-slate-600"
                    />
                    <input
                      type="text"
                      value={skuNama}
                      onChange={(e) => setSkuNama(e.target.value)}
                      placeholder="Nama Produk..."
                      className="bg-[#090D16] text-xs text-white px-3 py-2 rounded-lg border border-slate-800 focus:border-orange-500 focus:outline-none w-full sm:w-48 placeholder:text-slate-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
                      HPP / Harga Modal Pabrik (Rp)
                    </label>
                    <input
                      type="number"
                      value={inHpp}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInHpp(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-white p-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono font-bold text-sm tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
                      Biaya Packing + Bubble (Rp)
                    </label>
                    <input
                      type="number"
                      value={inPacking}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInPacking(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-white p-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono font-semibold text-sm tabular-nums"
                    />
                  </div>

                  {calcMode === 'ideal' ? (
                    <div>
                      <label className="block text-[11px] font-bold text-emerald-400 mb-1.5">
                        Target Untung Bersih / Pcs (Rp)
                      </label>
                      <input
                        type="number"
                        value={inTargetUntung}
                        onChange={(e) => {
                          setCustomHargaFinal(null);
                          setInTargetUntung(parseFloat(e.target.value) || 0);
                        }}
                        className="w-full bg-emerald-950/25 text-emerald-300 p-3 rounded-xl border border-emerald-500/40 focus:border-emerald-400 focus:outline-none font-mono font-extrabold text-sm tabular-nums"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[11px] font-bold text-sky-400 mb-1.5">
                        Harga Jual Kompetitor (Rp)
                      </label>
                      <input
                        type="number"
                        value={inHargaKompetitor}
                        onChange={(e) =>
                          setInHargaKompetitor(parseFloat(e.target.value) || 0)
                        }
                        className="w-full bg-sky-950/25 text-sky-300 p-3 rounded-xl border border-sky-500/40 focus:border-sky-400 focus:outline-none font-mono font-extrabold text-sm tabular-nums"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Step 3: Potongan Persentase, Biaya Tetap, Budget Iklan & Risiko Retur COD (v5.0) */}
              <div className="bg-[#0E131F] p-4 sm:p-5 rounded-2xl border border-slate-800/90 space-y-4">
                <h2 className="text-xs font-bold text-slate-200 tracking-wide border-b border-slate-800/80 pb-3.5">
                  03. Potongan Marketplace, Iklan &amp; Strategi Harga Coret
                </h2>

                <div className="grid grid-cols-3 gap-2.5 sm:gap-3.5">
                  <div className="flex flex-col justify-between">
                    <label className="block text-[10px] sm:text-[11px] font-medium text-slate-400 mb-1.5 leading-tight">
                      Biaya Admin (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={inAdminPct}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInAdminPct(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none text-center font-mono font-bold text-sm tabular-nums"
                    />
                  </div>
                  <div className="flex flex-col justify-between">
                    <label className="block text-[10px] sm:text-[11px] font-medium text-slate-400 mb-1.5 leading-tight">
                      Ongkir Xtra (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={inOngkirPct}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInOngkirPct(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none text-center font-mono font-bold text-sm tabular-nums"
                    />
                  </div>
                  <div className="flex flex-col justify-between">
                    <label className="block text-[10px] sm:text-[11px] font-medium text-slate-400 mb-1.5 leading-tight">
                      Affiliate (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={inAffPct}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInAffPct(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-white p-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none text-center font-mono font-bold text-sm tabular-nums"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
                      Biaya Proses Order (Rp)
                    </label>
                    <input
                      type="number"
                      value={inBiayaProses}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInBiayaProses(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-slate-200 p-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
                      Voucher Toko (Rp)
                    </label>
                    <input
                      type="number"
                      value={inVoucherToko}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInVoucherToko(parseFloat(e.target.value) || 0);
                      }}
                      className="w-full bg-[#090D16] text-slate-200 p-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-indigo-300 mb-1.5">
                      Budget Iklan / Pcs (Opsional)
                    </label>
                    <input
                      type="number"
                      value={inBiayaIklanPcs}
                      onChange={(e) => {
                        setCustomHargaFinal(null);
                        setInBiayaIklanPcs(parseFloat(e.target.value) || 0);
                      }}
                      placeholder="0"
                      className="w-full bg-indigo-950/20 text-indigo-200 p-2.5 rounded-xl border border-indigo-500/35 focus:border-indigo-400 focus:outline-none font-mono font-bold text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-400 mb-1.5">
                      Rencana % Diskon Coret
                    </label>
                    <input
                      type="number"
                      value={inDiskonCoretPct}
                      onChange={(e) =>
                        setInDiskonCoretPct(parseFloat(e.target.value) || 0)
                      }
                      className="w-full bg-amber-950/20 text-amber-300 p-2.5 rounded-xl border border-amber-500/40 focus:border-amber-400 focus:outline-none text-center font-mono font-extrabold text-sm tabular-nums"
                    />
                  </div>
                </div>

                {/* FITUR EKSKLUSIF v5.0: Cadangan Risiko Paket Gagal Kirim / Retur COD (RTS Guard) */}
                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-rose-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>
                        Proteksi Risiko Retur COD / Paket Gagal Kirim (RTS):
                      </span>
                      <span className="text-[9px] font-mono font-extrabold bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/30 inline-flex items-center gap-1">
                        <Crown className="w-2.5 h-2.5" />
                        <span>v5.0</span>
                      </span>
                    </span>
                    {isV5Unlocked ? (
                      <span className="text-[11px] font-mono text-slate-400">
                        Cadangan:{' '}
                        <strong className="text-rose-300">
                          {rp(calcResult.cadanganRtsPcs)}/pcs
                        </strong>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          handlePromptUpgradeV5('Proteksi Risiko Retur COD')
                        }
                        className="text-[10px] font-bold text-amber-300 hover:text-amber-200 underline cursor-pointer"
                      >
                        Buka Proteksi COD (v5.0) →
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                    {[
                      { label: '0% (Non-COD)', val: 0 },
                      { label: '2% (Aman)', val: 2 },
                      { label: '5% (Wajar)', val: 5 },
                      { label: '8% (Tinggi)', val: 8 },
                      { label: '10% (Rawan)', val: 10 },
                    ].map((opt) => {
                      const active = calcResult.rtsCodPct === opt.val;
                      const isLockedOpt = !isV5Unlocked && opt.val > 0;
                      return (
                        <button
                          key={opt.val}
                          type="button"
                          onClick={() => {
                            if (isLockedOpt) {
                              handlePromptUpgradeV5(
                                'Proteksi Risiko Retur COD (RTS)'
                              );
                              return;
                            }
                            setCustomHargaFinal(null);
                            setInRtsCodPct(opt.val);
                          }}
                          className={`py-2 px-2 rounded-lg border text-[11px] font-mono font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                            active
                              ? 'bg-rose-500/20 border-rose-400 text-rose-200 shadow-sm'
                              : isLockedOpt
                              ? 'bg-[#090D16]/60 hover:bg-amber-500/10 border-amber-500/25 text-slate-400'
                              : 'bg-[#090D16] hover:bg-slate-800 border-slate-800 text-slate-400'
                          }`}
                        >
                          {isLockedOpt && (
                            <Lock className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                          )}
                          <span>{opt.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Kolom Kanan: Output Executive Summary & ROAS */}
            <div className="lg:col-span-5">
              <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-slate-800/90 shadow-2xl space-y-4 sm:space-y-5 lg:sticky lg:top-22 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-orange-500 via-amber-400 to-emerald-400" />

                {/* Output Utama */}
                <div className="space-y-3 border-b border-slate-800/80 pb-4">
                  <div className="flex flex-wrap justify-between items-start gap-3">
                    <div className="min-w-0">
                      <span className="text-[10px] sm:text-[11px] font-bold text-orange-400 tracking-wide uppercase block">
                        {calcMode === 'ideal'
                          ? customHargaFinal
                            ? 'Harga Jual Final (Dibulatkan Psikologis)'
                            : 'Harga Jual Final (Setelah Diskon)'
                          : 'Sisa Profit Bersih Per Pcs'}
                      </span>
                      <div className="text-2xl sm:text-3xl xl:text-4xl font-mono font-extrabold text-white mt-1 tabular-nums tracking-tight break-words">
                        {calcMode === 'ideal'
                          ? rp(calcResult.hargaJualFinal)
                          : rp(calcResult.profitBersih)}
                      </div>
                    </div>

                    <div className="text-left sm:text-right shrink-0 ml-auto">
                      {calcResult.profitBersih <= 0 ? (
                        <div className="inline-flex items-center gap-1.5 text-rose-400 text-xs font-bold">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                          <span>BONCOS / RUGI</span>
                        </div>
                      ) : calcResult.netMarginPctNum < 12 ? (
                        <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-bold">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                          <span>MARGIN TIPIS</span>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                          <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                          <span>MARGIN SEHAT</span>
                        </div>
                      )}
                      <div className="text-xs text-slate-400 mt-1">
                        Net Margin:{' '}
                        <strong className="font-mono text-white tabular-nums">
                          {calcResult.netMarginPct}%
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Tombol 1-Klik Bulatkan ke Harga Psikologis */}
                  {calcResult.opsiPsikologis.length > 0 && (
                    <div className="bg-[#090D16] p-2.5 sm:p-3 rounded-xl border border-slate-800/90 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-1">
                        <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span>
                            Bulatkan ke Harga Cantik / Psikologis (1-Klik):
                          </span>
                        </span>
                        {calcMode === 'ideal' && customHargaFinal !== null && (
                          <button
                            type="button"
                            onClick={() => {
                              setCustomHargaFinal(null);
                              triggerToast(
                                `Dikembalikan ke Harga Ideal Murni: ${rp(calcResult.hargaIdealMurni)}`
                              );
                            }}
                            className="text-[10px] font-semibold text-slate-400 hover:text-white underline cursor-pointer"
                          >
                            Reset ({rp(calcResult.hargaIdealMurni)})
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                        {calcResult.opsiPsikologis.map((op) => {
                          const isCurrent =
                            calcResult.hargaJualFinal === op.harga;
                          return (
                            <button
                              key={op.harga}
                              type="button"
                              onClick={() =>
                                handleTerapkanHargaPsikologis(op.harga, op.laba)
                              }
                              className={`p-2 rounded-lg border text-left transition-all cursor-pointer ${
                                isCurrent
                                  ? 'bg-amber-500/20 border-amber-400/70 ring-1 ring-amber-400/30'
                                  : 'bg-[#0E131F] hover:bg-slate-800/80 border-slate-800'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-[10px] text-slate-400 font-medium">
                                  {op.label}
                                </span>
                                {isCurrent && (
                                  <span className="text-[9px] font-bold text-amber-300">
                                    AKTIF
                                  </span>
                                )}
                              </div>
                              <div className="text-xs font-mono font-extrabold text-amber-300 mt-0.5 tabular-nums">
                                {rp(op.harga)}
                              </div>
                              <div className="text-[10px] font-mono text-emerald-400 tabular-nums">
                                Laba: {rp(op.laba)}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Box Harga Coret */}
                <div className="bg-amber-500/[0.07] border border-amber-500/25 p-3.5 sm:p-4 rounded-xl flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                  <div>
                    <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 shrink-0" />
                      <span>Pasang Harga Sebelum Diskon (Harga Coret):</span>
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      Agar setelah diskon{' '}
                      <strong className="font-mono text-amber-200">
                        {calcResult.diskonCoretPct}%
                      </strong>{' '}
                      menjadi harga final di atas
                    </span>
                  </div>
                  <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 line-through decoration-rose-500 decoration-2 shrink-0 tabular-nums sm:text-right">
                    {rp(calcResult.hargaCoret)}
                  </div>
                </div>

                {/* Progress Bar Komposisi */}
                <div>
                  <div className="flex flex-wrap justify-between gap-2 text-[11px] text-slate-400 mb-2 font-medium">
                    <span>
                      Modal:{' '}
                      <strong className="font-mono text-sky-400">
                        {calcResult.pModal}%
                      </strong>
                    </span>
                    <span>
                      Fee &amp; Ads:{' '}
                      <strong className="font-mono text-rose-400">
                        {calcResult.pFee}%
                      </strong>
                    </span>
                    <span>
                      Profit:{' '}
                      <strong className="font-mono text-emerald-400">
                        {calcResult.pProfit}%
                      </strong>
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#090D16] rounded-full overflow-hidden flex p-0.5 border border-slate-800/80">
                    <div
                      className="bg-sky-500 h-full transition-all duration-150 rounded-l-full"
                      style={{ width: `${calcResult.pModal}%` }}
                    />
                    <div
                      className="bg-rose-500 h-full transition-all duration-150"
                      style={{ width: `${calcResult.pFee}%` }}
                    />
                    <div
                      className="bg-emerald-500 h-full transition-all duration-150 rounded-r-full"
                      style={{ width: `${calcResult.pProfit}%` }}
                    />
                  </div>
                </div>

                {/* Breakdown Rincian */}
                <div className="border-t border-b border-slate-800/80 py-3.5 sm:py-4 space-y-2.5 text-xs">
                  <div className="flex justify-between items-center gap-2 text-slate-400">
                    <span>Total Modal (HPP + Packing):</span>
                    <span className="font-mono font-bold text-sky-400 tabular-nums shrink-0">
                      {rp(calcResult.totalModal)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center gap-2 text-slate-400">
                    <span>
                      Potongan Komisi Platform (
                      <span className="font-mono">
                        {calcResult.totalPctFee.toFixed(1)}%
                      </span>
                      ):
                    </span>
                    <span className="font-mono font-bold text-rose-400 tabular-nums shrink-0">
                      - {rp(calcResult.nominalFeePct)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center gap-2 text-slate-400">
                    <span>Biaya Proses + Voucher Toko:</span>
                    <span className="font-mono font-bold text-rose-400 tabular-nums shrink-0">
                      - {rp(calcResult.totalPotonganTetap)}
                    </span>
                  </div>
                  {calcResult.cadanganRtsPcs > 0 && (
                    <div className="flex justify-between items-center gap-2 text-rose-300">
                      <span>
                        Cadangan Risiko Retur COD ({calcResult.rtsCodPct}%):
                      </span>
                      <span className="font-mono font-bold text-rose-300 tabular-nums shrink-0">
                        - {rp(calcResult.cadanganRtsPcs)}
                      </span>
                    </div>
                  )}
                  {calcResult.biayaIklanPcs > 0 && (
                    <div className="flex justify-between items-center gap-2 text-indigo-300">
                      <span className="inline-flex items-center gap-1">
                        <Megaphone className="w-3 h-3 shrink-0" />
                        <span>Budget Iklan Aktual / Pcs:</span>
                      </span>
                      <span className="font-mono font-bold text-indigo-300 tabular-nums shrink-0">
                        - {rp(calcResult.biayaIklanPcs)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between items-center gap-2 text-slate-200 pt-2.5 border-t border-slate-800/60 font-bold text-xs sm:text-sm">
                    <span>Dana Cair Bersih (Payout Seller):</span>
                    <span className="font-mono text-white tabular-nums shrink-0">
                      {rp(calcResult.danaCair)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center gap-2 text-emerald-400 font-extrabold text-sm sm:text-base pt-1">
                    <span>
                      {calcResult.biayaIklanPcs > 0
                        ? 'Profit Bersih / Pcs (Setelah Iklan):'
                        : 'Profit Bersih / Pcs (Sebelum Iklan):'}
                    </span>
                    <span className="font-mono tabular-nums shrink-0">
                      {rp(calcResult.profitBersih)}
                    </span>
                  </div>
                </div>

                {/* ROAS Guard + Simulator Target ROAS GMV Max (Eksklusif v5.0) */}
                <div className="bg-indigo-950/25 border border-indigo-500/25 p-3.5 sm:p-4 rounded-xl space-y-3">
                  <div className="flex flex-wrap justify-between items-center gap-1">
                    <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                      <BarChart3 className="w-3.5 h-3.5 shrink-0" />
                      <span>ROAS Guard (Batas Aman Iklan)</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowAwamGuide((p) => !p)}
                      className="text-[10px] sm:text-[11px] text-amber-300 hover:text-amber-200 font-semibold underline cursor-pointer"
                    >
                      {showAwamGuide
                        ? 'Sembunyikan Arti'
                        : '💡 Apa Artinya Ini?'}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 sm:gap-3 border-t border-b border-indigo-500/15 py-2.5">
                    <div>
                      <span className="text-[10px] sm:text-[11px] text-slate-400 block leading-snug">
                        Batas Max Biaya Iklan/Pcs
                      </span>
                      <span className="text-xs sm:text-sm font-mono font-extrabold text-white tabular-nums mt-0.5 block">
                        {rp(calcResult.maxCpa)}
                      </span>
                    </div>
                    <div className="border-l border-indigo-500/15 pl-2.5 sm:pl-3">
                      <span className="text-[10px] sm:text-[11px] text-slate-400 block leading-snug">
                        Minimal Target ROAS Impas
                      </span>
                      <span className="text-xs sm:text-sm font-mono font-extrabold text-amber-400 tabular-nums mt-0.5 block">
                        {calcResult.minRoas}x
                      </span>
                    </div>
                  </div>

                  {/* FITUR EKSKLUSIF v5.0: Matriks 1-Klik Simulator Target ROAS GMV Max */}
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-1 text-[10px] sm:text-[11px] text-indigo-200 font-semibold">
                      <span className="inline-flex items-center gap-1">
                        <span>🎯 Simulator Target ROAS GMV Max:</span>
                        <span className="text-[9px] font-mono font-extrabold bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30 inline-flex items-center gap-0.5">
                          <Crown className="w-2.5 h-2.5" />
                          <span>v5.0</span>
                        </span>
                      </span>
                      {isV5Unlocked && inBiayaIklanPcs > 0 ? (
                        <button
                          type="button"
                          onClick={() => setInBiayaIklanPcs(0)}
                          className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
                        >
                          Reset Iklan (Rp 0)
                        </button>
                      ) : !isV5Unlocked ? (
                        <button
                          type="button"
                          onClick={() =>
                            handlePromptUpgradeV5(
                              'Simulator Target ROAS GMV Max'
                            )
                          }
                          className="text-[10px] text-amber-300 hover:text-amber-200 font-bold underline cursor-pointer"
                        >
                          Buka di v5.0 →
                        </button>
                      ) : null}
                    </div>
                    <div className="grid grid-cols-5 gap-1">
                      {calcResult.gmvMaxSimulations.map((sim) => {
                        const isSelected =
                          isV5Unlocked &&
                          inBiayaIklanPcs > 0 &&
                          Math.abs(inBiayaIklanPcs - sim.cpaGmv) <= 50;
                        return (
                          <button
                            key={sim.roas}
                            type="button"
                            onClick={() =>
                              handleTerapkanGmvMaxRoas(sim.roas, sim.cpaGmv)
                            }
                            className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-500/30 border-indigo-400 ring-1 ring-indigo-400/40'
                                : !isV5Unlocked
                                ? 'bg-[#090D16]/60 hover:bg-amber-500/10 border-amber-500/25'
                                : 'bg-[#090D16]/90 hover:bg-slate-800 border-slate-800'
                            }`}
                            title={
                              isV5Unlocked
                                ? `Target ROAS ${sim.roas}x → Iklan ${rp(sim.cpaGmv)}/pcs | Sisa Laba: ${rp(sim.sisaLaba)}/pcs`
                                : 'Fitur Eksklusif v5.0 Ultimate — Klik untuk Upgrade'
                            }
                          >
                            <div className="text-[10px] font-mono font-extrabold text-indigo-300 flex items-center justify-center gap-0.5">
                              {!isV5Unlocked && (
                                <Lock className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                              )}
                              <span>{sim.roas}x</span>
                            </div>
                            <div className="text-[9px] font-mono text-slate-400 truncate">
                              {isV5Unlocked
                                ? `-${Math.round(sim.cpaGmv / 1000)}rb`
                                : 'v5.0'}
                            </div>
                            <div
                              className={`text-[9px] font-mono font-bold truncate ${
                                !isV5Unlocked
                                  ? 'text-amber-300'
                                  : sim.isBepOrLoss
                                  ? 'text-rose-400'
                                  : sim.isSafe
                                  ? 'text-emerald-400'
                                  : 'text-amber-300'
                              }`}
                            >
                              {!isV5Unlocked
                                ? 'Buka'
                                : sim.sisaLaba >= 0
                                ? `+${Math.round(sim.sisaLaba / 1000)}rb`
                                : `${Math.round(sim.sisaLaba / 1000)}rb`}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Supaya masih kantongi untung bersih{' '}
                    <strong className="text-white">50% dari margin</strong>,
                    pastikan ROAS iklan di atas{' '}
                    <strong className="font-mono text-emerald-400 tabular-nums">
                      {calcResult.safeRoas}x
                    </strong>
                    .
                  </p>

                  {showAwamGuide && (
                    <div className="bg-[#090D16]/90 border border-indigo-500/20 rounded-lg p-2.5 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                      <div className="font-bold text-amber-300">
                        💡 Panduan Bahasa Awam (Untuk Iklan Shopee / TikTok):
                      </div>
                      <p>
                        •{' '}
                        <strong>
                          Batas Max Iklan ({rp(calcResult.maxCpa)}/pcs):
                        </strong>{' '}
                        Kalau biaya iklanmu untuk mendapatkan 1 pembeli melebihi
                        angka ini, kamu mulai tombok/boncos.
                      </p>
                      <p>
                        •{' '}
                        <strong>
                          ROAS Impas ({calcResult.minRoas}x) vs Aman (
                          {calcResult.safeRoas}x):
                        </strong>{' '}
                        Saat pasang iklan GMV Max, pilih target ROAS di atas{' '}
                        <strong className="text-emerald-300">
                          {calcResult.safeRoas}x
                        </strong>{' '}
                        agar iklanmu sehat &amp; menguntungkan!
                      </p>
                    </div>
                  )}
                </div>

                {/* Tombol Aksi */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 no-print pt-1">
                  <button
                    type="button"
                    onClick={handleSimpanKeDatabaseSKU}
                    className={`font-bold py-3 px-4 rounded-xl text-xs border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      savedSkuFeedback
                        ? 'bg-emerald-600/25 border-emerald-500/60 text-emerald-300 shadow-lg shadow-emerald-500/10'
                        : 'bg-slate-800/90 hover:bg-slate-800 text-white border-slate-700/80'
                    }`}
                  >
                    {savedSkuFeedback ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[2.5] shrink-0" />
                        <span>Tersimpan di SKU ({skuDatabase.length})!</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                        <span>Simpan ke Katalog SKU</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleSalinLaporanWA}
                    className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-extrabold py-3 px-4 rounded-xl text-xs transition-all shadow-lg shadow-orange-500/15 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {copiedWaReport ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[2.5] shrink-0" />
                        <span>Berhasil Disalin!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 stroke-[2.2] shrink-0" />
                        <span>Salin Kartu HPP (WA)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* MENU 2: SIMULASI PROYEKSI BULANAN, TARGET GAJIAN & RISIKO RETUR COD */}
        {activeMenu === 'proyeksi' && (
          <section className="space-y-6">
            <div className="bg-gradient-to-br from-[#12192B] via-[#0E131F] to-[#0E131F] p-4 sm:p-6 rounded-2xl border border-amber-500/35 shadow-xl space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 text-[11px] font-extrabold text-amber-400 uppercase tracking-wide">
                    <Target className="w-3.5 h-3.5" />
                    <span>
                      Reverse Goal Simulator · Kalkulator Target Gajian Seller
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-extrabold text-white mt-0.5">
                    Ingin Gajian / Untung Bersih Berapa Rupiah Bulan Ini?
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Pilih atau ketik target laba bersih bulanan yang kamu
                    inginkan. Sistem otomatis menghitung target order harian
                    &amp; modal stok yang wajib disiapkan:
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleSalinLaporanProyeksiWA}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold py-2.5 px-4 rounded-xl text-xs transition-all shadow-lg shadow-amber-500/15 flex items-center justify-center gap-2 cursor-pointer shrink-0"
                >
                  {copiedProyeksiWa ? (
                    <>
                      <Check className="w-4 h-4 stroke-[2.5]" />
                      <span>Laporan Disalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Salin Target &amp; Proyeksi (WA)</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                <div className="lg:col-span-5 space-y-3">
                  <label className="block text-xs font-bold text-amber-300">
                    Nominal Target Laba Bersih / Bulan (Rp):
                  </label>
                  <input
                    type="number"
                    value={targetGajianBulanan}
                    onFocus={(e) => e.target.select()}
                    onChange={(e) =>
                      setTargetGajianBulanan(
                        Math.max(0, parseFloat(e.target.value) || 0)
                      )
                    }
                    className="w-full bg-[#090D16] text-amber-300 p-3 rounded-xl border border-amber-500/40 focus:border-amber-400 focus:outline-none font-mono font-extrabold text-base tabular-nums"
                  />
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {[
                      { label: 'Rp 5 Juta', val: 5000000 },
                      { label: 'Rp 10 Juta', val: 10000000 },
                      { label: 'Rp 25 Juta', val: 25000000 },
                      { label: 'Rp 50 Juta', val: 50000000 },
                    ].map((presetGaji) => {
                      const active = targetGajianBulanan === presetGaji.val;
                      return (
                        <button
                          key={presetGaji.val}
                          type="button"
                          onClick={() => setTargetGajianBulanan(presetGaji.val)}
                          className={`py-2 px-2.5 rounded-lg border text-xs font-mono font-bold transition-all cursor-pointer ${
                            active
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm'
                              : 'bg-[#090D16] hover:bg-slate-800 border-slate-800 text-slate-300'
                          }`}
                        >
                          {presetGaji.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="lg:col-span-7 space-y-3">
                  {proyeksiResult.labaEfektifPerOrder <= 0 ? (
                    <div className="bg-rose-950/30 border border-rose-500/40 p-4 rounded-xl text-xs text-rose-300">
                      ⚠️ Profit bersih per produk saat ini masih{' '}
                      <strong>{rp(calcResult.profitBersih)}</strong> (atau habis
                      tergerus retur COD). Silakan naikkan harga jual / margin
                      di menu <strong>Kalkulator</strong> terlebih dahulu.
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="bg-[#090D16] p-3.5 rounded-xl border border-amber-500/30">
                          <span className="text-[11px] text-slate-400 block">
                            Wajib Terjual / Hari
                          </span>
                          <div className="text-xl font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                            {proyeksiResult.wajibOrderHari.toLocaleString(
                              'id-ID'
                            )}{' '}
                            Pcs/hr
                          </div>
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            Total:{' '}
                            {proyeksiResult.wajibOrderBulan.toLocaleString(
                              'id-ID'
                            )}{' '}
                            pcs/bulan
                          </span>
                        </div>

                        <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                          <span className="text-[11px] text-slate-400 block">
                            Modal Stok Wajib Siap
                          </span>
                          <div className="text-base sm:text-lg font-mono font-extrabold text-sky-400 mt-1 tabular-nums break-words">
                            {rp(proyeksiResult.modalStokTarget)}
                          </div>
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            HPP+Pack: {rp(calcResult.totalModal)}/pcs
                          </span>
                        </div>

                        <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                          <span className="text-[11px] text-slate-400 block">
                            Estimasi Omset Target
                          </span>
                          <div className="text-base sm:text-lg font-mono font-extrabold text-emerald-400 mt-1 tabular-nums break-words">
                            {rp(proyeksiResult.omsetTargetGajian)}
                          </div>
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            Sudah termasuk cadangan Opex &amp; COD
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#090D16]/80 px-3.5 py-2.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400">
                          Ingin menguji target{' '}
                          <strong className="text-amber-300 font-mono">
                            {proyeksiResult.wajibOrderHari} Pcs/Hari
                          </strong>{' '}
                          di kalkulator operasional bawah?
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setSimQtyHari(proyeksiResult.wajibOrderHari);
                            triggerToast(
                              `Target ${proyeksiResult.wajibOrderHari} Pcs/Hari diterapkan ke Simulasi Operasional!`
                            );
                          }}
                          className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer shrink-0"
                        >
                          Terapkan {proyeksiResult.wajibOrderHari} Pcs/Hari ↓
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-[#0E131F] p-4 sm:p-6 lg:p-8 rounded-2xl border border-slate-800/90 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
              <div className="lg:col-span-4 space-y-4">
                <div className="border-b border-slate-800/80 pb-3">
                  <h3 className="text-sm sm:text-base font-extrabold text-white">
                    Parameter Operasional Bulanan
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Menggunakan profit bersih per pcs (
                    {rp(calcResult.profitBersih)}) dari kalkulator aktif
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Target Terjual per Hari (Pcs/Hari)
                  </label>
                  <input
                    type="number"
                    value={simQtyHari}
                    onChange={(e) =>
                      setSimQtyHari(parseFloat(e.target.value) || 0)
                    }
                    className="w-full bg-[#090D16] text-white p-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono font-bold text-sm tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Estimasi Paket Gagal COD / Retur (%)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={simReturCodPct}
                    onChange={(e) =>
                      setSimReturCodPct(parseFloat(e.target.value) || 0)
                    }
                    className="w-full bg-[#090D16] text-rose-400 p-3 rounded-xl border border-slate-800 focus:border-rose-500 focus:outline-none font-mono font-bold text-sm tabular-nums"
                  />
                  <span className="text-[11px] text-slate-500 block mt-1">
                    Menghitung kerugian biaya packing &amp; selisih ongkir retur
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Biaya Operasional Tetap Bulanan (Gaji/Listrik/WiFi)
                  </label>
                  <input
                    type="number"
                    value={simOpexBulanan}
                    onChange={(e) =>
                      setSimOpexBulanan(parseFloat(e.target.value) || 0)
                    }
                    className="w-full bg-[#090D16] text-white p-3 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none font-mono font-bold text-sm tabular-nums"
                  />
                </div>
              </div>

              <div className="lg:col-span-8 flex flex-col justify-between space-y-5 sm:space-y-6 lg:border-l lg:border-slate-800/80 lg:pl-8">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
                  <div className="bg-[#090D16] p-4 rounded-xl border border-slate-800/80">
                    <span className="text-xs text-slate-400 block">
                      Total Order Sukses (30 Hari)
                    </span>
                    <div className="text-lg sm:text-xl font-mono font-extrabold text-white mt-1 tabular-nums">
                      {proyeksiResult.qtySukses.toLocaleString('id-ID')} Pcs
                    </div>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Dari total{' '}
                      {proyeksiResult.totalQtyBulan.toLocaleString('id-ID')}{' '}
                      resi dikirim
                    </span>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-slate-800/80">
                    <span className="text-xs text-slate-400 block">
                      Estimasi Omset Kotor
                    </span>
                    <div className="text-lg sm:text-xl font-mono font-extrabold text-amber-400 mt-1 tabular-nums break-words">
                      {rp(proyeksiResult.omsetKotor)}
                    </div>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Gross Merchandise Value (GMV)
                    </span>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-slate-800/80">
                    <span className="text-xs text-slate-400 block">
                      Beban Retur COD ({proyeksiResult.qtyRetur} Pcs)
                    </span>
                    <div className="text-lg sm:text-xl font-mono font-extrabold text-rose-400 mt-1 tabular-nums break-words">
                      - {rp(proyeksiResult.rugiReturCod)}
                    </div>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Estimasi retur:{' '}
                      <strong className="font-mono text-rose-300">
                        {proyeksiResult.qtyRetur.toLocaleString('id-ID')} paket
                      </strong>
                    </span>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-emerald-950/50 via-[#090D16] to-[#090D16] p-5 sm:p-6 rounded-2xl border border-emerald-500/30 flex flex-wrap justify-between items-center gap-4">
                  <div>
                    <span className="text-[11px] sm:text-xs font-bold text-emerald-400 tracking-wide uppercase block">
                      Proyeksi Laba Bersih Toko / Bulan (Net Profit)
                    </span>
                    <div className="text-2xl sm:text-3xl lg:text-4xl font-mono font-extrabold text-white mt-1.5 tabular-nums break-words">
                      {rp(proyeksiResult.netProfitBulan)}
                    </div>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      Titik Impas Operasional (Break-Even Point): Wajib terjual
                      minimal{' '}
                      <strong className="font-mono text-amber-300 tabular-nums">
                        {proyeksiResult.bepPcs.toLocaleString('id-ID')}{' '}
                        pcs/bulan
                      </strong>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* MENU 2B: v5.0 ULTIMATE SUPER SUITE (13 MODUL EKSEKUTIF) */}
        {activeMenu === 'v5suite' && (
          <section className="space-y-6">
            {!isV5Unlocked ? (
              /* LAYAR UPGRADE LISENSI DARI v4.0 KE v5.0 ULTIMATE (13 MODUL SUPER SUITE) */
              <div className="bg-gradient-to-br from-[#13192B] via-[#0E131F] to-[#0E131F] border border-amber-500/35 rounded-2xl p-5 sm:p-8 shadow-2xl space-y-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
                  <div className="space-y-1.5">
                    <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-3 py-1 rounded-lg">
                      <Crown className="w-3.5 h-3.5 shrink-0" />
                      <span>13 MODUL SUPER SUITE · SELLERMETRICS v5.0 ULTIMATE</span>
                    </div>
                    <h2 className="text-lg sm:text-2xl font-extrabold text-white">
                      Buka 13 Senjata Rahasia Seller Besar &amp; Maksimalkan Profit Toko
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
                      Toko Anda (
                      <strong className="text-white">{licensedStore}</strong>)
                      saat ini menggunakan{' '}
                      <strong>Lisensi Standar v4.0</strong>. Cukup tambah biaya
                      upgrade sekali bayar ({OWNER_CONFIG.hargaUpgradeV5}) untuk
                      membuka seluruh 13 Modul Eksekutif di bawah ini selamanya:
                    </p>
                  </div>

                  <a
                    href={waUpgradeV5Url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-extrabold px-5 py-3.5 rounded-xl text-xs sm:text-sm shadow-lg shadow-amber-500/20 inline-flex items-center justify-center gap-2 shrink-0 transition-all"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" />
                    <span>Upgrade ke v5.0 ({OWNER_CONFIG.hargaUpgradeV5})</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  </a>
                </div>

                {/* Preview 9 Modul v5.0 */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="bg-[#090D16] p-4 rounded-xl border border-amber-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-amber-300 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>1. Kalkulator Paket Bundling (1 Resi)</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung otomatis harga paket &ldquo;Beli 2 Hemat&rdquo;,
                      &ldquo;Paket 3 Pcs&rdquo;, &ldquo;Grosir 5 Pcs&rdquo;.
                      Biaya proses order hanya dipotong 1x per resi sehingga
                      profit per pesanan melonjak drastis!
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-sky-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-sky-300 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-sky-400 shrink-0" />
                      <span>2. Matriks Komparasi 4 Marketplace</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Bandingkan potongan admin, harga jual ideal, dan sisa
                      margin antara Shopee Star, Shopee Mall, TikTok Shop, dan
                      Tokopedia secara berdampingan dalam 1 layar.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-indigo-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-indigo-300 flex items-center gap-2">
                      <Megaphone className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span>3. Simulator Iklan GMV Max &amp; Budget Harian</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Simulasikan budget iklan harian (Rp 50rb–500rb/hari) dan
                      target ROAS GMV Max (5x–15x) untuk mengetahui estimasi
                      order harian, CPA, dan laba bersih iklan sebelum bakar
                      uang!
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-emerald-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-emerald-300 flex items-center gap-2">
                      <Award className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>4. Kalkulator Komisi Affiliate &amp; Sampel Gratis</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Bandingkan komisi Affiliate Standar (5%), Top Creator
                      (12%), dan Host Live/MCN (15%) serta hitung berapa pcs
                      wajib terjual agar modal kirim sampel gratis balik modal!
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-rose-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-rose-300 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>5. Simulator Flash Sale &amp; Subsidi Silang</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung kuota stok Flash Sale (9.9 / 11.11 / Payday) dan
                      subsidi silang dari trafik penjualan normal agar toko
                      tidak boncos saat banting harga.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-orange-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-orange-300 flex items-center gap-2">
                      <Tag className="w-4 h-4 text-orange-400 shrink-0" />
                      <span>6. Generator Harga Coret Seller Centre (15%–60%)</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Tabel otomatis Harga Sebelum Diskon + angka psikologis
                      (.900) untuk dipajang di menu Promosi Diskon Toko tanpa
                      menggerus target profit bersih Anda.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-sky-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-sky-300 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-sky-400 shrink-0" />
                      <span>7. Kalkulator Overhead Toko &amp; Gaji Owner</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung minimal resi harian yang wajib keluar untuk menutup
                      gaji admin packing, listrik, WiFi, sewa gudang, sekaligus
                      mengamankan target gaji bersih Owner.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-amber-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-amber-300 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>8. Simulator Modal Kerja &amp; Dana Tertahan</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung berapa modal kas yang tertahan di pengiriman
                      marketplace (settlement) dan berapa dana cadangan wajib
                      agar toko tidak kehabisan stok saat order ramai.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-emerald-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-emerald-300 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>9. Detektor Kebocoran Dana Cair &amp; Retur COD</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Audit selisih dana cair aktual vs estimasi resmi + kunci
                      cadangan kerugian paket gagal kirim COD (2%–10%) di harga
                      jual otomatis.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-indigo-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-indigo-300 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span>10. Kalkulator Multi-Varian Ukuran (S–XXL / ml)</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung otomatis Harga Jual &amp; Harga Coret tiap ukuran
                      yang HPP-nya berbeda tanpa melanggar batas rasio harga
                      varian Shopee/TikTok.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-rose-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-rose-300 flex items-center gap-2">
                      <Target className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>11. Kalkulator Gaji Host Live &amp; BEP Sesi</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Hitung minimal order wajib per sesi Live Streaming untuk
                      menutup fee jam Host Live + bonus komisi % GMV agar tidak
                      boncos.
                    </p>
                  </div>

                  <div className="bg-[#090D16] p-4 rounded-xl border border-emerald-500/25 space-y-1.5">
                    <div className="text-xs font-bold text-emerald-300 flex items-center gap-2">
                      <Tag className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>12 &amp; 13. Voucher Guard + Skrip Brief Kreator</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Simulator batas aman Voucher Minimum Belanja bertingkat (1,
                      2, 3 pcs) + Generator Skrip Undangan Affiliate siap kirim
                      ke WA/TikTok.
                    </p>
                  </div>
                </div>

                {/* Form Aktivasi Instan Kode Upgrade SM5-... */}
                <form
                  onSubmit={handleUpgradeKeV5InApp}
                  className="bg-[#090D16] p-4 sm:p-5 rounded-xl border border-amber-500/30 space-y-3"
                >
                  <div className="text-xs font-bold text-white">
                    Sudah Memiliki Kode Upgrade v5.0 (
                    <code className="text-amber-300">SM5-...</code>)? Masukkan
                    di Bawah Ini:
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <input
                      type="text"
                      value={upgradeKodeInput}
                      onChange={(e) => setUpgradeKodeInput(e.target.value)}
                      placeholder={`Contoh: ${generateSerialKey(licensedStore, 'v5').slice(0, 6)}...`}
                      className="flex-grow bg-[#0E131F] text-amber-300 px-4 py-2.5 rounded-xl border border-slate-700 focus:border-amber-400 focus:outline-none text-xs sm:text-sm font-mono font-bold uppercase tracking-wider"
                    />
                    <button
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs sm:text-sm transition-colors cursor-pointer shrink-0"
                    >
                      Aktifkan v5.0 Sekarang
                    </button>
                  </div>
                  {upgradeError && (
                    <p className="text-xs text-rose-400 font-medium">
                      {upgradeError}
                    </p>
                  )}
                </form>
              </div>
            ) : (
              /* TAMPILAN PENUH 13 MODUL FITUR v5.0 ULTIMATE SUPER SUITE */
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-amber-500/10 via-[#0E131F] to-[#0E131F] p-4 sm:p-5 rounded-2xl border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/35 flex items-center justify-center text-amber-300 shrink-0">
                      <Crown className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-extrabold text-white">
                          v5.0 Ultimate Executive Super Suite (13 Modul Aktif)
                        </span>
                        <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-md border border-amber-500/30">
                          UNLOCKED
                        </span>
                      </div>
                      <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                        Produk Aktif:{' '}
                        <strong className="text-slate-200">
                          {skuNama.trim() || 'Produk Marketplace'}
                        </strong>{' '}
                        · Harga Satuan:{' '}
                        <strong className="text-amber-300 font-mono">
                          {rp(calcResult.hargaJualFinal)}
                        </strong>
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleSalinLaporanV5WA}
                    className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold py-2.5 px-4 rounded-xl text-xs transition-all shadow-lg shadow-amber-500/15 flex items-center justify-center gap-2 cursor-pointer shrink-0"
                  >
                    {copiedV5Report ? (
                      <>
                        <Check className="w-4 h-4 stroke-[2.5]" />
                        <span>Strategi v5.0 Disalin!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Salin Semua Strategi v5.0 (WA)</span>
                      </>
                    )}
                  </button>
                </div>

                {/* MODUL 01: KALKULATOR PAKET BUNDLING & GROSIR 1 RESI */}
                <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-slate-800/90 space-y-5">
                  <div className="flex flex-col gap-4 border-b border-slate-800/80 pb-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wide">
                        <Layers className="w-3.5 h-3.5" />
                        <span>Modul 01 · Strategi Peningkatan AOV (1 Resi)</span>
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
                        Kalkulator Paket Bundling &ldquo;Beli Banyak Lebih
                        Hemat&rdquo;
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Saat pembeli beli 2–5 pcs sekaligus dalam 1 pesanan,
                        Biaya Proses ({rp(Number(inBiayaProses) || 0)}) &amp;
                        Voucher Toko hanya terpotong 1x per resi!
                      </p>
                    </div>

                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                      <div className="bg-[#090D16] p-2.5 sm:p-3 rounded-xl border border-amber-500/30 space-y-2">
                        <label className="block text-[11px] font-bold text-slate-300">
                          Diskon Beli 2 (%)
                        </label>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon2Pct((p) =>
                                Math.max(0, Number(p) - 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            value={bundleDiskon2Pct}
                            onFocus={(e) => e.target.select()}
                            onChange={(e) =>
                              setBundleDiskon2Pct(
                                Math.max(
                                  0,
                                  Math.min(90, parseFloat(e.target.value) || 0)
                                )
                              )
                            }
                            className="w-full bg-[#0E131F] text-amber-300 px-2 py-1.5 rounded-lg border border-slate-700 focus:border-amber-400 focus:outline-none font-mono font-extrabold text-sm text-center"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon2Pct((p) =>
                                Math.min(90, Number(p) + 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            +
                          </button>
                        </div>
                        <div className="pt-1.5 border-t border-slate-800/80 text-[10px] space-y-0.5">
                          <div className="flex justify-between text-slate-400">
                            <span>Harga 2 Pcs:</span>
                            <strong className="font-mono text-orange-400 tabular-nums">
                              {rp(v5Result.tier2.hargaPaket)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Laba Resi:</span>
                            <strong className="font-mono text-emerald-400 tabular-nums">
                              {rp(v5Result.tier2.labaBersihResi)}
                            </strong>
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#090D16] p-2.5 sm:p-3 rounded-xl border border-slate-800 space-y-2">
                        <label className="block text-[11px] font-bold text-slate-300">
                          Diskon Beli 3 (%)
                        </label>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon3Pct((p) =>
                                Math.max(0, Number(p) - 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            value={bundleDiskon3Pct}
                            onFocus={(e) => e.target.select()}
                            onChange={(e) =>
                              setBundleDiskon3Pct(
                                Math.max(
                                  0,
                                  Math.min(90, parseFloat(e.target.value) || 0)
                                )
                              )
                            }
                            className="w-full bg-[#0E131F] text-amber-300 px-2 py-1.5 rounded-lg border border-slate-700 focus:border-amber-400 focus:outline-none font-mono font-extrabold text-sm text-center"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon3Pct((p) =>
                                Math.min(90, Number(p) + 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            +
                          </button>
                        </div>
                        <div className="pt-1.5 border-t border-slate-800/80 text-[10px] space-y-0.5">
                          <div className="flex justify-between text-slate-400">
                            <span>Harga 3 Pcs:</span>
                            <strong className="font-mono text-orange-400 tabular-nums">
                              {rp(v5Result.tier3.hargaPaket)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Laba Resi:</span>
                            <strong className="font-mono text-emerald-400 tabular-nums">
                              {rp(v5Result.tier3.labaBersihResi)}
                            </strong>
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#090D16] p-2.5 sm:p-3 rounded-xl border border-slate-800 space-y-2">
                        <label className="block text-[11px] font-bold text-slate-300">
                          Diskon Beli 5 (%)
                        </label>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon5Pct((p) =>
                                Math.max(0, Number(p) - 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            value={bundleDiskon5Pct}
                            onFocus={(e) => e.target.select()}
                            onChange={(e) =>
                              setBundleDiskon5Pct(
                                Math.max(
                                  0,
                                  Math.min(90, parseFloat(e.target.value) || 0)
                                )
                              )
                            }
                            className="w-full bg-[#0E131F] text-amber-300 px-2 py-1.5 rounded-lg border border-slate-700 focus:border-amber-400 focus:outline-none font-mono font-extrabold text-sm text-center"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setBundleDiskon5Pct((p) =>
                                Math.min(90, Number(p) + 1)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            +
                          </button>
                        </div>
                        <div className="pt-1.5 border-t border-slate-800/80 text-[10px] space-y-0.5">
                          <div className="flex justify-between text-slate-400">
                            <span>Harga 5 Pcs:</span>
                            <strong className="font-mono text-orange-400 tabular-nums">
                              {rp(v5Result.tier5.hargaPaket)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Laba Resi:</span>
                            <strong className="font-mono text-emerald-400 tabular-nums">
                              {rp(v5Result.tier5.labaBersihResi)}
                            </strong>
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#090D16] p-2.5 sm:p-3 rounded-xl border border-slate-800 space-y-2">
                        <label className="block text-[11px] font-bold text-slate-300">
                          Hemat Pack (%)
                        </label>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              setBundleHematPackingPct((p) =>
                                Math.max(0, Number(p) - 10)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            value={bundleHematPackingPct}
                            onFocus={(e) => e.target.select()}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              setBundleHematPackingPct(
                                Number.isNaN(val)
                                  ? 0
                                  : Math.max(0, Math.min(100, val))
                              );
                            }}
                            className="w-full bg-[#0E131F] text-sky-300 px-2 py-1.5 rounded-lg border border-slate-700 focus:border-sky-400 focus:outline-none font-mono font-extrabold text-sm text-center"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setBundleHematPackingPct((p) =>
                                Math.min(100, Number(p) + 10)
                              )
                            }
                            className="w-8 h-8 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm flex items-center justify-center shrink-0 cursor-pointer active:scale-95"
                          >
                            +
                          </button>
                        </div>
                        <div className="pt-1.5 border-t border-slate-800/80 text-[10px] space-y-0.5">
                          <div className="flex justify-between text-slate-400">
                            <span>Pack Pcs ke-2+:</span>
                            <strong className="font-mono text-sky-300 tabular-nums">
                              {rp(v5Result.packPcsTambahan)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Hemat (5 Pcs):</span>
                            <strong className="font-mono text-emerald-400 tabular-nums">
                              +{rp(v5Result.tier5.hematPackingNominal)}
                            </strong>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                    {v5Result.bundlingTiers.map((b) => (
                      <div
                        key={b.qty}
                        className={`p-4 rounded-xl border space-y-3 ${
                          b.qty === 2
                            ? 'bg-amber-500/[0.06] border-amber-500/40'
                            : b.qty === 1
                            ? 'bg-[#090D16]/60 border-slate-800/60'
                            : 'bg-[#090D16] border-slate-800/90'
                        }`}
                      >
                        <div className="flex justify-between items-center border-b border-slate-800/80 pb-2.5">
                          <span className="text-xs font-extrabold text-white">
                            {b.qty === 1
                              ? 'Pembanding: Satuan (1 Pcs)'
                              : `Paket Hemat ${b.qty} Pcs`}
                          </span>
                          {b.diskonPct > 0 ? (
                            <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">
                              Diskon {b.diskonPct}%
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono text-slate-500">
                              Normal
                            </span>
                          )}
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block">
                            Harga Paket ke Pembeli:
                          </span>
                          <div className="text-lg font-mono font-extrabold text-orange-400 tabular-nums mt-0.5">
                            {rp(b.hargaPaket)}
                          </div>
                          {b.hematPembeli > 0 ? (
                            <span className="text-[11px] text-emerald-400 block">
                              Pembeli hemat {rp(b.hematPembeli)}
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-500 block">
                              Harga jual standar 1 pcs
                            </span>
                          )}
                        </div>

                        <div className="pt-2 border-t border-slate-800/80 space-y-1 text-[11px]">
                          <div className="flex justify-between text-slate-400">
                            <span>Biaya Packing ({b.qty} pcs):</span>
                            <span className="font-mono text-sky-300">
                              {rp(b.modalPackingTotal)}
                              {b.hematPackingNominal > 0
                                ? ` (Hemat ${rp(b.hematPackingNominal)})`
                                : ''}
                            </span>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Potongan 1 Resi:</span>
                            <span className="font-mono text-rose-400">
                              -{rp(b.totalPotonganResi)}
                            </span>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Profit / Pcs:</span>
                            <span className="font-mono text-slate-200">
                              {rp(b.labaPerPcs)}
                            </span>
                          </div>
                          <div className="flex justify-between font-bold text-emerald-400 text-xs pt-1">
                            <span>Total Laba Resi:</span>
                            <span className="font-mono tabular-nums">
                              {rp(b.labaBersihResi)} ({b.marginPct}%)
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* MODUL 02: MATRIKS KOMPARASI 4 MARKETPLACE SEKALIGUS */}
                <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-slate-800/90 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3.5">
                    <div>
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-sky-400 uppercase tracking-wide">
                        <BarChart3 className="w-3.5 h-3.5" />
                        <span>Modul 02 · Cross-Platform Margin Matrix</span>
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
                        Komparasi Profitabilitas 4 Marketplace Sekaligus
                      </h3>
                    </div>
                    {v5Result.bestMp && (
                      <div className="text-xs bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 px-3 py-1.5 rounded-xl font-semibold">
                        Platform Paling Untung:{' '}
                        <strong className="text-white">
                          {v5Result.bestMp.name}
                        </strong>
                      </div>
                    )}
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                          <th className="py-3 px-3">Platform Marketplace</th>
                          <th className="py-3 px-3 text-right">
                            Total Fee (%)
                          </th>
                          <th className="py-3 px-3 text-right">
                            Rekomendasi Harga Ideal
                          </th>
                          <th className="py-3 px-3 text-right">
                            Potongan di Harga {rp(calcResult.hargaJualFinal)}
                          </th>
                          <th className="py-3 px-3 text-right">
                            Sisa Profit Bersih
                          </th>
                          <th className="py-3 px-3 text-right">Min ROAS</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {v5Result.mpComparisons.map((mp) => {
                          const isBest =
                            v5Result.bestMp && v5Result.bestMp.id === mp.id;
                          return (
                            <tr
                              key={mp.id}
                              className={
                                isBest
                                  ? 'bg-emerald-950/20'
                                  : 'hover:bg-slate-800/30'
                              }
                            >
                              <td className="py-3.5 px-3 font-bold text-white whitespace-nowrap">
                                {mp.name}{' '}
                                {isBest && (
                                  <span className="ml-1.5 text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-semibold">
                                    TERBAIK
                                  </span>
                                )}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-slate-300 tabular-nums">
                                {mp.totalPct.toFixed(1)}%
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono font-bold text-orange-400 tabular-nums">
                                {rp(mp.hargaIdealMp)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-rose-400 tabular-nums">
                                -{rp(mp.potonganJikaHargaSama)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono font-extrabold text-emerald-400 tabular-nums">
                                {rp(mp.profitJikaHargaSama)} (
                                {mp.marginJikaHargaSama}%)
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-indigo-300 font-bold tabular-nums">
                                {mp.minRoasMp}x
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* MODUL 03 (BARU DI v5.0): SIMULATOR BUDGET IKLAN HARIAN & TARGET ROAS GMV MAX */}
                <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-indigo-500/30 grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-5 space-y-4">
                    <div className="border-b border-slate-800/80 pb-3">
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-indigo-400 uppercase tracking-wide">
                        <Megaphone className="w-3.5 h-3.5" />
                        <span>Modul 03 · GMV Max Daily Ads Simulator</span>
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
                        Simulator Budget Iklan Harian &amp; Target ROAS GMV Max
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Uji berapa estimasi order harian dan profit bersih toko
                        sebelum Anda menyalakan iklan GMV Max Shopee / TikTok
                        Ads:
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Budget Iklan Harian (Rp / Hari):
                      </label>
                      <input
                        type="number"
                        value={gmvDailyBudget}
                        onChange={(e) =>
                          setGmvDailyBudget(
                            Math.max(0, parseFloat(e.target.value) || 0)
                          )
                        }
                        className="w-full bg-[#090D16] text-indigo-300 p-3 rounded-xl border border-slate-800 font-mono font-extrabold text-sm tabular-nums"
                      />
                      <div className="grid grid-cols-4 gap-1.5 mt-2">
                        {[
                          { label: 'Rp 50rb', val: 50000 },
                          { label: 'Rp 150rb', val: 150000 },
                          { label: 'Rp 300rb', val: 300000 },
                          { label: 'Rp 500rb', val: 500000 },
                        ].map((b) => (
                          <button
                            key={b.val}
                            type="button"
                            onClick={() => setGmvDailyBudget(b.val)}
                            className={`py-1.5 px-2 rounded-lg border text-[10px] font-mono font-bold transition-all cursor-pointer ${
                              gmvDailyBudget === b.val
                                ? 'bg-indigo-500/25 border-indigo-400 text-indigo-200'
                                : 'bg-[#090D16] hover:bg-slate-800 border-slate-800 text-slate-400'
                            }`}
                          >
                            {b.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <label className="block text-xs font-medium text-slate-300">
                          Pilih Target ROAS GMV Max:
                        </label>
                        <span className="text-[10px] font-mono text-amber-300">
                          Min Impas: {calcResult.minRoas}x · Aman:{' '}
                          {calcResult.safeRoas}x
                        </span>
                      </div>
                      <div className="grid grid-cols-5 gap-1.5">
                        {GMV_MAX_ROAS_TARGETS.map((t) => (
                          <button
                            key={t.roas}
                            type="button"
                            onClick={() => setGmvTargetRoas(t.roas)}
                            className={`py-2 px-2 rounded-lg border text-xs font-mono font-extrabold transition-all cursor-pointer ${
                              gmvTargetRoas === t.roas
                                ? 'bg-indigo-500/30 border-indigo-400 text-white shadow-sm'
                                : 'bg-[#090D16] hover:bg-slate-800 border-slate-800 text-slate-400'
                            }`}
                          >
                            {t.roas}x
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Est. Omset Iklan / Hari
                        </span>
                        <div className="text-base sm:text-lg font-mono font-extrabold text-amber-300 mt-1 tabular-nums">
                          {rp(v5Result.gmvOmsetHarian)}
                        </div>
                        <span className="text-[10px] text-slate-500 block mt-0.5">
                          ~{v5Result.gmvEstOrderHari} pcs terjual/hari
                        </span>
                      </div>

                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Biaya Iklan / Pcs (CPA)
                        </span>
                        <div className="text-base sm:text-lg font-mono font-extrabold text-indigo-300 mt-1 tabular-nums">
                          {rp(v5Result.gmvCpaPerOrder)}
                        </div>
                        <span className="text-[10px] text-slate-500 block mt-0.5">
                          Sisa laba: {rp(v5Result.gmvLabaPerOrder)}/pcs
                        </span>
                      </div>

                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Laba Bersih Iklan / Hari
                        </span>
                        <div
                          className={`text-base sm:text-lg font-mono font-extrabold mt-1 tabular-nums ${
                            v5Result.gmvNetProfitHarian >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {rp(v5Result.gmvNetProfitHarian)}
                        </div>
                        <span className="text-[10px] text-slate-500 block mt-0.5">
                          Setelah potong budget iklan
                        </span>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-indigo-950/50 via-[#090D16] to-[#090D16] p-4 sm:p-5 rounded-2xl border border-indigo-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wide block">
                          Proyeksi Laba Bersih dari Iklan GMV Max (30 Hari)
                        </span>
                        <div
                          className={`text-2xl sm:text-3xl font-mono font-extrabold mt-1 tabular-nums ${
                            v5Result.gmvNetProfitBulanan >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {rp(v5Result.gmvNetProfitBulanan)}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          {v5Result.gmvLabaPerOrder <= 0
                            ? `⚠️ Target ROAS ${v5Result.targetRoasVal}x masih di bawah titik impas (${calcResult.minRoas}x). Naikkan target ROAS!`
                            : `Target ROAS ${v5Result.targetRoasVal}x menghasilkan profit bersih positif setiap hari.`}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setInBiayaIklanPcs(v5Result.gmvCpaPerOrder);
                          triggerToast(
                            `CPA GMV Max (${rp(v5Result.gmvCpaPerOrder)}/pcs) diterapkan ke Kalkulator!`
                          );
                        }}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer shrink-0"
                      >
                        Terapkan CPA ke Kalkulator
                      </button>
                    </div>
                  </div>
                </div>

                {/* MODUL 04 (BARU DI v5.0): KALKULATOR KOMISI AFFILIATE, CREATOR LIVE & BEP SAMPEL GRATIS */}
                <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-emerald-500/30 space-y-5">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 uppercase tracking-wide">
                        <Award className="w-3.5 h-3.5" />
                        <span>
                          Modul 04 · Affiliate &amp; Creator Sample ROI Calculator
                        </span>
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
                        Kalkulator Komisi Affiliate, Live Creator &amp; Titik
                        Impas (BEP) Sampel Gratis
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Jangan asal kirim sampel gratis atau kasih komisi tinggi
                        ke kreator! Hitung berapa pcs yang wajib terjual oleh
                        kreator agar modal sampel gratis Anda balik modal:
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-2.5 shrink-0">
                      <div className="bg-[#090D16] p-2.5 rounded-xl border border-slate-800">
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Jml Sampel Gratis
                        </label>
                        <input
                          type="number"
                          value={affSampleQty}
                          onChange={(e) =>
                            setAffSampleQty(
                              Math.max(0, parseFloat(e.target.value) || 0)
                            )
                          }
                          className="w-full bg-[#0E131F] text-amber-300 px-2 py-1.5 rounded-lg border border-slate-700 font-mono font-bold text-xs text-center"
                        />
                      </div>
                      <div className="bg-[#090D16] p-2.5 rounded-xl border border-slate-800">
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Ongkir Sampel (Rp)
                        </label>
                        <input
                          type="number"
                          value={affSampleOngkir}
                          onChange={(e) =>
                            setAffSampleOngkir(
                              Math.max(0, parseFloat(e.target.value) || 0)
                            )
                          }
                          className="w-full bg-[#0E131F] text-white px-2 py-1.5 rounded-lg border border-slate-700 font-mono font-bold text-xs text-center"
                        />
                      </div>
                      <div className="bg-[#090D16] p-2.5 rounded-xl border border-slate-800">
                        <label className="block text-[10px] text-slate-400 mb-1">
                          Target Laku (Pcs)
                        </label>
                        <input
                          type="number"
                          value={affTargetSalesQty}
                          onChange={(e) =>
                            setAffTargetSalesQty(
                              Math.max(1, parseFloat(e.target.value) || 1)
                            )
                          }
                          className="w-full bg-[#0E131F] text-emerald-300 px-2 py-1.5 rounded-lg border border-slate-700 font-mono font-bold text-xs text-center"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                    {v5Result.affiliateTiers.map((tier) => (
                      <div
                        key={tier.id}
                        className="bg-[#090D16] p-4 rounded-xl border border-slate-800/90 space-y-3"
                      >
                        <div className="flex justify-between items-center border-b border-slate-800/80 pb-2.5">
                          <span className="text-xs font-extrabold text-white">
                            {tier.name}
                          </span>
                          <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded">
                            Komisi {tier.pct}%
                          </span>
                        </div>

                        <div className="space-y-1 text-[11px]">
                          <div className="flex justify-between text-slate-400">
                            <span>Komisi Kreator/Pcs:</span>
                            <strong className="font-mono text-rose-400">
                              -{rp(tier.komisiRp)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Sisa Laba Toko/Pcs:</span>
                            <strong
                              className={`font-mono ${
                                tier.labaPerPcsKreator > 0
                                  ? 'text-emerald-400'
                                  : 'text-rose-400'
                              }`}
                            >
                              {rp(tier.labaPerPcsKreator)}
                            </strong>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>BEP {affSampleQty} Sampel Gratis:</span>
                            <strong className="font-mono text-amber-300">
                              {tier.bepSampelPcs > 0
                                ? `Wajib laku ${tier.bepSampelPcs} pcs`
                                : 'Rugi'}
                            </strong>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-800/80">
                          <span className="text-[10px] text-slate-400 block">
                            Net Profit ({v5Result.targetSalesKreator} Pcs Laku -
                            Modal Sampel):
                          </span>
                          <div
                            className={`text-sm font-mono font-extrabold mt-0.5 tabular-nums ${
                              tier.netProfitKolaborasi >= 0
                                ? 'text-emerald-400'
                                : 'text-rose-400'
                            }`}
                          >
                            {rp(tier.netProfitKolaborasi)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* MODUL 05: SIMULATOR FLASH SALE & EVENT KEMBAR */}
                <div className="bg-[#0E131F] p-4 sm:p-6 rounded-2xl border border-slate-800/90 grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-5 space-y-4">
                    <div className="border-b border-slate-800/80 pb-3">
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-rose-400 uppercase tracking-wide">
                        <Zap className="w-3.5 h-3.5" />
                        <span>Modul 05 · Campaign &amp; Flash Sale Guard</span>
                      </div>
                      <h3 className="text-sm sm:text-base font-extrabold text-white mt-0.5">
                        Simulator Banting Harga Flash Sale &amp; Subsidi Silang
                      </h3>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-medium text-slate-300">
                          Harga Flash Sale yang Diajukan (Rp)
                        </label>
                        <span className="text-[10px] font-mono text-slate-400">
                          Normal: {rp(calcResult.hargaJualFinal)}
                        </span>
                      </div>
                      <input
                        type="number"
                        value={flashSaleHarga}
                        onChange={(e) =>
                          setFlashSaleHarga(parseFloat(e.target.value) || 0)
                        }
                        className="w-full bg-[#090D16] text-amber-300 p-3 rounded-xl border border-slate-800 font-mono font-bold text-sm"
                      />
                      {(() => {
                        const harga10 = Math.round(
                          calcResult.hargaJualFinal * 0.9
                        );
                        const harga15 = Math.round(
                          calcResult.hargaJualFinal * 0.85
                        );
                        const harga20 = Math.round(
                          calcResult.hargaJualFinal * 0.8
                        );
                        const pembagi = 1 - calcResult.totalPctFee / 100;
                        const hargaImpas =
                          pembagi > 0.05
                            ? Math.ceil(
                                (calcResult.totalModal +
                                  (Number(inBiayaProses) || 0)) /
                                  pembagi
                              )
                            : calcResult.totalModal;

                        const is10 = flashSaleHarga === harga10;
                        const is15 = flashSaleHarga === harga15;
                        const is20 = flashSaleHarga === harga20;
                        const isImpas = flashSaleHarga === hargaImpas;

                        const activeBtnClass =
                          'bg-amber-500/20 text-amber-300 border-amber-500/60 shadow-sm ring-1 ring-amber-500/30';
                        const inactiveBtnClass =
                          'bg-[#090D16] hover:bg-slate-800 text-slate-300 border-slate-800';

                        return (
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mt-2">
                            <button
                              type="button"
                              onClick={() => setFlashSaleHarga(harga10)}
                              className={`border py-1.5 px-2 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                                is10 ? activeBtnClass : inactiveBtnClass
                              }`}
                            >
                              -10% Normal
                            </button>
                            <button
                              type="button"
                              onClick={() => setFlashSaleHarga(harga15)}
                              className={`border py-1.5 px-2 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                                is15 ? activeBtnClass : inactiveBtnClass
                              }`}
                            >
                              -15% Normal
                            </button>
                            <button
                              type="button"
                              onClick={() => setFlashSaleHarga(harga20)}
                              className={`border py-1.5 px-2 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                                is20 ? activeBtnClass : inactiveBtnClass
                              }`}
                            >
                              -20% Normal
                            </button>
                            <button
                              type="button"
                              onClick={() => setFlashSaleHarga(hargaImpas)}
                              className={`border py-1.5 px-2 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                                isImpas ? activeBtnClass : inactiveBtnClass
                              }`}
                              title="Set ke Harga Impas (Untung Rp 0 / Tidak Rugi)"
                            >
                              Harga Impas
                            </button>
                          </div>
                        );
                      })()}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Kuota Stok Flash Sale (Pcs)
                        </label>
                        <input
                          type="number"
                          value={flashSaleKuota}
                          onChange={(e) =>
                            setFlashSaleKuota(parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-[#090D16] text-white p-3 rounded-xl border border-slate-800 font-mono font-bold text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Target Terjual Normal (Pcs)
                        </label>
                        <input
                          type="number"
                          value={flashSaleNormalQty}
                          onChange={(e) =>
                            setFlashSaleNormalQty(
                              parseFloat(e.target.value) || 0
                            )
                          }
                          className="w-full bg-[#090D16] text-emerald-300 p-3 rounded-xl border border-slate-800 font-mono font-bold text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="lg:col-span-7 flex flex-col justify-between space-y-4 lg:border-l lg:border-slate-800/80 lg:pl-6">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Margin Saat Flash Sale / Pcs
                        </span>
                        <div
                          className={`text-base sm:text-lg font-mono font-extrabold mt-1 tabular-nums ${
                            v5Result.fsProfitPerPcs >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {rp(v5Result.fsProfitPerPcs)}
                        </div>
                      </div>
                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Total Hasil Kuota Flash Sale
                        </span>
                        <div
                          className={`text-base sm:text-lg font-mono font-extrabold mt-1 tabular-nums ${
                            v5Result.fsTotalProfitOrLoss >= 0
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {rp(v5Result.fsTotalProfitOrLoss)}
                        </div>
                      </div>
                      <div className="bg-[#090D16] p-3.5 rounded-xl border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">
                          Laba dari Penjualan Normal
                        </span>
                        <div className="text-base sm:text-lg font-mono font-extrabold text-sky-400 mt-1 tabular-nums">
                          {rp(v5Result.fsLabaPenjualanNormal)}
                        </div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-indigo-950/40 via-[#090D16] to-[#090D16] p-5 rounded-2xl border border-indigo-500/30">
                      <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wide block">
                        Total Laba Bersih Akhir Campaign (Flash Sale + Normal)
                      </span>
                      <div
                        className={`text-2xl sm:text-3xl font-mono font-extrabold mt-1 tabular-nums ${
                          v5Result.fsNetCampaignProfit >= 0
                            ? 'text-emerald-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {rp(v5Result.fsNetCampaignProfit)}
                      </div>
                      <p className="text-xs text-slate-400 mt-2">
                        {v5Result.fsTotalProfitOrLoss < 0
                          ? `Subsidi rugi Flash Sale akan tertutup impas jika ada minimal ${v5Result.fsBepNormalQty} pcs penjualan harga normal setelah Flash Sale.`
                          : 'Harga Flash Sale Anda masih menghasilkan untung positif tanpa perlu subsidi silang!'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* MODUL 06, 07, 08, 09 & 10: HARGA CORET, OVERHEAD GAJI OWNER, MODAL KERJA, DETEKTOR BOCOR DANA CAIR & MULTI-VARIAN */}
                <V5AdvancedModules
                  skuNama={skuNama}
                  hargaJualFinal={calcResult.hargaJualFinal}
                  hpp={calcResult.hpp}
                  packing={calcResult.packing}
                  totalModal={calcResult.totalModal}
                  totalPctFee={calcResult.totalPctFee}
                  totalPotonganTetap={calcResult.totalPotonganTetap}
                  biayaIklanPcs={calcResult.biayaIklanPcs}
                  profitBersih={calcResult.profitBersih}
                  danaCair={calcResult.danaCair}
                  diskonCoretPct={calcResult.diskonCoretPct}
                  onApplyDiskonCoret={(pct) => setInDiskonCoretPct(pct)}
                  onSyncOpexAndGajiToSimulasi={(totalOpex, targetGaji) => {
                    setSimOpexBulanan(totalOpex);
                    setTargetGajianBulanan(targetGaji);
                    setActiveMenu('proyeksi');
                    triggerToast(
                      `Overhead (${rp(totalOpex)}) & Target Gaji Owner (${rp(targetGaji)}) disinkronkan ke Menu Simulasi!`
                    );
                  }}
                  onToast={triggerToast}
                />
              </div>
            )}
          </section>
        )}

        {/* MENU 3: DATABASE KATALOG SKU & EXPORT EXCEL/PDF */}
        {activeMenu === 'database' && (
          <section className="space-y-4">
            {/* Analitik Eksekutif Portofolio Katalog SKU (Eksklusif v5.0) */}
            {skuDatabase.length > 0 &&
              (isV5Unlocked ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 no-print">
                  <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-2xl border border-slate-800/90">
                    <span className="text-[11px] text-slate-400 block">
                      Rata-Rata Margin Katalog
                    </span>
                    <div className="text-lg sm:text-xl font-mono font-extrabold text-emerald-400 mt-1 tabular-nums">
                      {skuAnalytics.avgMargin}%
                    </div>
                  </div>
                  <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-2xl border border-slate-800/90">
                    <span className="text-[11px] text-slate-400 block">
                      Rata-Rata Profit / Pcs
                    </span>
                    <div className="text-lg sm:text-xl font-mono font-extrabold text-white mt-1 tabular-nums">
                      {rp(skuAnalytics.avgProfit)}
                    </div>
                  </div>
                  <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-2xl border border-slate-800/90">
                    <span className="text-[11px] text-slate-400 block">
                      Produk Profit Tertinggi (Winner SKU)
                    </span>
                    <div className="text-xs sm:text-sm font-bold text-amber-300 mt-1 truncate">
                      {skuAnalytics.winnerSku
                        ? `${skuAnalytics.winnerSku.nama} (${rp(skuAnalytics.winnerSku.profitBersih)})`
                        : '-'}
                    </div>
                  </div>
                  <div className="bg-[#0E131F] p-3.5 sm:p-4 rounded-2xl border border-slate-800/90">
                    <span className="text-[11px] text-slate-400 block">
                      Kesehatan Katalog SKU
                    </span>
                    <div className="text-xs sm:text-sm font-bold text-sky-300 mt-1">
                      {skuAnalytics.healthyCount} Sehat ·{' '}
                      <span className="text-rose-400">
                        {skuAnalytics.riskCount} Tipis/Boncos
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-amber-500/10 via-[#0E131F] to-[#0E131F] p-4 rounded-2xl border border-amber-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
                  <div className="flex items-center gap-2.5">
                    <Crown className="w-5 h-5 text-amber-400 shrink-0" />
                    <div>
                      <div className="text-xs font-extrabold text-white">
                        Analitik Portofolio &amp; Deteksi Winner SKU (Eksklusif
                        v5.0 Ultimate)
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Upgrade ke v5.0 untuk membuka ringkasan rata-rata margin
                        toko, produk paling untung, dan deteksi SKU rawan boncos.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveMenu('v5suite')}
                    className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs px-3.5 py-2 rounded-xl transition-colors cursor-pointer shrink-0"
                  >
                    Buka di v5.0 →
                  </button>
                </div>
              ))}

            <div className="bg-[#0E131F] print-surface p-4 sm:p-6 rounded-2xl border border-slate-800/90 space-y-5">
              <div className="hidden print-only border-b-2 border-slate-900 pb-4 mb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-xl font-extrabold text-slate-900">
                      LAPORAN KATALOG HPP, HARGA JUAL &amp; PROFIT MARGIN SKU
                    </h1>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Toko / Brand Resmi: <strong>{licensedStore}</strong> ·
                      Dicetak via SellerMetrics Pro Suite
                    </p>
                  </div>
                  <div className="text-right text-xs text-slate-600">
                    <div>Tanggal Cetak: {currentPrintDate}</div>
                    <div>Total Produk: {filteredSkuDatabase.length} SKU</div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4 border-b border-slate-800/80 pb-4 no-print">
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-white">
                    Katalog Perhitungan HPP &amp; Harga SKU Tersimpan
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Klik tombol <strong>Muat</strong> untuk mengedit kembali SKU
                    di kalkulator, atau ekspor ke Excel/PDF.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative flex-grow sm:flex-grow-0 sm:w-56">
                    <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={searchQuerySku}
                      onChange={(e) => setSearchQuerySku(e.target.value)}
                      placeholder="Cari SKU / Nama produk..."
                      className="w-full bg-[#090D16] text-xs text-white pl-8 pr-7 py-2.5 rounded-xl border border-slate-800 focus:border-orange-500 focus:outline-none placeholder:text-slate-600"
                    />
                    {searchQuerySku && (
                      <button
                        type="button"
                        onClick={() => setSearchQuerySku('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleExportKeCSV}
                    disabled={skuDatabase.length === 0}
                    className="flex-1 sm:flex-initial justify-center bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:pointer-events-none text-white text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 shrink-0" />
                    <span>Export CSV</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleBackupFullDeviceJSON}
                    className="flex-1 sm:flex-initial justify-center bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/35 text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                    title="Download file backup penuh (.JSON) untuk pindah data ke HP atau Laptop lain"
                  >
                    <Save className="w-3.5 h-3.5 shrink-0" />
                    <span>Backup Pindah HP</span>
                  </button>

                  <label className="flex-1 sm:flex-initial justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center gap-1.5 cursor-pointer">
                    <Upload className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Restore / Import</span>
                    <input
                      type="file"
                      accept=".csv,.json"
                      onChange={handleImportFileSKU}
                      className="hidden"
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => window.print()}
                    disabled={skuDatabase.length === 0}
                    className="flex-1 sm:flex-initial justify-center bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:pointer-events-none text-white text-xs font-bold px-3.5 py-2.5 rounded-xl transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 shrink-0" />
                    <span>Cetak PDF</span>
                  </button>

                  {!confirmResetDb ? (
                    <button
                      type="button"
                      onClick={() => setConfirmResetDb(true)}
                      disabled={skuDatabase.length === 0}
                      className="bg-rose-950/50 hover:bg-rose-900/70 disabled:opacity-40 disabled:pointer-events-none text-rose-300 text-xs font-bold px-3.5 py-2.5 rounded-xl border border-rose-800/40 transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Reset</span>
                    </button>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 bg-rose-950/80 border border-rose-700/60 px-2.5 py-1.5 rounded-xl">
                      <span className="text-[11px] text-rose-200 font-semibold">
                        Hapus semua?
                      </span>
                      <button
                        type="button"
                        onClick={handleResetDatabaseSKU}
                        className="bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold px-2 py-1 rounded-lg cursor-pointer"
                      >
                        Ya
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmResetDb(false)}
                        className="text-slate-300 hover:text-white text-[11px] font-semibold px-1.5 py-1 cursor-pointer"
                      >
                        Batal
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {filteredSkuDatabase.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  <div className="max-w-sm mx-auto space-y-3 px-4">
                    <Package className="w-8 h-8 text-slate-600 mx-auto" />
                    <div className="space-y-1">
                      <p className="text-xs text-slate-300 font-semibold">
                        {skuDatabase.length === 0
                          ? 'Belum ada produk disimpan di Katalog SKU.'
                          : `Tidak ditemukan SKU dengan kata kunci "${searchQuerySku}".`}
                      </p>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        {skuDatabase.length === 0
                          ? 'Silakan hitung HPP pada menu Kalkulator lalu klik tombol “Simpan ke Katalog SKU”, atau muat contoh data di bawah ini.'
                          : 'Coba gunakan kata kunci pencarian lain.'}
                      </p>
                    </div>
                    {skuDatabase.length === 0 && (
                      <div className="pt-1">
                        <button
                          type="button"
                          onClick={handleMuatContohSKU}
                          className="bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold px-4 py-2.5 rounded-xl inline-flex items-center gap-2 transition-colors cursor-pointer"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                          <span>Muat 3 Contoh Produk (Demo Katalog)</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 gap-3 md:hidden no-print">
                    {filteredSkuDatabase.map((item, idx) => {
                      const rowKey = item.id || `${item.kode}-${idx}`;
                      return (
                        <div
                          key={`mob-${rowKey}`}
                          className="bg-[#090D16] p-4 rounded-xl border border-slate-800/90 space-y-3"
                        >
                          <div className="flex justify-between items-start gap-2 border-b border-slate-800/80 pb-2.5">
                            <div>
                              <span className="font-mono text-[11px] font-bold text-amber-400 block">
                                {item.kode}
                              </span>
                              <h4 className="text-xs font-bold text-white mt-0.5">
                                {item.nama}
                              </h4>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-slate-400 block">
                                Profit Bersih
                              </span>
                              <span className="font-mono text-xs font-extrabold text-emerald-400 tabular-nums">
                                {rp(item.profitBersih)} ({item.netMarginPct}%)
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[11px]">
                            <div>
                              <span className="text-slate-500 block">
                                Modal + Packing:
                              </span>
                              <span className="font-mono font-semibold text-sky-400 tabular-nums">
                                {rp(item.totalModal)}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-500 block">
                                Harga Coret:
                              </span>
                              <span className="font-mono text-slate-400 line-through tabular-nums">
                                {rp(item.hargaCoret)}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-500 block">
                                Harga Jual Final:
                              </span>
                              <span className="font-mono font-extrabold text-orange-400 tabular-nums">
                                {rp(item.hargaJualFinal)}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-500 block">
                                Fee MP &amp; Min ROAS:
                              </span>
                              <span className="font-mono text-rose-400 tabular-nums">
                                -{rp(item.totalSemuaFee)}{' '}
                                <strong className="text-indigo-300">
                                  ({item.minRoas}x)
                                </strong>
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/60">
                            <button
                              type="button"
                              onClick={() => handleMuatSkuKeKalkulator(item)}
                              className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold py-2 px-3 rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <RotateCcw className="w-3 h-3 text-orange-400" />
                              <span>Muat / Edit di Kalkulator</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleHapusSatuSku(
                                  item.id || item.kode,
                                  item.kode
                                )
                              }
                              title="Hapus SKU ini"
                              className="bg-rose-950/50 hover:bg-rose-900/70 text-rose-300 p-2 rounded-lg border border-rose-800/40 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="hidden md:block print-only overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse print-table">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                          <th className="py-3.5 px-3">SKU</th>
                          <th className="py-3.5 px-3">Nama Produk</th>
                          <th className="py-3.5 px-3 text-right">
                            Modal + Pack
                          </th>
                          <th className="py-3.5 px-3 text-right">
                            Harga Coret
                          </th>
                          <th className="py-3.5 px-3 text-right">
                            Harga Jual Final
                          </th>
                          <th className="py-3.5 px-3 text-right">
                            Total Fee MP
                          </th>
                          <th className="py-3.5 px-3 text-right">Min ROAS</th>
                          <th className="py-3.5 px-3 text-right">
                            Profit Bersih
                          </th>
                          <th className="py-3.5 px-3 text-right no-print">
                            Aksi
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {filteredSkuDatabase.map((item, idx) => {
                          const rowKey = item.id || `${item.kode}-${idx}`;
                          return (
                            <tr
                              key={`desk-${rowKey}`}
                              className="hover:bg-slate-800/30 transition-colors"
                            >
                              <td className="py-3.5 px-3 font-mono text-amber-400 font-bold whitespace-nowrap">
                                {item.kode}
                              </td>
                              <td className="py-3.5 px-3 font-semibold text-white">
                                {item.nama}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-sky-400 tabular-nums whitespace-nowrap">
                                {rp(item.totalModal)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-slate-500 line-through tabular-nums whitespace-nowrap">
                                {rp(item.hargaCoret)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono font-extrabold text-orange-400 tabular-nums whitespace-nowrap">
                                {rp(item.hargaJualFinal)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-rose-400 tabular-nums whitespace-nowrap">
                                -{rp(item.totalSemuaFee)}
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono text-indigo-300 font-bold tabular-nums whitespace-nowrap">
                                {item.minRoas}x
                              </td>
                              <td className="py-3.5 px-3 text-right font-mono font-extrabold text-emerald-400 tabular-nums whitespace-nowrap">
                                {rp(item.profitBersih)}{' '}
                                <span className="text-slate-400 font-normal">
                                  ({item.netMarginPct}%)
                                </span>
                              </td>
                              <td className="py-3.5 px-3 text-right whitespace-nowrap no-print">
                                <div className="inline-flex items-center justify-end gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleMuatSkuKeKalkulator(item)
                                    }
                                    title="Muat & Edit di Kalkulator"
                                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold px-2.5 py-1.5 rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                                  >
                                    <RotateCcw className="w-3 h-3 text-orange-400" />
                                    <span>Muat</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleHapusSatuSku(
                                        item.id || item.kode,
                                        item.kode
                                      )
                                    }
                                    title="Hapus SKU ini"
                                    className="bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 p-1.5 rounded-lg border border-rose-800/40 transition-colors cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          </section>
        )}

        {/* 5. BANNER UPSELL JASA WEB & SOURCE CODE */}
        <div className="mt-6 sm:mt-8 bg-gradient-to-r from-[#111729] via-[#0E131F] to-[#0E131F] p-5 sm:p-7 rounded-2xl border border-indigo-500/25 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 sm:gap-6 no-print">
          <div className="space-y-1.5 max-w-2xl">
            <div className="text-[11px] font-bold text-indigo-400 tracking-wide">
              Partner Resmi Transformasi Digital UMKM
            </div>
            <h4 className="text-sm sm:text-base font-extrabold text-white leading-snug">
              Ingin Punya Website Katalog Order WhatsApp Sendiri atau Beli
              Source Code Aplikasi Ini?
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Bebas potongan admin marketplace! Bangun website toko online,
              landing page, atau beli hak jual kembali (White-Label Source Code)
              bersama{' '}
              <strong className="text-white font-semibold">
                {OWNER_CONFIG.brandName}
              </strong>
              .
            </p>
          </div>

          <div className="flex flex-col sm:flex-row w-full lg:w-auto gap-2.5 sm:gap-3 shrink-0">
            <a
              href={waSourceCodeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto justify-center bg-[#090D16] hover:bg-slate-900 text-amber-300 border border-amber-500/30 text-xs font-bold py-3 px-4 rounded-xl transition-colors inline-flex items-center gap-2"
            >
              <Code2 className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Beli Source Code ({OWNER_CONFIG.hargaSourceCode})</span>
            </a>
            <a
              href={waJasaWebUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto justify-center bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-3 px-4 rounded-xl transition-colors shadow-lg shadow-indigo-600/20 inline-flex items-center gap-2"
            >
              <Globe className="w-4 h-4 shrink-0" />
              <span>Buat Website Toko Sekarang</span>
              <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}
