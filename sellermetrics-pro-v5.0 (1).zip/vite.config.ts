import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import {execSync} from 'child_process';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'bundle-standalone-and-zip',
        closeBundle() {
          try {
            const distIndex = path.resolve(import.meta.dirname, 'dist/index.html');
            if (!fs.existsSync(distIndex)) return;
            let html = fs.readFileSync(distIndex, 'utf-8');
            const assetsDir = path.resolve(import.meta.dirname, 'dist/assets');
            if (fs.existsSync(assetsDir)) {
              const files = fs.readdirSync(assetsDir);
              const cssFile = files.find((f) => f.endsWith('.css'));
              const jsFile = files.find((f) => f.endsWith('.js'));
              if (cssFile && jsFile) {
                const css = fs.readFileSync(path.join(assetsDir, cssFile), 'utf-8');
                const js = fs.readFileSync(path.join(assetsDir, jsFile), 'utf-8');
                html = html.replace(
                  /<link rel="stylesheet"[^>]*>/,
                  () => `<style>${css}</style>`
                );
                html = html.replace(
                  /<script type="module"[^>]*><\/script>/,
                  () => `<script type="module">${js}</script>`
                );
                fs.writeFileSync(
                  path.resolve(import.meta.dirname, 'public/SellerMetrics-Pro-v4.0.html'),
                  html,
                  'utf-8'
                );
                fs.writeFileSync(
                  path.resolve(import.meta.dirname, 'dist/SellerMetrics-Pro-v4.0.html'),
                  html,
                  'utf-8'
                );
              }
            }
            execSync(
              `python3 -c "import os, zipfile; zf = zipfile.ZipFile('public/sellermetrics-update-netlify.zip', 'w', zipfile.ZIP_DEFLATED); [zf.write(os.path.join(r, f), os.path.relpath(os.path.join(r, f), 'dist')) for r, d, files in os.walk('dist') for f in files if f != 'sellermetrics-update-netlify.zip']; zf.close()"`
            );
          } catch (e) {
            console.warn('Packaging warning:', e);
          }
        },
      },
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['icon.svg', 'apple-touch-icon.png'],
        manifest: {
          id: '/',
          name: 'SellerMetrics Pro v5.0',
          short_name: 'SellerMetric',
          description:
            'SaaS Kalkulator HPP, ROAS & Margin Marketplace — Hitung HPP, Harga Coret, Batas Aman ROAS Iklan, Bundling, Flash Sale & Simulasi Profit Bersih Shopee/TikTok Shop.',
          theme_color: '#080B12',
          background_color: '#080B12',
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,woff,woff2}'],
          globIgnores: [
            'SellerMetrics-Pro-v4.0.html',
            'sellermetrics-update-netlify.zip',
            'og-banner.png',
            '**/node_modules/**/*',
          ],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    build: {
      chunkSizeWarningLimit: 800,
    },
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR === 'true' to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
